class TeachingError(RuntimeError):
    """Device operation failed; no usable position is returned."""


class ConnectionError(TeachingError):
    pass


class ReadError(TeachingError):
    pass


class DeviceFault(TeachingError):
    pass


class TorqueError(TeachingError):
    pass
