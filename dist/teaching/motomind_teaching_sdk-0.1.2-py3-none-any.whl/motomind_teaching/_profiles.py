"""Internal right-device definition; public JSON contains only force tuning."""
import json
from pathlib import Path

TUNING_KEYS = ('torque_enable', 'current_limit', 'p_gain')


def resolve_profile(data):
    """Combine user tuning with locked coordinates, accepting unchanged dev metadata."""
    if not isinstance(data, dict):
        raise ValueError('teaching settings must be a JSON object')
    fixed = json.loads(Path(__file__).with_name('_right_device.json').read_text())
    unknown = data.keys() - (fixed.keys() | set(TUNING_KEYS) | {'note', 'position_limits_source'})
    if unknown:
        raise ValueError(f'unknown teaching settings: {sorted(unknown)}')
    for key, value in fixed.items():
        if key in data:
            supplied = data[key]
            if key == 'teleop_feedback' and isinstance(supplied, dict):
                supplied = {k: v for k, v in supplied.items() if k != 'source'}
            if supplied != value:
                raise ValueError(f'{key} is fixed by the teaching SDK')
    for key, predicate in (
        ('torque_enable', lambda v: type(v) is bool),
        ('current_limit', lambda v: type(v) is int and 0 <= v <= 800),
        ('p_gain', lambda v: type(v) is int and 0 <= v <= 150),
    ):
        values = data.get(key)
        if not isinstance(values, (list, tuple)) or len(values) != len(fixed['ids']) or not all(
                predicate(v) for v in values):
            raise ValueError(f'invalid {key}: seven supported values required')
        if key == 'p_gain' and any(value > 100 and joint != 'gripper'
                                  for joint, value in zip(fixed['joint_names'], values)):
            raise ValueError('invalid p_gain: arm 0..100, gripper 0..150 required')
        fixed[key] = list(values)
    return fixed


def load_profile(path):
    return resolve_profile(json.loads(Path(path).read_text()))
