"""Small Protocol 2.0 adapter. No port repair, process killing, or fake fallback."""
import time
import errno
from .errors import ConnectionError, ReadError, TorqueError
from .serial_access import permission_help


class DxlTransport:
    def __init__(self, port, baudrate):
        self.port_name, self.baudrate = port, baudrate
        self.port = None

    def open(self):
        from dynamixel_sdk import PortHandler, PacketHandler
        self.port = PortHandler(self.port_name)
        self.port.getCurrentTime = lambda: time.monotonic() * 1000
        self.packet = PacketHandler(2.0)
        try:
            if not self.port.openPort() or not self.port.setBaudRate(self.baudrate):
                raise ConnectionError(f'cannot open {self.port_name} at {self.baudrate}')
            # POSIX serial exclusive lock cooperates with other exclusive openers.
            # It cannot evict or stop a non-cooperating program already using the port.
            if hasattr(self.port, 'ser'):
                self.port.ser.exclusive = True
                self.port.ser.write_timeout = .1
        except BaseException as exc:
            self.close()
            if not isinstance(exc, Exception):
                raise
            if isinstance(exc, PermissionError) or getattr(exc, 'errno', None) in (errno.EACCES, errno.EPERM):
                raise ConnectionError(permission_help(self.port_name)) from exc
            raise ConnectionError(f'{self.port_name}: {exc}') from exc

    def _check(self, result, error, mid, kind):
        if result != 0 or error != 0:
            raise kind(f'DXL {mid}: {self.packet.getTxRxResult(result)}; '
                       f'{self.packet.getRxPacketError(error)}')

    def ping(self, mid):
        model, result, error = self.packet.ping(self.port, mid)
        self._check(result, error, mid, ConnectionError)
        return model

    def read(self, mid, address, size):
        value, result, error = getattr(self.packet, f'read{size}ByteTxRx')(
            self.port, mid, address)
        self._check(result, error, mid, ReadError)
        return value

    def write(self, mid, address, size, value):
        expected = value & ((1 << (size*8))-1)
        result, error = getattr(self.packet, f'write{size}ByteTxRx')(
            self.port, mid, address, expected)
        self._check(result, error, mid, TorqueError)
        actual = self.read(mid, address, size)
        if actual != expected:
            raise TorqueError(f'DXL {mid}: register {address} readback mismatch '
                              f'(wrote={expected} [0x{expected:0{size*2}X}], '
                              f'read={actual} [0x{actual:0{size*2}X}])')

    def _sync_read(self, ids, address, size):
        # One broadcast request, as in the legacy driver. GroupSyncRead.rxPacket()
        # discards per-servo error flags, so receive through readRx() explicitly.
        ids = tuple(ids)
        result = self.packet.syncReadTx(self.port, address, size, list(ids), len(ids), False)
        self._check(result, 0, 'sync read request', ReadError)
        values = []
        for mid in ids:
            data, result, error = self.packet.readRx(self.port, mid, size)
            self._check(result, error, mid, ReadError)
            if len(data) != size:
                raise ReadError(f'DXL {mid}: incomplete register {address} response')
            value = int.from_bytes(data, 'little')
            values.append(value)
        return values

    def positions(self, ids):
        return [value - (1 << 32) if value >= (1 << 31) else value
                for value in self._sync_read(ids, 132, 4)]

    def feedback_state(self, ids):
        """Fresh mode and torque checks for every selected axis, in two requests."""
        ids = tuple(ids)
        modes = self._sync_read(ids, 11, 1)
        torque = self._sync_read(ids, 64, 1)
        return tuple(zip(modes, torque))

    def close(self):
        if self.port is not None:
            try:
                if self.port.ser is not None:
                    self.port.closePort()
            finally:
                self.port = None
