"""Explicit output-coordinate calibration. Contains no robot-specific constants."""
from dataclasses import dataclass
import math


def _finite(value):
    return type(value) in (int, float) and math.isfinite(value)


@dataclass(frozen=True)
class PositionMapping:
    offsets_rad: tuple
    gains: tuple
    limits_rad: tuple

    def __post_init__(self):
        offsets = tuple(self.offsets_rad)
        gains = tuple(self.gains)
        limits = tuple(tuple(pair) for pair in self.limits_rad)
        if not offsets or len(offsets) != len(gains) or len(offsets) != len(limits):
            raise ValueError('mapping offset/gain/limit lengths must match')
        if not all(_finite(v) for v in offsets) or not all(_finite(v) and v != 0 for v in gains):
            raise ValueError('mapping requires finite offsets and finite nonzero gains')
        if any(len(pair) != 2 or not all(_finite(v) for v in pair)
               or pair[0] >= pair[1] for pair in limits):
            raise ValueError('mapping limits must be finite [min, max] pairs with min < max')
        object.__setattr__(self, 'offsets_rad', offsets)
        object.__setattr__(self, 'gains', gains)
        object.__setattr__(self, 'limits_rad', limits)

    def apply(self, raw_positions):
        raw = tuple(raw_positions)
        if len(raw) != len(self.offsets_rad) or not all(_finite(v) for v in raw):
            raise ValueError('invalid raw position vector')
        mapped = tuple(gain*(value-offset) for value, offset, gain
                       in zip(raw, self.offsets_rad, self.gains))
        if not all(math.isfinite(v) for v in mapped):
            raise ValueError('mapped position overflow')
        return tuple(max(lo, min(hi, v)) for v, (lo, hi) in zip(mapped, self.limits_rad))
