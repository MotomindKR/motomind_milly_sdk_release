"""Position-only API with explicit profile mapping; following policy belongs to callers."""
import math
import time
from threading import RLock

from .errors import ConnectionError, DeviceFault, ReadError, TorqueError
from .transport import DxlTransport
from .mapping import PositionMapping
from ._profiles import load_profile

# Explicit initial support. Other models must get a verified control table first.
MODELS = {1190: 'XL330-M077-T', 1200: 'XL330-M288-T'}
RAD_PER_TICK = 2 * math.pi / 4096


class TeachingDevice:
    def __init__(self, port, ids, *, baudrate=1_000_000, read_timeout_s=.25,
                 transport=None, mapping=None, expected_models=None):
        self.ids = tuple(ids)
        if not self.ids or len(set(self.ids)) != len(self.ids) or any(
            type(i) is not int or not 0 <= i <= 252 for i in self.ids
        ):
            raise ValueError('ids must be unique integers in 0..252')
        if not math.isfinite(read_timeout_s) or read_timeout_s <= 0:
            raise ValueError('read_timeout_s must be finite and positive')
        if type(baudrate) is not int or baudrate <= 0:
            raise ValueError('baudrate must be a positive integer')
        if mapping is not None and (not isinstance(mapping, PositionMapping)
                                    or len(mapping.offsets_rad) != len(self.ids)):
            raise ValueError('mapping must match the configured IDs')
        self.mapping = mapping
        self.expected_models = tuple(expected_models) if expected_models is not None else None
        if self.expected_models is not None and (len(self.expected_models) != len(self.ids)
                or any(m not in MODELS.values() for m in self.expected_models)):
            raise ValueError('expected_models must specify one supported model per ID')
        self.read_timeout_s = read_timeout_s
        self._io = transport if transport is not None else DxlTransport(port, baudrate)
        self._lock = RLock()
        self._opened = False
        self._fault = None
        self._owned = set()
        self._prepared = set()
        self._current_ceiling = {}
        self.models = {}

    @classmethod
    def from_profile(cls, port, profile_path, **kwargs):
        """Load user force tuning with the SDK's fixed right-device coordinates.

        Gains/current tuning in that file are for examples, not automatically applied.
        """
        data = load_profile(profile_path)
        try:
            mapping = PositionMapping(data['position_offset_rad'], data['position_gain'],
                                      data['position_limits_rad'])
            return cls(port, data['ids'], mapping=mapping, expected_models=data['models'], **kwargs)
        except (KeyError, TypeError) as exc:
            raise ValueError(f'invalid teaching profile: {exc}') from exc

    def open(self):
        """Ping every configured ID and verify a first sample; never changes torque."""
        with self._lock:
            if self._opened:
                raise ConnectionError('already open; close before reconnecting')
            self._fault = None
            self._prepared.clear()
            self._current_ceiling.clear()
            self.models = {}
            try:
                self._io.open()
                for index, mid in enumerate(self.ids):
                    model = self._io.ping(mid)
                    if model not in MODELS:
                        raise ConnectionError(f'DXL {mid}: unsupported model {model}')
                    if self.expected_models is not None and MODELS[model] != self.expected_models[index]:
                        raise ConnectionError(f'DXL {mid}: expected {self.expected_models[index]}, '
                                              f'got {MODELS[model]}')
                    self.models[mid] = MODELS[model]
                self._opened = True
                self._read_raw_positions()
            except BaseException as exc:
                self._opened = False
                self._io.close()
                if not isinstance(exc, Exception):
                    raise
                raise ConnectionError(f'connection/initial sample failed: {exc}') from exc
        return self

    def _require(self, *, allow_fault=False):
        if not self._opened:
            raise ConnectionError('device is not open')
        if self._fault is not None and not allow_fault:
            raise DeviceFault(f'device fault latched; close/open explicitly: {self._fault}')

    def read_positions(self):
        """Return fresh output positions: gain * (raw - offset), clipped to profile limits.

        from_profile() configures mapping. A bare constructor without mapping is a
        generic encoder reader and returns raw radians. Both paths reject failed reads.
        """
        with self._lock:
            raw = self._read_raw_positions()
            try:
                return self.mapping.apply(raw) if self.mapping is not None else raw
            except ValueError as exc:
                self._fault = str(exc)
                raise ReadError(f'no position output: {exc}') from exc

    def _read_raw_positions(self):
        """Return a NEW tuple of device encoder angles in radians, in ids order.

        One Sync Read request for all axes; no velocity, cached output, zero
        substitution, partial sample, or retry. Per-axis status errors are checked.
        The timeout rejects late samples; it is not an OS-level interruption timer.
        """
        with self._lock:
            self._require()
            try:
                start = time.monotonic()
                raw = self._io.positions(self.ids)
                if time.monotonic() - start > self.read_timeout_s:
                    raise ReadError('position transaction exceeded read_timeout_s')
                if len(raw) != len(self.ids) or any(
                    type(x) is not int or not -(1 << 31) <= x < (1 << 31) for x in raw
                ):
                    raise ReadError('incomplete or invalid position sample')
                return tuple(x * RAD_PER_TICK for x in raw)
            except Exception as exc:
                self._fault = str(exc)
                raise ReadError(f'no position output: {exc}') from exc

    def _vector(self, values, name, low, high, *, integer=False):
        values = tuple(values)
        if len(values) != len(self.ids) or any(
            isinstance(v, bool) or not isinstance(v, (int, float))
            or not math.isfinite(v) or not low <= v <= high
            or (integer and int(v) != v) for v in values
        ):
            raise ValueError(f'{name}: expected {len(self.ids)} values in [{low}, {high}]')
        return values

    def prepare_hold(self, *, p_gain, current_limit_ma):
        """With ALL axes off, prepare Mode 5 gains/current; does not enable.

        current_limit_ma sets RAM Goal Current(102), not EEPROM Current Limit(38).
        Uses current factory hardware limit as an additional bound. No preset gains.
        Goal Position is set from a fresh encoder sample AFTER zero-current ON,
        following the verified legacy sequence. The returned pose is diagnostic.
        """
        with self._lock:
            self._require()
            gains = self._vector(p_gain, 'p_gain', 0, 16383, integer=True)
            currents = self._vector(current_limit_ma, 'current_limit_ma', 0, 1750)
            self._prepared.clear()
            try:
                for mid, current in zip(self.ids, currents):
                    if self._io.read(mid, 64, 1):
                        raise TorqueError('prepare_hold requires all axes torque OFF')
                    if self._io.read(mid, 10, 1) & 8:
                        raise TorqueError(f'DXL {mid}: Drive Mode(10) bit 3 enables torque on goal update; '
                                          'hold preparation refused without changing Drive Mode')
                    ceiling = self._io.read(mid, 38, 2)
                    if current > ceiling:
                        raise TorqueError(f'DXL {mid}: exceeds device Current Limit(38)')
                    self._current_ceiling[mid] = ceiling
                for mid in self.ids:
                    self._io.write(mid, 11, 1, 5)
                # Read AFTER mode changes (encoder representation may change).
                pose = self._read_raw_positions()
                for mid, gain, current in zip(self.ids, gains, currents):
                    self._io.write(mid, 84, 2, int(gain))
                    self._io.write(mid, 82, 2, 0)
                    self._io.write(mid, 80, 2, 0)
                    self._io.write(mid, 102, 2, int(current))
                self._prepared.update(self.ids)
                return pose
            except Exception as exc:
                self._fault = str(exc)
                raise TorqueError(f'hold preparation failed: {exc}') from exc

    def set_current_limits(self, current_limit_ma):
        """Set Mode 5 RAM current caps after prepare_hold; no EEPROM writes.

        Model units are mA for the supported XL330s. Soft ramp policy is in examples.
        """
        with self._lock:
            self._require()
            currents = self._vector(current_limit_ma, 'current_limit_ma', 0, 1750)
            if self._prepared != set(self.ids):
                raise TorqueError('prepare_hold before setting current limits')
            if any(c > self._current_ceiling[i] for i, c in zip(self.ids, currents)):
                raise ValueError('current exceeds device Current Limit(38)')
            try:
                for mid, current in zip(self.ids, currents):
                    self._io.write(mid, 102, 2, int(current))
            except Exception as exc:
                self._fault = str(exc)
                raise TorqueError(f'current update failed: {exc}') from exc

    def apply_feedback(self, raw_position_rad, *, p_gain, ids):
        """Write raw Mode 5 targets and gains to an owned, enabled subset.

        Full vectors follow self.ids; output offset/gain/clipping is never applied.
        Force policy and interpolation belong to the caller. A transport failure
        latches a fault and attempts OFF for every axis owned by this instance.
        """
        selected = tuple(ids)
        if not selected or len(set(selected)) != len(selected) or any(i not in self.ids for i in selected):
            raise ValueError('ids must be a nonempty unique subset of device ids')
        with self._lock:
            self._require()
            gains = self._vector(p_gain, 'p_gain', 0, 16383, integer=True)
            targets = self._vector(raw_position_rad, 'raw_position_rad',
                                   -1048575 * RAD_PER_TICK, 1048575 * RAD_PER_TICK)
            if not set(selected) <= (self._prepared & self._owned):
                raise TorqueError('feedback requires prepared axes enabled by this instance')
            try:
                # Validate every selected axis before writing any new target.
                for mid in selected:
                    if self._io.read(mid, 64, 1) != 1 or self._io.read(mid, 11, 1) != 5:
                        raise TorqueError(f'DXL {mid}: feedback requires torque ON in Mode 5')
                for mid, gain, target in zip(self.ids, gains, targets):
                    if mid in selected:
                        if self._io.read(mid, 84, 2) != gain:
                            self._io.write(mid, 84, 2, int(gain))
                        self._io.write(mid, 116, 4, round(target / RAD_PER_TICK))
            except BaseException as exc:
                self._fault = str(exc)
                try:
                    self._off(tuple(self._owned))
                except TorqueError as stop:
                    raise TorqueError(f'feedback failed: {exc}; {stop}') from exc
                if isinstance(exc, Exception):
                    raise TorqueError(f'feedback failed: {exc}') from exc
                raise

    def set_torque(self, enabled, *, ids=None):
        """Enable/disable ALL configured axes by default; optional subset for examples.

        ON requires prepare_hold. Current is verified at zero before ON; fresh
        raw hold goals are written/read back after ON, then current caps restored.
        On partial failure, attempts OFF on every axis
        attempted by this call. OFF remains available after read/write faults.
        """
        if type(enabled) is not bool:
            raise ValueError('enabled must be bool')
        selected = self.ids if ids is None else tuple(ids)
        if not selected or len(set(selected)) != len(selected) or any(i not in self.ids for i in selected):
            raise ValueError('ids must be a nonempty unique subset of device ids')
        with self._lock:
            self._require(allow_fault=not enabled)
            if enabled and not set(selected) <= self._prepared:
                raise TorqueError('prepare_hold before enabling torque')
            if enabled:
                if any(self._io.read(mid, 64, 1) for mid in selected):
                    raise TorqueError('selected axes already ON; turn OFF before enabling')
                try:
                    # Legacy captures/commands the hold goal AFTER ON. Keep its
                    # order, with a zero current cap while the previous goal is active.
                    requested = {mid: self._io.read(mid, 102, 2) for mid in selected}
                    if any(not 0 <= value <= self._current_ceiling[mid]
                           for mid, value in requested.items()):
                        raise TorqueError('invalid prepared Goal Current(102) before ON')
                    for mid in selected:
                        self._io.write(mid, 102, 2, 0)
                    for mid in selected:
                        self._owned.add(mid)  # a lost ACK can still mean enabled
                        self._io.write(mid, 64, 1, 1)
                    pose = self._read_raw_positions()
                    for mid, angle in zip(self.ids, pose):
                        if mid in selected:
                            self._io.write(mid, 116, 4, round(angle/RAD_PER_TICK))
                    # No nonzero current until ALL selected hold goals verify.
                    for mid in selected:
                        self._io.write(mid, 102, 2, requested[mid])
                except BaseException as exc:
                    self._fault = str(exc)
                    try:
                        self._off(tuple(self._owned))
                    except TorqueError as stop:
                        raise TorqueError(f'enable failed: {exc}; {stop}') from exc
                    if isinstance(exc, Exception):
                        raise TorqueError(f'enable failed: {exc}') from exc
                    raise
            else:
                self._off(selected)

    def _off(self, ids):
        failures = []
        for mid in ids:
            try:
                self._io.write(mid, 64, 1, 0)
                self._owned.discard(mid)
            except Exception as exc:
                failures.append(f'{mid}: {exc}')
        if failures:
            self._fault = '; '.join(failures)
            raise TorqueError('torque OFF NOT confirmed for ' + self._fault)

    def close(self):
        """OFF axes enabled by this instance, then close. Read-only use sends no writes.

        A failed stop is reported, not described as safe. USB/power loss may prevent OFF.
        """
        with self._lock:
            try:
                if self._opened and self._owned:
                    self._off(tuple(self._owned))
            finally:
                self._io.close()
                self._opened = False
                self._prepared.clear()

    def __enter__(self):
        return self.open()

    def __exit__(self, *_):
        self.close()
