"""Linux serial access check. Never opens a port or changes permissions."""
import argparse
import errno
import os
from pathlib import Path
import stat

DEFAULT_PORT = '/dev/ttyUSB0'


def permission_help(port):
    return (f'Permission denied for {port}. On Ubuntu, run '
            'sudo usermod -aG dialout "$USER", then log out and log in again '
            '(restart VS Code/Codex too). Check with: teaching-check-port. '
            'No chmod or sudo is run automatically.')


def check_access(port=DEFAULT_PORT):
    path = Path(port)
    try:
        info = path.stat()
    except FileNotFoundError:
        return False, f'{port}: device not found. Connect the DXL USB adapter or specify --port.'
    except OSError as exc:
        return False, permission_help(port) if exc.errno in (errno.EACCES, errno.EPERM) else str(exc)
    if not stat.S_ISCHR(info.st_mode):
        return False, f'{port}: not a serial character device'
    try:
        import grp
        group = grp.getgrgid(info.st_gid).gr_name
    except (KeyError, ImportError):
        group = str(info.st_gid)
    details = f'{port}: mode={stat.filemode(info.st_mode)}, group={group}'
    if not os.access(path, os.R_OK | os.W_OK):
        return False, details + '\n' + permission_help(port)
    return True, details + '\nRead/write permission OK (port not opened; DXL communication not tested).'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', default=DEFAULT_PORT)
    args = parser.parse_args()
    ok, message = check_access(args.port)
    print(message)
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
