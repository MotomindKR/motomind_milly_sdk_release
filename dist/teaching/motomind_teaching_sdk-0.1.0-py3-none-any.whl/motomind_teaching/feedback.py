"""Milly joint_limit force policy in the current teaching output coordinates.

Use unclipped output coordinates for limit detection and convert targets back to raw.
No Milly/ROS imports and no hardware access in the policy calculations.
"""
import math

from .mapping import PositionMapping
from .device import RAD_PER_TICK
from ._profiles import resolve_profile


class TeleopFeedback:
    def __init__(self, profile):
        try:
            settings = profile['teleop_feedback']
            if settings['coordinate_source'] != 'position_mapping':
                raise ValueError('teleop feedback must use position_mapping coordinates')
            mapping = PositionMapping(profile['position_offset_rad'], profile['position_gain'],
                                      profile['position_limits_rad'])
            self.multiplier = settings['p_gain_over_limit_multiplier']
        except KeyError as exc:
            raise ValueError(f'missing teleop feedback setting: {exc}') from exc
        self.offsets = mapping.offsets_rad
        self.gains = mapping.gains
        self.limits = mapping.limits_rad
        self.base_p_gain = tuple(profile['p_gain'])
        if len(self.base_p_gain) != len(profile['ids']) or len(self.offsets) != len(profile['ids']):
            raise ValueError('teleop feedback vectors must match IDs')
        if (isinstance(self.multiplier, bool) or not isinstance(self.multiplier, (int, float))
                or not math.isfinite(self.multiplier) or self.multiplier < 1):
            raise ValueError('invalid teleop P gain multiplier')
        for gain in self.base_p_gain:
            if (type(gain) is not int or not 0 <= gain <= 16383
                    or gain * self.multiplier > 16383 or int(gain * self.multiplier) != gain * self.multiplier):
                raise ValueError('teleop gains must fit integer register values')
        # The legacy default_action is the midpoint of each action limit.
        self.raw_target = tuple((lo + hi) / 2 / gain + offset
                                for (lo, hi), gain, offset in zip(self.limits, self.gains, self.offsets))
        if any(not math.isfinite(value) or abs(value) > 1048575 * RAD_PER_TICK for value in self.raw_target):
            raise ValueError('teleop raw targets exceed Mode 5 position range')

    def position_gains(self, raw_positions):
        raw_positions = tuple(raw_positions)
        if len(raw_positions) != len(self.offsets) or not all(math.isfinite(x) for x in raw_positions):
            raise ValueError('teleop feedback requires a complete finite raw sample')
        actions = tuple(gain * (raw - offset)
                        for raw, offset, gain in zip(raw_positions, self.offsets, self.gains))
        return tuple(int(base if lo <= action <= hi else base * self.multiplier)
                     for base, action, (lo, hi) in zip(self.base_p_gain, actions, self.limits))

    def ramped_target(self, start_positions, fraction):
        return tuple(start + (goal - start) * fraction
                     for start, goal in zip(start_positions, self.raw_target))


class TeachingFeedback:
    """Optional example force policy; never enables or reads hardware on construction.

    JSON tuning uses torque_enable (bool), current_limit (mA, 0..800),
    and p_gain (integer, 0..100). Raw motor targets remain separate from output.
    Call enable() explicitly inside a TeachingDevice context, then step() for
    each NEW output sample. Let read/write errors propagate to caller cleanup.
    """
    def __init__(self, device, profile, *, ramp_seconds=3., clock=None):
        import time
        profile = resolve_profile(profile)
        self.device = device
        if tuple(profile['ids']) != device.ids or device.mapping is None:
            raise ValueError('feedback profile must match the mapped device IDs')
        self.policy = TeleopFeedback(profile)
        # A caller must not accidentally use one profile for output and another for force.
        if (self.policy.offsets != device.mapping.offsets_rad
                or self.policy.gains != device.mapping.gains
                or self.policy.limits != device.mapping.limits_rad):
            raise ValueError('feedback coordinates must match device mapping')
        def vector(name, predicate):
            values = tuple(profile[name])
            if len(values) != len(device.ids) or not all(predicate(v) for v in values):
                raise ValueError(f'invalid {name}: one supported value per ID required')
            return values
        mask = vector('torque_enable', lambda v: type(v) is bool)
        currents = vector('current_limit', lambda v: type(v) is int and 0 <= v <= 800)
        self.p_gain = vector('p_gain', lambda v: type(v) is int and 0 <= v <= 100)
        self.ids = tuple(mid for mid, on in zip(device.ids, mask) if on)
        self.current_limit = tuple(c if on else 0 for c, on in zip(currents, mask))
        if not math.isfinite(ramp_seconds) or ramp_seconds <= 0:
            raise ValueError('ramp_seconds must be finite and positive')
        self.ramp_seconds = ramp_seconds
        self.clock = clock or time.monotonic
        self.started = None

    def enable(self):
        if self.started is not None:
            raise ValueError('feedback already enabled')
        self.device.set_torque(False)
        if self.ids:
            self.device.prepare_hold(p_gain=self.p_gain, current_limit_ma=self.current_limit)
            self.device.set_current_limits([0] * len(self.device.ids))
            self.device.set_torque(True, ids=self.ids)
        self.start_pose = self.device._read_raw_positions()
        self.started = self.clock()

    def step(self):
        if self.started is None:
            raise ValueError('enable feedback before requesting output')
        raw = self.device._read_raw_positions()
        fraction = min(1., max(0., (self.clock() - self.started) / self.ramp_seconds))
        scale = .5 * (1 - math.cos(math.pi * fraction))
        if self.ids:
            self.device.apply_feedback(self.policy.ramped_target(self.start_pose, scale),
                                       p_gain=self.policy.position_gains(raw), ids=self.ids)
            self.device.set_current_limits([c * scale for c in self.current_limit])
        return self.device.mapping.apply(raw)
