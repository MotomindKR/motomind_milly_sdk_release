"""Explicit test transport. Never selected automatically by TeachingDevice."""
from .errors import ConnectionError, ReadError, TorqueError


class FakeTransport:
    def __init__(self, ids, *, model=1200):
        self.ids = tuple(ids)
        self.model = model
        self.positions_raw = [2048] * len(self.ids)
        self.registers = {(mid, address): value for mid in self.ids
                          for address, value in [(64, 0), (38, 1750), (11, 3),
                                                 (84, 0), (102, 0), (116, 2048)]}
        self.writes = []
        self.read_count = 0
        self.fail_after = None
        self.fail_write = None
        self.missing_ids = set()
        self.opened = False

    def open(self):
        self.opened = True

    def ping(self, mid):
        if mid in self.missing_ids:
            raise ConnectionError(f'fake missing ID {mid}')
        return self.model[mid] if isinstance(self.model, dict) else self.model

    def positions(self, ids):
        self.read_count += 1
        if self.fail_after is not None and self.read_count > self.fail_after:
            raise ReadError('injected cable disconnect')
        if set(ids) & self.missing_ids:
            raise ReadError('injected partial read')
        return self.positions_raw.copy()

    def read(self, mid, address, size):
        if address == 132:
            return self.positions_raw[self.ids.index(mid)] & 0xFFFFFFFF
        return self.registers.get((mid, address), 0)

    def feedback_state(self, ids):
        if set(ids) & self.missing_ids:
            raise ReadError('injected partial state read')
        return tuple((self.read(mid, 11, 1), self.read(mid, 64, 1)) for mid in ids)

    def write(self, mid, address, size, value):
        self.writes.append((mid, address, size, value))
        if self.fail_write and self.fail_write(mid, address, value):
            raise TorqueError('injected write/ACK failure')
        self.registers[mid, address] = value

    def close(self):
        self.opened = False
