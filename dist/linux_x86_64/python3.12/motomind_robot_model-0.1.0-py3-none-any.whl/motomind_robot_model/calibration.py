"""Static gravity calibration — identify per-link (mass, mass*COM) from held-pose
torques, so gravity compensation uses MEASURED parameters instead of the (often
inaccurate) URDF CAD inertials.

Physics (verified against Pinocchio on the Milly URDF): the joint gravity torque
is LINEAR in the inertial parameters,

    tau_gravity(q) = Y_g(q) @ phi_g

where ``Y_g`` comes from ``pin.computeJointTorqueRegressor(model, data, q, 0, 0)``
and ``phi_g`` holds, PER LINK, only the gravity-observable parameters:

    phi_g[link] = [m, m*cx, m*cy, m*cz]     (mass + first moment)

The rotation-inertia terms (Ixx..Izz) do NOT affect gravity — their regressor
columns are exactly zero — so they are unobservable and left at their URDF
values. Stacking N held poses gives a least-squares problem solved with ridge
regularization toward the URDF prior (keeps weakly-observed directions sane;
``cond(W)`` is reported so poor pose sets are visible).

This module is offline and needs no robot: feed it (q, measured_torque) pairs.
Collecting those on the real arm (bidirectional approach to cancel friction) is
a separate on-robot step.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Optional, Sequence

import numpy as np
import pinocchio as pin

# per-link gravity-observable parameters: [m, m*cx, m*cy, m*cz]
PARAMS_PER_LINK = 4


def urdf_gravity_params(model) -> "np.ndarray":
    """Prior ``phi_g`` (length 4*(njoints-1)) from the URDF inertials."""
    phi = []
    for i in range(1, model.njoints):
        inertia = model.inertias[i]
        m = float(inertia.mass)
        mc = m * np.asarray(inertia.lever)          # first moment = m * COM
        phi.extend([m, mc[0], mc[1], mc[2]])
    return np.asarray(phi, dtype=float)


def gravity_regressor(model, data, q) -> "np.ndarray":
    """``Y_g(q)`` (nv x 4*(njoints-1)): the gravity-observable columns of the
    joint-torque regressor at zero velocity/acceleration."""
    nv = model.nv
    Y = pin.computeJointTorqueRegressor(model, data, np.asarray(q, dtype=float),
                                        np.zeros(nv), np.zeros(nv))
    nb = model.njoints - 1
    cols = np.concatenate([np.arange(10 * b, 10 * b + PARAMS_PER_LINK)
                           for b in range(nb)])
    return Y[:, cols]


@dataclass
class CalibrationReport:
    n_poses: int
    n_equations: int
    n_params: int           # total parameters (4 per link)
    rank: int               # identifiable directions (< n_params: some are
                            #   gravity-unobservable and kept at the URDF prior)
    rmse: float             # N·m, residual of Y_g @ phi vs measured torque
    r_squared: float
    cond: float             # condition number of the OBSERVABLE subspace
    max_mass_change: float  # largest |m_calibrated - m_urdf| across links


def identify_gravity(
    model,
    poses_q: Sequence["np.ndarray"],
    torques: Sequence["np.ndarray"],
    *,
    dof_mask: Optional[Sequence[int]] = None,
    ridge: float = 1e-3,
) -> "tuple[np.ndarray, CalibrationReport]":
    """Identify ``phi_g`` from held-pose torques (ridge toward the URDF prior).

    ``poses_q`` are full configuration vectors; ``torques[k]`` is the measured
    holding torque at ``poses_q[k]`` (length nv). ``dof_mask`` selects which
    joint DOFs were actually measured (e.g. the 6 arm joints — the gripper /
    fingers are usually not part of the calibration); rows for other DOFs are
    dropped. ``ridge`` pulls the solution toward the URDF values along
    weakly-observed directions (larger = closer to URDF).
    """
    if len(poses_q) != len(torques):
        raise ValueError("poses_q and torques must have the same length")
    if not poses_q:
        raise ValueError("need at least one pose")

    data = model.createData()
    prior = urdf_gravity_params(model)
    mask = np.asarray(dof_mask, dtype=int) if dof_mask is not None else None

    rows_Y: List[np.ndarray] = []
    rows_b: List[np.ndarray] = []
    for q, tau in zip(poses_q, torques):
        Yg = gravity_regressor(model, data, q)
        tau = np.asarray(tau, dtype=float)
        if mask is not None:
            Yg = Yg[mask]
            tau = tau[mask]
        rows_Y.append(Yg)
        rows_b.append(tau)
    W = np.vstack(rows_Y)
    b = np.concatenate(rows_b)

    # ridge toward the prior: min ||W phi - b||^2 + ridge*||phi - prior||^2
    #   (W^T W + ridge I) phi = W^T b + ridge * prior
    n = W.shape[1]
    A = W.T @ W + ridge * np.eye(n)
    rhs = W.T @ b + ridge * prior
    phi = np.linalg.solve(A, rhs)

    resid = W @ phi - b
    rmse = float(np.sqrt(np.mean(resid ** 2)))
    ss_res = float(np.sum(resid ** 2))
    ss_tot = float(np.sum((b - b.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 1e-12 else 1.0
    # rank / observable-subspace condition number (the full W is rank-deficient:
    # some inertial params never affect gravity, so cond(W) would be inf)
    sv = np.linalg.svd(W, compute_uv=False)
    tol = sv[0] * max(W.shape) * np.finfo(float).eps
    rank = int(np.sum(sv > tol))
    cond = float(sv[0] / sv[rank - 1]) if rank > 0 else float("inf")
    max_dm = float(np.max(np.abs(phi[0::PARAMS_PER_LINK] - prior[0::PARAMS_PER_LINK])))
    report = CalibrationReport(n_poses=len(poses_q), n_equations=W.shape[0],
                               n_params=n, rank=rank, rmse=rmse, r_squared=r2,
                               cond=cond, max_mass_change=max_dm)
    return phi, report


def apply_gravity_params(model, phi_g: "np.ndarray") -> None:
    """Overwrite each link's mass + COM in ``model`` with calibrated values,
    KEEPING the URDF rotation inertia (it is gravity-unobservable). After this,
    ``pin.computeGeneralizedGravity`` / ``rnea(q,0,0)`` use the calibrated model."""
    for i in range(1, model.njoints):
        base = PARAMS_PER_LINK * (i - 1)
        m = float(phi_g[base])
        mc = np.asarray(phi_g[base + 1:base + 4], dtype=float)
        com = mc / m if abs(m) > 1e-9 else np.zeros(3)
        rot_inertia = model.inertias[i].inertia      # keep URDF rotational inertia
        model.inertias[i] = pin.Inertia(m, com, rot_inertia)


def params_to_dict(model, phi_g: "np.ndarray") -> dict:
    """Human/YAML-friendly {link_name: {mass, com:[x,y,z]}} from ``phi_g``."""
    out = {}
    for i in range(1, model.njoints):
        base = PARAMS_PER_LINK * (i - 1)
        m = float(phi_g[base])
        com = (np.asarray(phi_g[base + 1:base + 4]) / m).tolist() \
            if abs(m) > 1e-9 else [0.0, 0.0, 0.0]
        out[model.names[i]] = {"mass": m, "com": [round(c, 6) for c in com]}
    return out


def dict_to_params(model, params: dict) -> "np.ndarray":
    """Inverse of :func:`params_to_dict`: {link: {mass, com}} -> phi_g. Links
    not present keep their URDF prior (unobservable / not calibrated)."""
    phi = []
    for i in range(1, model.njoints):
        name = model.names[i]
        if name in params:
            m = float(params[name]["mass"])
            com = np.asarray(params[name]["com"], dtype=float)
            phi.extend([m, m * com[0], m * com[1], m * com[2]])
        else:
            inertia = model.inertias[i]
            m = float(inertia.mass)
            mc = m * np.asarray(inertia.lever)
            phi.extend([m, mc[0], mc[1], mc[2]])
    return np.asarray(phi, dtype=float)


def save_calibration(model, phi_g, report, path: str) -> None:
    """Write calibrated params to YAML (link masses/COMs + calibration info)."""
    import yaml
    doc = {
        "use_calibrated_params": True,
        "inertia_params": params_to_dict(model, phi_g),
        "calibration_info": {
            "n_poses": report.n_poses, "rank": report.rank,
            "rmse": round(report.rmse, 6), "r_squared": round(report.r_squared, 6),
            "cond": float(f"{report.cond:.3e}"),
        },
    }
    with open(path, "w", encoding="utf-8") as fh:
        yaml.safe_dump(doc, fh, sort_keys=False)


def load_calibration(model, path: str) -> "np.ndarray":
    """Load a YAML calibration file into a phi_g vector for ``model``."""
    import yaml
    with open(path, "r", encoding="utf-8") as fh:
        doc = yaml.safe_load(fh) or {}
    return dict_to_params(model, doc.get("inertia_params", {}))
