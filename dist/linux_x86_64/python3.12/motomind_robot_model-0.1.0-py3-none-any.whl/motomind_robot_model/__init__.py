"""motomind_robot_model — URDF-driven robot-model layer (Pinocchio).

General-purpose and independent of the motor core and of any specific robot: it
only needs a URDF. This is the Python prototype of the planned C++
``platform/native/motomind_robot_model``; the API here is what the C++ pybind
module will mirror, so callers won't change when it is ported.

M1 (implemented): dynamics.
  - ``gravity(q)`` -> generalized gravity torque G(q), with a tunable gain that
    absorbs CAD inertial error until masses are calibrated.
  - ``forward_dynamics`` / ``integrate`` -> headless simulation.
M2 (implemented): kinematics.
  - ``frame_pose(q, frame)`` -> FK: frame pose as (xyz, rpy) in the base frame.
  - ``ik(frame, xyz, rpy, q0)`` -> damped-least-squares CLIK with a free-joint
    mask (e.g. gripper fingers stay put) and URDF joint-limit clamping.
"""

from __future__ import annotations

from typing import Dict, Iterable, List, Mapping, Optional, Tuple

try:
    import numpy as np
    import pinocchio as pin
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "motomind_robot_model needs pin + numpy: uv pip install -e '.'"
    ) from exc

__all__ = ["RobotModel", "IkResult", "__version__"]
__version__ = "0.2.0"


class IkResult:
    """Outcome of :meth:`RobotModel.ik`."""

    def __init__(self, q: "np.ndarray", success: bool, pos_err: float, rot_err: float,
                 iterations: int):
        self.q = q
        self.success = success
        self.pos_err = pos_err
        self.rot_err = rot_err
        self.iterations = iterations

    def __repr__(self) -> str:  # pragma: no cover
        return (f"<IkResult success={self.success} pos_err={self.pos_err:.2e} "
                f"rot_err={self.rot_err:.2e} iters={self.iterations}>")


class RobotModel:
    """Thin wrapper over a Pinocchio model built from a URDF (fixed base)."""

    def __init__(self, urdf_path: str, *, gravity_gain: float = 1.0):
        self.urdf_path = urdf_path
        self.model = pin.buildModelFromUrdf(urdf_path)  # inertials only; meshes ignored
        self.data = self.model.createData()
        self.geom_model = None  # set by enable_self_collision()
        self.geom_data = None
        #: Scales G(q) to absorb model mass error until inertials are calibrated.
        self.gravity_gain = float(gravity_gain)
        self._qidx: Dict[str, int] = {}
        self._vidx: Dict[str, int] = {}
        for jid in range(1, self.model.njoints):
            name = self.model.names[jid]
            self._qidx[name] = self.model.joints[jid].idx_q
            self._vidx[name] = self.model.joints[jid].idx_v

    # -- introspection ------------------------------------------------------- #
    @property
    def joint_names(self) -> List[str]:
        return list(self._qidx.keys())

    @property
    def total_mass(self) -> float:
        return float(pin.computeTotalMass(self.model))

    def neutral(self) -> "np.ndarray":
        return pin.neutral(self.model)

    def q_from_joints(self, joint_positions: Mapping[str, float]) -> "np.ndarray":
        """Full configuration vector from {joint_name: q}; others default to neutral."""
        q = pin.neutral(self.model)
        for name, value in joint_positions.items():
            if name not in self._qidx:
                raise KeyError(f"unknown joint {name!r}; known: {self.joint_names}")
            q[self._qidx[name]] = float(value)
        return q

    # -- calibration --------------------------------------------------------- #
    def load_gravity_calibration(self, source) -> None:
        """Replace the URDF mass/COM with statically-calibrated values so
        ``gravity(q)`` uses MEASURED parameters. ``source`` is a YAML path or a
        {link: {mass, com}} dict (see :mod:`motomind_robot_model.calibration`).
        The rotation inertia stays at the URDF value (gravity-unobservable)."""
        from . import calibration
        if isinstance(source, str):
            phi = calibration.load_calibration(self.model, source)
        else:
            phi = calibration.dict_to_params(self.model, source)
        calibration.apply_gravity_params(self.model, phi)
        self.data = self.model.createData()   # refresh derived buffers

    # -- dynamics ------------------------------------------------------------ #
    def gravity(self, q: "np.ndarray") -> "np.ndarray":
        """Generalized gravity torque G(q) for the full model (length nv)."""
        return self.gravity_gain * pin.computeGeneralizedGravity(self.model, self.data, q)

    def gravity_by_joint(self, joint_positions: Mapping[str, float]) -> Dict[str, float]:
        """G(q) restricted to the requested joints, as {joint_name: tau}."""
        g = self.gravity(self.q_from_joints(joint_positions))
        return {name: float(g[self._vidx[name]]) for name in joint_positions}

    def forward_dynamics(
        self, q: "np.ndarray", v: "np.ndarray", tau: "np.ndarray"
    ) -> "np.ndarray":
        """Joint accelerations under applied torque (ABA) — for simulation."""
        return pin.aba(self.model, self.data, q, v, tau)

    def integrate(self, q: "np.ndarray", dv: "np.ndarray") -> "np.ndarray":
        """Configuration integration on the manifold (q ⊕ dv)."""
        return pin.integrate(self.model, q, dv)

    # -- kinematics (M2) ------------------------------------------------------ #
    def frame_id(self, frame: str) -> int:
        if not self.model.existFrame(frame):
            raise KeyError(f"unknown frame {frame!r}; e.g. link frames: "
                           f"{[f.name for f in self.model.frames if f.type == pin.FrameType.BODY]}")
        return self.model.getFrameId(frame)

    def frame_pose(self, q: "np.ndarray", frame: str) -> Tuple["np.ndarray", "np.ndarray"]:
        """FK: pose of ``frame`` in the base frame as (xyz[m], rpy[rad])."""
        fid = self.frame_id(frame)
        pin.framesForwardKinematics(self.model, self.data, q)
        M = self.data.oMf[fid]
        return M.translation.copy(), pin.rpy.matrixToRpy(M.rotation).copy()

    def ik(
        self,
        frame: str,
        target_xyz,
        target_rpy,
        q0: Optional["np.ndarray"] = None,
        *,
        free_joints: Optional[Iterable[str]] = None,
        max_iters: int = 600,
        tol_pos: float = 1e-4,
        tol_rot: float = 1e-3,
        damping: float = 1e-4,
        step: float = 0.8,
    ) -> IkResult:
        """Damped-least-squares CLIK to reach a frame pose.

        ``free_joints`` limits which joints may move (default: all) — e.g. the
        six arm joints, so gripper fingers stay put. Joint limits from the URDF
        are clamped every iteration. Seeding ``q0`` from the current measured
        configuration picks the nearest solution branch; the defaults
        (damping=1e-4, step=0.8) were tuned to also converge from far seeds
        (10/10 random reachable poses from the zero pose on Milly).
        """
        fid = self.frame_id(frame)
        q = self.neutral() if q0 is None else np.asarray(q0, dtype=float).copy()
        rpy = np.asarray(target_rpy, dtype=float)
        target = pin.SE3(pin.rpy.rpyToMatrix(rpy[0], rpy[1], rpy[2]),
                         np.asarray(target_xyz, dtype=float))

        mask = np.zeros(self.model.nv, dtype=bool)
        names = list(free_joints) if free_joints is not None else self.joint_names
        for name in names:
            if name not in self._vidx:
                raise KeyError(f"unknown joint {name!r}; known: {self.joint_names}")
            mask[self._vidx[name]] = True

        lower = self.model.lowerPositionLimit
        upper = self.model.upperPositionLimit
        pos_err = rot_err = float("inf")
        for it in range(max_iters):
            pin.framesForwardKinematics(self.model, self.data, q)
            M = self.data.oMf[fid]
            pos_err = float(np.linalg.norm(M.translation - target.translation))
            rot_err = float(np.linalg.norm(
                pin.log3(M.rotation.T @ target.rotation)))
            if pos_err < tol_pos and rot_err < tol_rot:
                return IkResult(q, True, pos_err, rot_err, it)

            iMd = M.actInv(target)
            err = pin.log(iMd).vector
            J = pin.computeFrameJacobian(self.model, self.data, q, fid)
            J = -pin.Jlog6(iMd.inverse()) @ J
            J[:, ~mask] = 0.0
            v = -J.T @ np.linalg.solve(J @ J.T + damping * np.eye(6), err)
            v[~mask] = 0.0
            q = pin.integrate(self.model, q, v * step)
            q = np.clip(q, lower, upper)

        return IkResult(q, False, pos_err, rot_err, max_iters)

    # -- self-collision (exact meshes via coal/hpp-fcl) ----------------------- #
    def enable_self_collision(self, package_dirs, baseline_qs=None) -> Tuple[int, int]:
        """Load the URDF collision meshes and arm exact self-collision checks.

        CAD models genuinely overlap at joint interfaces (motors sit inside the
        neighbouring link frames), so every pair that already collides at the
        ``baseline_qs`` configurations (default: the neutral pose — must be a
        physically valid pose) is disabled; only NEW contacts count afterwards.
        Returns (active_pairs, disabled_pairs).
        """
        geom = pin.buildGeomFromUrdf(self.model, self.urdf_path,
                                     pin.GeometryType.COLLISION,
                                     package_dirs=list(package_dirs))
        geom.addAllCollisionPairs()
        gdata = pin.GeometryData(geom)

        baseline = set()
        for q in (baseline_qs if baseline_qs is not None else [self.neutral()]):
            pin.computeCollisions(self.model, self.data, geom, gdata, q, False)
            for k, res in enumerate(gdata.collisionResults):
                if res.isCollision():
                    p = geom.collisionPairs[k]
                    baseline.add((p.first, p.second))
        for first, second in baseline:
            geom.removeCollisionPair(pin.CollisionPair(first, second))

        self.geom_model = geom
        self.geom_data = pin.GeometryData(geom)
        return len(geom.collisionPairs), len(baseline)

    def self_collides(self, q: "np.ndarray") -> bool:
        """True if any non-baseline link pair collides at ``q`` (stops at the
        first hit). Requires :meth:`enable_self_collision`."""
        if self.geom_model is None:
            raise RuntimeError("call enable_self_collision(package_dirs) first")
        return bool(pin.computeCollisions(self.model, self.data, self.geom_model,
                                          self.geom_data, q, True))

    def colliding_pairs(self, q: "np.ndarray") -> List[Tuple[str, str]]:
        """Names of the link pairs in collision at ``q`` (for diagnostics)."""
        if self.geom_model is None:
            raise RuntimeError("call enable_self_collision(package_dirs) first")
        pin.computeCollisions(self.model, self.data, self.geom_model,
                              self.geom_data, q, False)
        out = []
        for k, res in enumerate(self.geom_data.collisionResults):
            if res.isCollision():
                p = self.geom_model.collisionPairs[k]
                out.append((self.geom_model.geometryObjects[p.first].name,
                            self.geom_model.geometryObjects[p.second].name))
        return out

    def first_new_self_collision_on_path(
        self,
        q_start: "np.ndarray",
        q_target: "np.ndarray",
        *,
        max_joint_step: float = 0.05,
    ) -> Optional[Tuple[float, List[Tuple[str, str]]]]:
        """First newly introduced self-collision on a straight joint path.

        The returned tuple is ``(progress, pairs)`` where progress is in
        ``[0, 1]``. Contacts already present at ``q_start`` are ignored so an
        arm can move away from an existing contact; only new pairs reject the
        path. Collision geometry must first be enabled with
        :meth:`enable_self_collision`.
        """
        if max_joint_step <= 0.0:
            raise ValueError("max_joint_step must be positive")
        start = np.asarray(q_start, dtype=float)
        target = np.asarray(q_target, dtype=float)
        if start.shape != target.shape:
            raise ValueError("q_start and q_target must have the same shape")

        start_pairs = set(self.colliding_pairs(start))
        max_delta = float(np.max(np.abs(target - start)))
        samples = max(1, int(np.ceil(max_delta / max_joint_step)))
        for index in range(samples + 1):
            progress = index / samples
            q = (1.0 - progress) * start + progress * target
            pairs = set(self.colliding_pairs(q))
            new_pairs = pairs - start_pairs
            if new_pairs:
                return progress, sorted(new_pairs)
        return None
