"""ModeSupervisor — the single, always-on writer of motor commands.

Plays the role Piper's controller firmware plays: once started, ONE streaming
thread continuously feeds the control loop, so

- the arm HOLDS its pose after any motion finishes (no 100 ms dead-man latch),
- keepalive threads and per-call streaming loops become unnecessary,
- mode changes are safe by construction (every transition ramps).

Modes
-----
HOLD   keep a target pose with the arm's kp/kd (entered with a gain ramp so
       the arm stiffens smoothly instead of snapping).
FLOAT  gravity-compensated drag/teach: kp=0, kd=hold_kd, tff=scale*G(q)
       (entered with a torque ramp — the mirror-example logic, promoted).
TRACK  follow an externally planned trajectory (move_j/move_p feed this);
       when the trajectory ends the supervisor latches its final target and
       returns to HOLD — command-continuous, no step.
MIT    stream the latest per-motor MIT command (move_mit). Motors without an
       MIT command HOLD their measured pose when MIT mode starts.

The supervisor never fights the safety chain: if the manager leaves Running
(fault -> damping latch), streaming stops immediately and the yaml reaction
stays in charge. Users normally never see this class — Arm wraps it.
"""

from __future__ import annotations

import enum
import logging
import threading
import time
from typing import Callable, Dict, Optional

from ._core import MotorCommand, MotorManager, MotorManagerState

log = logging.getLogger("motomind_milly.supervisor")

DEFAULT_RATE_HZ = 100.0
# Streaming rate is tunable but bounded: below ~20 Hz the 100 ms dead-man
# (command_update_timeout) can trip between updates; above ~500 Hz there is no
# benefit and it just loads the CPU/CAN bus. The control-loop CAN send rate is
# a separate setting (start_control_loop).
MIN_RATE_HZ = 20.0
MAX_RATE_HZ = 500.0
HOLD_RAMP_S = 1.5     # gain ramp when (re)entering HOLD from limp states
FLOAT_RAMP_S = 2.0    # torque ramp when entering FLOAT
MAX_FLOAT_SCALE = 1.5  # >1.0 OVER-compensates gravity (arm rises on its own);
#                        capped so a typo can't send the arm flying


class Mode(enum.Enum):
    HOLD = "hold"
    FLOAT = "float"
    TRACK = "track"
    MIT = "mit"


class ModeSupervisor:
    """Single-writer command streamer with a mode state machine.

    ``gravity`` is anything with ``compute() -> List[MotorCommand]`` (normally
    a :class:`~motomind_milly.gravity_comp.GravityCompensator`); FLOAT is
    refused without it.
    """

    def __init__(
        self,
        manager: MotorManager,
        joint_ids,                       # all configured motor ids (arm + gripper)
        *,
        kp: Optional[Dict[int, float]] = None,   # per-motor HOLD gains
        kd: Optional[Dict[int, float]] = None,
        bounds: Optional[Dict[int, tuple]] = None,
        gravity=None,
        rate_hz: float = DEFAULT_RATE_HZ,
    ):
        self._m = manager
        self._joint_ids = list(joint_ids)
        self._kp = dict(kp or {})
        self._kd = dict(kd or {})
        self._float_kd: Dict[int, float] = {}   # per-motor FLOAT damping override
        self._float_kp: Dict[int, float] = {}   # per-motor FLOAT stiffness override
        self._bounds = dict(bounds or {})
        self._gravity = gravity
        if not MIN_RATE_HZ <= float(rate_hz) <= MAX_RATE_HZ:
            raise ValueError(
                f"supervisor rate_hz must be within [{MIN_RATE_HZ:g}, "
                f"{MAX_RATE_HZ:g}] Hz, got {rate_hz}")
        self._period = 1.0 / float(rate_hz)

        self._lock = threading.Lock()
        self._mode = Mode.HOLD
        self._ramp_start = 0.0
        self._ramp_s = HOLD_RAMP_S
        self._float_scale = 1.0
        self._hold_target: Dict[int, float] = {}
        self._track_provider: Optional[
            Callable[[float], Optional[Dict[int, float]]]] = None
        self._track_t0 = 0.0
        self._track_done = threading.Event()
        self._mit_commands: Dict[int, MotorCommand] = {}

        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        # one motion at a time: concurrent move requests are refused loudly
        # instead of silently preempting each other
        self._motion_lock = threading.Lock()

    # ------------------------------------------------------------------ API
    @property
    def mode(self) -> Mode:
        return self._mode

    def hold_targets(self) -> Dict[int, float]:
        """Currently commanded/held targets (for command-continuous planning)."""
        with self._lock:
            return dict(self._hold_target)

    def set_target(self, motor_id: int, position: float, *,
                   kp: Optional[float] = None, kd: Optional[float] = None) -> None:
        """Set ONE motor's held target (e.g. the gripper). It is streamed every
        tick — in HOLD, TRACK and FLOAT alike (non-arm motors always hold) — so
        the gripper follows this position via its kp/kd impedance regardless of
        what the arm is doing. Optional kp/kd override its gains."""
        with self._lock:
            self._hold_target[motor_id] = float(position)
            if kp is not None:
                self._kp[motor_id] = float(kp)
            if kd is not None:
                self._kd[motor_id] = float(kd)

    def resume_pose(self) -> Dict[int, float]:
        """Where the next planned move should START from for a no-jump
        transition. HOLD/TRACK: the commanded hold target (avoids the PD-sag
        step). FLOAT: the MEASURED position — the arm was compliant (kp=0) and
        may have moved, so the next move must begin where it ACTUALLY is, not
        where it was before FLOAT."""
        if self._mode in (Mode.FLOAT, Mode.MIT):
            want = set(self._joint_ids)
            return {s.id: s.position for s in self._m.states() if s.id in want}
        with self._lock:
            return dict(self._hold_target)

    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        """Begin streaming. Requires the manager to be Running; the current
        measured pose becomes the HOLD target and gains ramp up from zero
        (soft-start — no snap even if the arm rests away from any target)."""
        if self.running():
            return
        if self._m.state() != MotorManagerState.Running:
            raise RuntimeError(
                f"supervisor needs Running (got {self._m.state()}) — call "
                "enable() and start_control_loop() first")
        fb = {s.id: s.position for s in self._m.states()}
        with self._lock:
            self._hold_target = {mid: fb.get(mid, 0.0) for mid in self._joint_ids}
            self._mit_commands.clear()
            self._mode = Mode.HOLD
            self._ramp_start = time.monotonic()
            self._ramp_s = HOLD_RAMP_S
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name="mode_supervisor", daemon=True)
        self._thread.start()
        log.info("supervisor started: HOLD at measured pose (gain ramp %.1fs)",
                 HOLD_RAMP_S)

    def stop(self) -> None:
        """Stop streaming (the dead-man will then latch per the yaml rules
        unless the caller stops the control loop first)."""
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None

    # -- mode requests (thread-safe, ramped) --------------------------------- #
    def _refuse_if_moving(self, what: str) -> None:
        if self._mode is Mode.TRACK:
            raise RuntimeError(
                f"{what} refused: motion in progress — wait for the current "
                "move to finish")

    def hold(self) -> None:
        """HOLD the current measured pose (smooth: gains ramp up)."""
        self._refuse_if_moving("hold")
        fb = {s.id: s.position for s in self._m.states()}
        with self._lock:
            self._hold_target = {mid: fb.get(mid, self._hold_target.get(mid, 0.0))
                                 for mid in self._joint_ids}
            self._mit_commands.clear()
            self._mode = Mode.HOLD
            self._ramp_start = time.monotonic()
            self._ramp_s = HOLD_RAMP_S
        log.info("mode -> HOLD (latched measured pose, %.1fs gain ramp)",
                 HOLD_RAMP_S)

    def float_(self, scale: float = 1.0) -> None:
        """FLOAT (gravity-compensated drag). Torque ramps in over %.1fs.""" \
            % FLOAT_RAMP_S
        if self._gravity is None:
            raise RuntimeError(
                "FLOAT needs gravity compensation — attach a robot model "
                "(set_robot_model) so a GravityCompensator can be built")
        if not 0.0 <= scale <= MAX_FLOAT_SCALE:
            raise ValueError(
                f"float scale must be within [0, {MAX_FLOAT_SCALE}], got {scale}")
        self._refuse_if_moving("float")
        with self._lock:
            self._float_scale = float(scale)
            self._mit_commands.clear()
            self._mode = Mode.FLOAT
            self._ramp_start = time.monotonic()
            self._ramp_s = FLOAT_RAMP_S
        log.info("mode -> FLOAT (scale %.2f, %.1fs torque ramp)", scale,
                 FLOAT_RAMP_S)
        if scale > 1.0:
            log.warning("FLOAT scale %.2f > 1.0 OVER-compensates gravity — the "
                        "arm will tend to rise on its own; keep a hand on it", scale)

    def set_mit_command(self, command: MotorCommand) -> bool:
        """Enter MIT mode or update one motor's persistent MIT command.

        This is deliberately an update to the supervisor's command state, not
        a direct CAN write. The supervisor sends the latest command every tick
        while every other configured motor holds its pose. A later
        :meth:`hold`, :meth:`float_`, or planned trajectory leaves MIT mode.
        """
        motor_id = int(command.id)
        if motor_id not in self._joint_ids:
            raise ValueError(
                f"MIT command motor {motor_id} is not configured; "
                f"motors: {self._joint_ids}")
        self._refuse_if_moving("move_mit")

        fb = {s.id: s.position for s in self._m.states()}
        entered_mit = False
        with self._lock:
            if self._mode is not Mode.MIT:
                # A FLOAT arm may have been moved by hand. Capture every
                # measured pose before stiffening the non-MIT motors so this
                # mode transition cannot command them back to an old pose.
                self._hold_target = {
                    mid: fb.get(mid, self._hold_target.get(mid, 0.0))
                    for mid in self._joint_ids
                }
                self._mit_commands.clear()
                self._mode = Mode.MIT
                self._ramp_start = time.monotonic()
                self._ramp_s = HOLD_RAMP_S
                entered_mit = True
            # Do not retain the pybind object that set_commands may let the
            # safety chain clamp in-place. The next supervisor tick must start
            # from the caller's requested values again.
            self._mit_commands[motor_id] = MotorCommand(
                id=motor_id,
                position=float(command.position),
                velocity=float(command.velocity),
                kp=float(command.kp),
                kd=float(command.kd),
                torque_feedforward=float(command.torque_feedforward),
            )
        if entered_mit:
            log.info("mode -> MIT (other motors HOLD)")
        return True

    def set_gravity_gain(self, motor_id: int, gain: float) -> bool:
        """Live-trim ONE joint's gravity feedforward multiplier (FLOAT). Returns
        False if no gravity model is attached."""
        if self._gravity is None:
            return False
        self._gravity.set_gain(int(motor_id), float(gain))
        return True

    def set_float_kd(self, motor_id: int, kd: float) -> None:
        """Per-joint FLOAT damping override (replaces the default hold_kd for
        that joint while FLOATing) — lower it if a distal joint feels too
        damped/sticky to drag. Takes effect on the next tick."""
        with self._lock:
            self._float_kd[int(motor_id)] = max(0.0, float(kd))

    def float_kd(self) -> Dict[int, float]:
        """Current per-joint FLOAT damping overrides {motor_id: kd}."""
        return dict(self._float_kd)

    def set_float_kp(self, motor_id: int, kp: float) -> None:
        """Per-joint FLOAT stiffness override — mainly to soften the GRIPPER,
        which otherwise holds at its full kp and feels stiff while teaching (arm
        joints are already kp=0 in FLOAT). Takes effect on the next tick."""
        with self._lock:
            self._float_kp[int(motor_id)] = max(0.0, float(kp))

    def float_kp(self) -> Dict[int, float]:
        """Current per-joint FLOAT stiffness overrides {motor_id: kp}."""
        return dict(self._float_kp)

    def run_trajectory(self, traj, target: Dict[int, float]) -> float:
        """Blocking TRACK: stream ``traj`` (an object with ``sample(t)`` and
        ``done(t)``), then HOLD at ``target``. Command-continuous at both ends
        (trajectories must start at the currently commanded pose). Returns the
        elapsed time [s]."""
        if not self._motion_lock.acquire(blocking=False):
            raise RuntimeError(
                "motion in progress — one move at a time (wait for the "
                "current move_j/move_p to finish)")
        done = self._track_done
        done.clear()

        # capped-dt sampling: a stalled caller thread must pause the motion,
        # never jump it (same rule as everywhere else in this SDK)
        state = {"t": 0.0, "last": time.monotonic()}

        def provider(_now: float) -> Optional[Dict[int, float]]:
            now = time.monotonic()
            state["t"] += min(now - state["last"], 5 * self._period)
            state["last"] = now
            if traj.done(state["t"]):
                return None
            return traj.sample(state["t"])

        try:
            with self._lock:
                self._track_provider = provider
                self._mit_commands.clear()
                self._mode = Mode.TRACK
            t0 = time.monotonic()
            while not done.wait(timeout=0.05):
                if self._stop.is_set() or not self.running():
                    raise RuntimeError("supervisor stopped during trajectory")
                if self._m.state() != MotorManagerState.Running:
                    raise RuntimeError(
                        "manager left Running during trajectory (fault) — the "
                        "yaml reaction is in charge now")
            with self._lock:
                # HOLD exactly at the trajectory's end target: continuous, no
                # ramp (update, not replace — non-arm motors keep their pose)
                self._hold_target.update(target)
                self._mode = Mode.HOLD
                self._ramp_start = 0.0      # full gains immediately
            return time.monotonic() - t0
        finally:
            self._motion_lock.release()

    # ------------------------------------------------------------------ loop
    def _ramp_factor(self) -> float:
        if self._ramp_start <= 0.0:
            return 1.0
        elapsed = time.monotonic() - self._ramp_start
        return max(0.0, min(1.0, elapsed / self._ramp_s))

    def _commands_hold(self, factor: float):
        cmds = []
        for mid in self._joint_ids:
            pos = self._hold_target.get(mid, 0.0)
            lo, hi = self._bounds.get(mid, (pos, pos))
            pos = min(max(pos, lo), hi)
            cmds.append(MotorCommand(
                id=mid, position=pos,
                kp=factor * self._kp.get(mid, 15.0),
                kd=max(0.2, factor * self._kd.get(mid, 1.0))))
        return cmds

    def _commands_float(self, factor: float):
        cmds = self._gravity.compute()      # ARM joints only (has a gravity model)
        scale = factor * self._float_scale
        for cmd in cmds:
            cmd.torque_feedforward *= scale
            if cmd.id in self._float_kd:    # per-joint FLOAT damping override
                cmd.kd = self._float_kd[cmd.id]
            if cmd.id in self._float_kp:    # per-joint FLOAT stiffness override
                cmd.kp = self._float_kp[cmd.id]
        # Motors without a gravity model (e.g. the gripper) get NO command from
        # compute(). They must still be commanded every tick, or their
        # command_update_timeout trips and faults the whole arm. HOLD them —
        # softened by any FLOAT kp/kd override (the gripper is stiff otherwise).
        covered = {cmd.id for cmd in cmds}
        for mid in self._joint_ids:
            if mid not in covered:
                pos = self._hold_target.get(mid, 0.0)
                lo, hi = self._bounds.get(mid, (pos, pos))
                cmds.append(MotorCommand(
                    id=mid, position=min(max(pos, lo), hi),
                    kp=self._float_kp.get(mid, self._kp.get(mid, 15.0)),
                    kd=self._float_kd.get(mid, self._kd.get(mid, 1.0))))
        return cmds

    def _commands_mit(self, factor: float):
        """One supervisor-owned MIT command per selected motor; HOLD the rest."""
        cmds = self._commands_hold(factor)
        with self._lock:
            mit = dict(self._mit_commands)
        by_id = {cmd.id: i for i, cmd in enumerate(cmds)}
        for motor_id, command in mit.items():
            # Make a new command each tick. Core safety plugins may adjust the
            # outgoing instance, but must never mutate the requested MIT state.
            cmds[by_id[motor_id]] = MotorCommand(
                id=motor_id,
                position=command.position,
                velocity=command.velocity,
                kp=command.kp,
                kd=command.kd,
                torque_feedforward=command.torque_feedforward,
            )
        return cmds

    def _run(self) -> None:
        while not self._stop.is_set():
            if self._m.state() != MotorManagerState.Running:
                # a fault reaction (damping latch) owns the motors now; do not
                # fight it — stop streaming and let the watcher/logs report
                log.warning("supervisor: manager is %s — streaming stops",
                            self._m.state())
                self._track_done.set()
                return
            with self._lock:
                mode = self._mode
                provider = self._track_provider
                factor = self._ramp_factor()
            try:
                if mode is Mode.TRACK and provider is not None:
                    targets = provider(time.monotonic())
                    if targets is None:
                        self._track_done.set()   # run_trajectory latches HOLD
                        time.sleep(self._period)
                        continue
                    cmds = []
                    for mid in self._joint_ids:
                        pos = targets.get(mid, self._hold_target.get(mid, 0.0))
                        lo, hi = self._bounds.get(mid, (pos, pos))
                        cmds.append(MotorCommand(
                            id=mid, position=min(max(pos, lo), hi),
                            kp=self._kp.get(mid, 15.0),
                            kd=self._kd.get(mid, 1.0)))
                    self._m.set_commands(cmds)
                elif mode is Mode.FLOAT:
                    self._m.set_commands(self._commands_float(factor))
                elif mode is Mode.MIT:
                    self._m.set_commands(self._commands_mit(factor))
                else:
                    self._m.set_commands(self._commands_hold(factor))
            except Exception:
                log.exception("supervisor stream error")
            time.sleep(self._period)
