"""Robot identity via the Milly LED/button board.

Protocol: ``milly_button_can_protocol_upper_controller_ko.md``
(revision ``fixed-feedback-id-v2``). The board is a virtual RS06-style node at
fixed extended-ID target ``0xFD``; its Type ``0x02`` feedback ID never changes
with state — button/LED/active-report live in the payload only. Type ``0x1A``
info pages expose boot info, the MCU UID (factory internal — never shown to
users) and the factory product ID (pages 5/6, e.g. ``MILLY_6TG5``) which is
engraved on the robot and is the user-facing robot identity.

    import motomind_milly
    motomind_milly.list_robots()
    # [RobotId(name='MILLY_6TG5', interface='can0', ...)]

or from a shell (bus up first: ``sudo ip link set can0 up type can bitrate 1000000``):

    .venv/bin/motomind-milly-robots

Only the two bottom transport functions are OS-specific (Linux SocketCAN via
the stdlib here); the protocol encode/decode is pure and shared, so a Windows
transport can slot in later without touching the rest.
"""

from __future__ import annotations

import logging
import re
import socket
import struct
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

log = logging.getLogger("motomind_milly.identity")

BUTTON_NODE_ID = 0xFD          # compile-time fixed virtual target ID of the board
DEFAULT_HOST_ID = 0xA5         # host byte we use for requests
INFO_TYPE = 0x1A               # boot/app/UID/product-id info read
FEEDBACK_TYPE = 0x02           # feedback; ID is FIXED, state is payload-only
FEEDBACK_ROUTE = 0x00          # route byte of every Type 0x02 feedback
MIT_TYPE = 0x01                # one-shot feedback request

INFO_PAGE_BOOT = 0
INFO_PAGE_UID_LO = 3           # UID word 0 + word 1 (factory internal)
INFO_PAGE_UID_HI = 4           # UID word 2
INFO_PAGE_PRODUCT_LO = 5       # product ID ASCII bytes 0..7
INFO_PAGE_PRODUCT_HI = 6       # product ID ASCII bytes 8..15 (NUL padded)

_CAN_FRAME_FMT = "=IB3x8s"     # struct can_frame (id, dlc, pad, data)
_ARPHRD_CAN = 280              # /sys/class/net/<if>/type for CAN devices

#: Linux talks SocketCAN; every other OS talks straight gs_usb (pyusb) to the
#: module. Logical interface names stay "can0"/"can1" on both, so the
#: user-facing API and all docs are OS-independent.
_USE_SOCKETCAN = sys.platform.startswith("linux")


# --------------------------------------------------------------------------- #
# Pure protocol encode / decode (OS independent, unit tested)
# --------------------------------------------------------------------------- #
def build_info_request(page: int, host: int = DEFAULT_HOST_ID) -> Tuple[int, bytes]:
    """(extended_id, data) for a Type 0x1A info-page read addressed to the board."""
    can_id = (INFO_TYPE << 24) | ((host & 0xFF) << 8) | BUTTON_NODE_ID
    return can_id, bytes([page & 0xFF]) + bytes(7)


def info_response_id(page: int, host: int = DEFAULT_HOST_ID) -> int:
    """Extended ID the board answers a Type 0x1A page read with."""
    return (INFO_TYPE << 24) | ((page & 0xFF) << 16) | (BUTTON_NODE_ID << 8) | (host & 0xFF)


def build_feedback_request(host: int = DEFAULT_HOST_ID) -> Tuple[int, bytes]:
    """(extended_id, data) of the recommended one-shot Type 0x01 request."""
    can_id = (MIT_TYPE << 24) | (0x80 << 16) | ((host & 0xFF) << 8) | BUTTON_NODE_ID
    return can_id, bytes([0x80, 0x00, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00])


def feedback_id(host: int = DEFAULT_HOST_ID) -> int:
    """The board's FIXED Type 0x02 feedback ID for ``host`` (state-independent)."""
    return (FEEDBACK_TYPE << 24) | (FEEDBACK_ROUTE << 16) \
        | (BUTTON_NODE_ID << 8) | (host & 0xFF)


def is_feedback_id(can_id: int) -> bool:
    """True if ``can_id`` is a Type 0x02 frame from the button board.

    The route byte must be 0x00: state is never encoded in the ID (v2), and
    this also rejects real motor feedback (whose data field carries the motor
    id in that byte).
    """
    return ((can_id >> 24) & 0x1F) == FEEDBACK_TYPE \
        and ((can_id >> 16) & 0xFF) == FEEDBACK_ROUTE \
        and ((can_id >> 8) & 0xFF) == BUTTON_NODE_ID


def parse_feedback(data: bytes) -> Dict[str, int]:
    """Button/LED/report state from the 8-byte Type 0x02 payload (v2:
    payload-only — the ID carries no state)."""
    if len(data) < 8:
        raise ValueError("Type 0x02 feedback payload must be 8 bytes")
    return {
        "button_state": data[2] & 0x03,
        "led_fault": data[3] & 0x01,      # 1 = red/fault, 0 = sky-blue/normal
        "active_report_enabled": int(data[4] != 0),
        "temperature_deci_c": (data[6] << 8) | data[7],
    }


def assemble_uid(page3_data: bytes, page4_data: bytes) -> str:
    """96-bit MCU UID hex from info pages 3/4 — FACTORY INTERNAL. The SDK
    never displays this; users identify robots by the engraved product ID."""
    if len(page3_data) < 8 or len(page4_data) < 4:
        raise ValueError("info pages must carry 8 bytes of data")
    return (bytes(page3_data[:8]) + bytes(page4_data[:4])).hex()


def assemble_product_id(page5_data: bytes, page6_data: bytes) -> Optional[str]:
    """Factory product ID (e.g. ``MILLY_6TG5``) from info pages 5/6 —
    16 ASCII bytes, NUL padded. None if unprogrammed (all zero)."""
    raw = (bytes(page5_data[:8]) + bytes(page6_data[:8])).split(b"\x00", 1)[0]
    if not raw:
        return None
    try:
        return raw.decode("ascii")
    except UnicodeDecodeError:
        return None


def parse_boot_info(page0_data: bytes) -> Dict[str, int]:
    """Decode info page 0 (bootloader query mirror)."""
    return {
        "format_version": page0_data[0],
        "boot_info_valid": page0_data[1],
        "boot_protocol": page0_data[2],
        "boot_node_id": page0_data[3],
        "app_max_size": struct.unpack("<I", bytes(page0_data[4:8]))[0],
    }


# --------------------------------------------------------------------------- #
# Linux SocketCAN transport (the only OS-specific part, stdlib only)
# --------------------------------------------------------------------------- #
def list_can_interfaces() -> List[str]:
    """Names of all CAN interfaces on this machine (up or down)."""
    if not _USE_SOCKETCAN:
        from . import gsusb_transport
        return gsusb_transport.list_channels()
    found = []
    for dev in sorted(Path("/sys/class/net").glob("*")):
        try:
            if int((dev / "type").read_text()) == _ARPHRD_CAN:
                found.append(dev.name)
        except (OSError, ValueError):
            continue
    return found


def _exchange(
    interface: str,
    request_id: int,
    request_data: bytes,
    match,
    timeout_s: float = 0.3,
    retries: int = 2,
) -> Optional[Tuple[int, bytes]]:
    """Send one extended frame and return the first (id, data) where
    ``match(id)`` is true, ignoring unrelated traffic (motor feedback etc.).
    None on timeout. Raises OSError if the interface cannot be used
    (down / missing) — callers turn that into a per-interface report.
    """
    if not _USE_SOCKETCAN:
        from . import gsusb_transport
        return gsusb_transport.exchange(
            interface, request_id, request_data, match, timeout_s, retries)
    sock = socket.socket(socket.AF_CAN, socket.SOCK_RAW, socket.CAN_RAW)
    try:
        sock.bind((interface,))
        for _ in range(retries + 1):
            frame = struct.pack(
                _CAN_FRAME_FMT, request_id | socket.CAN_EFF_FLAG, 8,
                request_data.ljust(8, b"\0"))
            sock.send(frame)
            sock.settimeout(timeout_s)
            deadline_frames = 200   # bound the sift through busy-bus traffic
            for _ in range(deadline_frames):
                try:
                    raw = sock.recv(16)
                except socket.timeout:
                    break
                rid, dlc, data = struct.unpack(_CAN_FRAME_FMT, raw)
                if not rid & socket.CAN_EFF_FLAG:
                    continue
                rid &= socket.CAN_EFF_MASK
                if match(rid):
                    return rid, data[:dlc]
        return None
    finally:
        sock.close()


def read_info_page(interface: str, page: int,
                   host: int = DEFAULT_HOST_ID) -> Optional[bytes]:
    """Data of one Type 0x1A info page from the board on ``interface`` (None
    if no board answered)."""
    req_id, req_data = build_info_request(page, host)
    want = info_response_id(page, host)
    got = _exchange(interface, req_id, req_data, lambda rid: rid == want)
    return got[1] if got else None


def _read_board_uid(interface: str, host: int = DEFAULT_HOST_ID) -> Optional[str]:
    """MCU UID on ``interface`` — FACTORY INTERNAL (production traceability
    only). Deliberately private: user-facing identity is the product ID."""
    p3 = read_info_page(interface, INFO_PAGE_UID_LO, host)
    if p3 is None:
        return None
    p4 = read_info_page(interface, INFO_PAGE_UID_HI, host)
    if p4 is None:
        return None
    return assemble_uid(p3, p4)


def read_product_id(interface: str, host: int = DEFAULT_HOST_ID) -> Optional[str]:
    """The engraved product ID (e.g. ``MILLY_6TG5``) stored on the board, or
    None if no board answered / ID not programmed."""
    p5 = read_info_page(interface, INFO_PAGE_PRODUCT_LO, host)
    if p5 is None:
        return None
    p6 = read_info_page(interface, INFO_PAGE_PRODUCT_HI, host)
    if p6 is None:
        return None
    return assemble_product_id(p5, p6)


def read_button(interface: str, host: int = DEFAULT_HOST_ID,
                retries: int = 2) -> Optional[Dict[str, int]]:
    """One-shot button/LED status via a Type 0x01 feedback request."""
    req_id, req_data = build_feedback_request(host)
    want = feedback_id(host)
    got = _exchange(interface, req_id, req_data, lambda rid: rid == want,
                    retries=retries)
    return parse_feedback(got[1]) if got else None


def can_state(interface: str) -> Optional[str]:
    """Kernel CAN bus state ('ERROR-ACTIVE', 'ERROR-PASSIVE', 'BUS-OFF', ...)
    or None if it cannot be determined (non-Linux: always None — the gs_usb
    path has no netlink state; the single-frame probe rule still applies)."""
    if not _USE_SOCKETCAN:
        return None
    try:
        out = subprocess.run(
            ["ip", "-details", "link", "show", interface],
            capture_output=True, text=True, timeout=2).stdout
    except Exception:
        return None
    m = re.search(r"can state ([A-Z-]+)", out)
    return m.group(1) if m else None


def probe_channel(interface: str) -> Optional[Dict[str, int]]:
    """Gently check one CAN channel for a button board.

    Sending on a channel with NO nodes leaves an un-ACKed frame retransmitting
    in the CAN controller and drives the channel toward bus-off — on the
    2-channel USB-CAN module that can wedge the OTHER channel too. So:

    1. skip channels that are already not ERROR-ACTIVE,
    2. send a single request (no retries) — at most ONE frame ever goes to an
       empty bus,
    3. if unanswered and the bus state degraded, say so explicitly and stop.
    """
    state = can_state(interface)
    if state is not None and state != "ERROR-ACTIVE":
        log.warning("%s: bus state %s — not probing. If this channel is "
                    "unused, keep it down: sudo ip link set %s down",
                    interface, state, interface)
        return None
    fb = read_button(interface, retries=0)
    if fb is None:
        after = can_state(interface)
        if after is not None and after != "ERROR-ACTIVE":
            log.warning("%s: no answer and bus state degraded to %s — no "
                        "nodes are ACKing on this channel (nothing connected?)."
                        " If unused, keep it down: sudo ip link set %s down",
                        interface, after, interface)
        else:
            log.info("%s: no Milly button board answered", interface)
    return fb


# --------------------------------------------------------------------------- #
# Discovery
# --------------------------------------------------------------------------- #
@dataclass
class RobotId:
    """One discovered robot. Identity is the engraved product ID (``name``);
    the MCU UID exists on the wire but is factory-internal and never exposed
    through the SDK's user-facing surfaces."""
    interface: str
    name: Optional[str]          # engraved product ID, e.g. MILLY_6TG5
    button_state: Optional[int] = None
    led_fault: Optional[int] = None

    def __repr__(self) -> str:  # pragma: no cover
        led = {0: "normal", 1: "fault", None: "?"}[self.led_fault]
        return (f"<RobotId {self.name or '(no product id)'} on {self.interface} "
                f"button={self.button_state} led={led}>")


def list_robots(interfaces: Optional[List[str]] = None) -> List[RobotId]:
    """Probe every CAN interface for a Milly button board. Interfaces that
    are down are skipped with a log line — bring them up first
    (``ip link set canX up type can bitrate 1000000``)."""
    robots: List[RobotId] = []
    for iface in interfaces if interfaces is not None else list_can_interfaces():
        try:
            fb = probe_channel(iface)
        except OSError as exc:
            log.warning("%s: cannot probe (%s) — is the interface up?", iface, exc)
            continue
        if fb is None:
            continue
        # the board answered: the channel is alive, retried reads are safe now
        robots.append(RobotId(interface=iface, name=read_product_id(iface),
                              button_state=fb["button_state"],
                              led_fault=fb["led_fault"]))
    return robots


def main() -> int:
    import argparse

    ap = argparse.ArgumentParser(
        description="Discover Milly robots on CAN buses (by engraved product ID)")
    ap.add_argument("--interface", action="append", default=None,
                    help="probe only this interface (repeatable; default: all CAN)")
    args = ap.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(message)s")
    ifaces = args.interface or ["can0"]     # 1-port product: default to can0 (--interface to override)
    if not ifaces:
        print("no CAN interfaces found on this machine")
        return 1
    print(f"probing {ifaces} for Milly robots ...")
    robots = list_robots(ifaces)
    if not robots:
        print("no robots found — check that the bus is up "
              "(sudo ip link set can0 up type can bitrate 1000000) "
              "and the LED board is powered")
        return 1
    for r in robots:
        led = "RED/fault" if r.led_fault else "sky-blue/normal"
        print(f"  {r.name or '(no product id programmed)'}  on {r.interface}   "
              f"button={r.button_state}   led={led}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
