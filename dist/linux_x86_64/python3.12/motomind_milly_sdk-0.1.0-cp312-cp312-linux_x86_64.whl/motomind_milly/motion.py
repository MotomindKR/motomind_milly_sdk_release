"""Joint-space motion planning for Piper-style move_j / move_p.

A move is planned as a time-synchronized cubic profile (all joints start and
stop together, zero velocity at both ends) and streamed to the motors in many
small steps — never one big jump.

Speed is a single intuitive knob: ``max_vel`` — the peak joint velocity in
rad/s (default 0.5, deliberately slow). The yaml velocity limits remain a hard
cap on top (effective limit = min(yaml_limit, max_vel)), and ``min_duration``
keeps even tiny moves gentle.

Duration comes from the slowest joint: a cubic profile's peak velocity is
1.5*|dq|/T, so T = max_i(1.5*|dq_i| / v_i).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Mapping

DEFAULT_MAX_VEL = 0.5   # rad/s — slow by default
MIN_DURATION_S = 1.0


def _cubic_s(tau: float) -> float:
    """Smoothstep time scaling: s(0)=0, s(1)=1, zero end velocities."""
    if tau <= 0.0:
        return 0.0
    if tau >= 1.0:
        return 1.0
    return tau * tau * (3.0 - 2.0 * tau)


@dataclass
class JointTrajectory:
    """A planned, time-parameterized joint move (positions in motor space)."""

    start: Dict[int, float]
    target: Dict[int, float]
    duration: float
    _delta: Dict[int, float] = field(init=False, repr=False)

    def __post_init__(self):
        self._delta = {mid: self.target[mid] - self.start[mid] for mid in self.target}

    def sample(self, t: float) -> Dict[int, float]:
        """Joint positions at time ``t`` (clamped to [0, duration])."""
        s = _cubic_s(t / self.duration) if self.duration > 0 else 1.0
        return {mid: self.start[mid] + self._delta[mid] * s for mid in self.target}

    def done(self, t: float) -> bool:
        return t >= self.duration


def plan_joint_move(
    start: Mapping[int, float],
    target: Mapping[int, float],
    velocity_limits: Mapping[int, float],
    *,
    max_vel: float = DEFAULT_MAX_VEL,
    min_duration: float = MIN_DURATION_S,
) -> JointTrajectory:
    """Plan a synchronized cubic move from ``start`` to ``target``.

    ``max_vel`` is the peak joint velocity [rad/s]; each joint is additionally
    hard-capped by its yaml ``velocity_limits`` entry. The slowest joint sets
    the shared duration; ``min_duration`` keeps even tiny moves gentle.
    """
    if max_vel <= 0.0:
        raise ValueError(f"max_vel must be positive, got {max_vel}")
    missing = [mid for mid in target if mid not in start]
    if missing:
        raise ValueError(f"no start position for motor(s) {missing}")

    duration = min_duration
    for mid, qf in target.items():
        v = min(abs(velocity_limits.get(mid, max_vel)), max_vel)
        if v <= 0.0:
            raise ValueError(f"non-positive velocity limit for motor {mid}")
        dq = abs(qf - start[mid])
        if dq > 0.0:
            duration = max(duration, 1.5 * dq / v)  # cubic peak vel = 1.5*dq/T

    return JointTrajectory(dict(start), dict(target), duration)
