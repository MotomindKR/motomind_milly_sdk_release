"""Core-backed SDK body (moved verbatim from __init__ for lazy loading).

Everything here needs the compiled ``_core`` extension. ``__init__`` loads
this module on first attribute access (PEP 562), so platforms without the
extension (Windows, until stage 3) can still import the package and use
discovery (``identity``)."""

from __future__ import annotations

import enum
import logging
import os
import re
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

from .identity import RobotId, list_robots  # robot serial discovery (button board)

log = logging.getLogger("motomind_milly")
log.addHandler(logging.NullHandler())

_COLLISION_PATH_MAX_STEP_RAD = 0.05
_BUTTON_MONITOR_ENABLED = False  # deployment gate: no button-triggered actions


def _milly_collision_package_dirs(urdf_path: str) -> List[str]:
    """Find the package root containing ``milly_description/meshes``.

    Collision meshes are intentionally kept out of the wheel. The release
    bundle ships them beside ``examples/``; editable SDK development has them
    in the monorepo. A non-standard installation sets
    ``MOTOMIND_MILLY_DESCRIPTION_DIR`` to its ``milly_description`` directory.
    """
    candidates: List[Path] = []
    raw_env = os.environ.get("MOTOMIND_MILLY_DESCRIPTION_DIR")
    env = Path(raw_env).expanduser() if raw_env else None
    if env is not None:
        candidates.append(env if env.name == "milly_description" else env / "milly_description")

    urdf = Path(urdf_path).resolve()
    if urdf.parent.name == "urdf":
        candidates.append(urdf.parent.parent)
    # A release user commonly keeps a small program in ``<release>/test/`` or
    # another subdirectory. Search upward to the release root instead of
    # requiring the process CWD itself to be that root.
    cwd = Path.cwd().resolve()
    candidates.extend(parent / "milly_description" for parent in (cwd, *cwd.parents))
    # Editable source-tree fallback; it is never relied on by a wheel install.
    candidates.append(
        Path(__file__).resolve().parents[4] / "ros2" / "src" / "milly_ros" /
        "milly_description")

    for description in candidates:
        if (description / "meshes" / "collision").is_dir():
            return [str(description.parent)]
    raise RuntimeError(
        "self-collision preflight needs milly_description/meshes. Run from the "
        "release directory (or a subdirectory) or set "
        "MOTOMIND_MILLY_DESCRIPTION_DIR to the full milly_description directory.")


def enable_logging(level="INFO") -> None:
    """Attach a console handler to the SDK logger (call once per application).

    The SDK logs everything that changes or gates user intent: lifecycle
    results, planned move summaries, clamps/adjustments (WARNING) and
    rejections (ERROR) — so a robot user can always tell what actually
    happened.
    """
    root = logging.getLogger("motomind_milly")
    if any(not isinstance(h, logging.NullHandler) for h in root.handlers):
        root.setLevel(level)
        return
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(
        "[%(asctime)s] %(name)s %(levelname)s: %(message)s", "%H:%M:%S"))
    root.addHandler(handler)
    root.setLevel(level)

from . import _core
from ._core import (  # re-export the core value/config types
    CommType,
    FaultReaction,
    Feedback,
    FsmGuards,
    FsmResult,
    LimitAction,
    MotorBusConfig,
    MotorBusDefinition,
    MotorCommand,
    MotorConfig,
    MotorLimits,
    MotorManager,
    MotorManagerState,
    MotorSafetyConfig,
    MotorState,
    RobstrideSystemConfig,
    SafetyConfig,
    SafetyPluginConfig,
    SafetySeverity,
    make_motor_manager,
)

from .gravity_comp import GravityCompensator, JointMap, resolve_urdf_joint
from .motion import DEFAULT_MAX_VEL, JointTrajectory, plan_joint_move

__version__ = _core.version()

__all__ = [
    "_core",
    "__version__",
    "log",
    "enable_logging",
    "GravityCompensator",
    "JointMap",
    "resolve_urdf_joint",
    "JointTrajectory",
    "plan_joint_move",
    "DEFAULT_MAX_VEL",
    "ArmModel",
    "RunMode",
    "CommType",
    "FaultReaction",
    "Feedback",
    "FsmGuards",
    "FsmResult",
    "LimitAction",
    "MotorBusConfig",
    "MotorBusDefinition",
    "MotorCommand",
    "MotorConfig",
    "MotorLimits",
    "MotorManager",
    "MotorManagerState",
    "MotorSafetyConfig",
    "MotorState",
    "RobstrideSystemConfig",
    "SafetyConfig",
    "SafetyPluginConfig",
    "SafetySeverity",
    "make_motor_manager",
    "make_motor",
    "default_safety_config",
    "load_config",
    "create_arm_config",
    "Arm",
    "Gripper",
    "ArmFactory",
    "milly_urdf",
]


def milly_urdf() -> str:
    """Filesystem path to the bundled Milly URDF (kinematics + base inertials).

    ``Arm.set_robot_model()`` applies the locked, factory-measured mass/COM
    calibration before FLOAT uses a model. Meshes are not bundled in the wheel
    — planned-motion collision preflight locates the full
    ``milly_description`` (URDF + meshes) shipped in the release bundle
    automatically; for a non-standard location set
    ``MOTOMIND_MILLY_DESCRIPTION_DIR``.
    """
    from importlib import resources
    return str(resources.files("motomind_milly") / "robot" / "MILLY.urdf")


class ArmModel(enum.Enum):
    """Product arm models. Milly is the first target (see plan M1/M2)."""

    MILLY = "milly"


class RunMode:
    """Robstride run modes (see config_loader run_mode mapping)."""

    MIT = 0
    POSITION = 1
    VELOCITY = 2


_RUN_MODE_ALIASES = {
    "mit": RunMode.MIT,
    "position": RunMode.POSITION,
    "pos": RunMode.POSITION,
    "velocity": RunMode.VELOCITY,
    "vel": RunMode.VELOCITY,
}

_REACTION_ATTRS = (
    "manual_fault_reaction",
    "enable_fault_reaction",
    "start_fault_reaction",
    "disable_fault_reaction",
    "communication_fault_reaction",
    "exit_reaction",
)


# --------------------------------------------------------------------------- #
# Config construction helpers
# --------------------------------------------------------------------------- #
def make_motor(
    *,
    id: int,
    joint: str,
    name: Optional[str] = None,
    bus: str = "can0",
    model: str = "ROBSTRIDE_04",
    direction: int = 1,
    required: bool = True,
    run_mode: int = RunMode.MIT,
    damping_kd: float = 0.7,
    limits: Optional[MotorLimits] = None,
) -> MotorConfig:
    """Build a :class:`MotorConfig`. ``damping_kd`` must be >= 0 (core requires it)."""
    mc = MotorConfig()
    mc.id = id
    mc.joint_name = joint
    mc.name = name or joint
    mc.bus_name = bus
    mc.model = model
    mc.direction = direction
    mc.required = required
    mc.run_mode = run_mode
    mc.safety.damping_kd = damping_kd  # `safety` is a reference — mutation sticks
    if limits is not None:
        mc.limits = limits
    return mc


def default_safety_config(
    reaction: FaultReaction = FaultReaction.DampingLatch,
    *,
    with_command_limit: bool = True,
) -> SafetyConfig:
    """A fully-configured :class:`SafetyConfig` (all reactions set) accepted by
    :func:`make_motor_manager`, which otherwise rejects unconfigured reactions."""
    s = SafetyConfig()
    for attr in _REACTION_ATTRS:
        setattr(s, attr, reaction)
        setattr(s, attr + "_configured", True)
    if with_command_limit:
        p = SafetyPluginConfig()
        p.id = "command_limit"
        p.type = "command_limit"
        p.action = LimitAction.Clamp
        p.action_configured = True
        p.severity = SafetySeverity.Warning
        p.severity_configured = True
        p.fault_reaction = reaction
        p.fault_reaction_configured = True
        s.plugins = [p]
    return s


def _reaction(name: str, field: str) -> FaultReaction:
    value = _core.parse_fault_reaction(str(name))
    if value is None:
        raise ValueError(f"Unsupported fault reaction for {field}: {name!r}")
    return value


def _severity(name: str) -> SafetySeverity:
    value = _core.parse_severity(str(name))
    if value is None:
        raise ValueError(f"Unsupported safety severity: {name!r}")
    return value


def _limit_action(name: str) -> LimitAction:
    value = _core.parse_limit_action(str(name))
    if value is None:
        raise ValueError(f"Unsupported safety limit action: {name!r}")
    return value


def _run_mode(value) -> int:
    if isinstance(value, int):
        return value
    key = str(value).strip().lower()
    if key not in _RUN_MODE_ALIASES:
        raise ValueError(f"Unsupported run_mode: {value!r}")
    return _RUN_MODE_ALIASES[key]


def _pair(seq, field: str):
    if not isinstance(seq, (list, tuple)) or len(seq) != 2:
        raise ValueError(f"Expected [min, max] for {field}, got {seq!r}")
    return float(seq[0]), float(seq[1])


def load_config(path: str) -> RobstrideSystemConfig:
    """Load a YAML actuator config into a :class:`RobstrideSystemConfig`.

    Mirrors the schema parsed by the C++ ``config_loader`` used by the ROS2
    gateway, so the SDK and the ROS2 node accept the same files. Parsing lives
    here (Python) — the frozen core is untouched.
    """
    import yaml

    with open(path, "r", encoding="utf-8") as handle:
        doc = yaml.safe_load(handle) or {}

    cfg = RobstrideSystemConfig()

    # buses: { name: { interface, host_id, command_rate_hz, enable_retries, ... } }
    buses = []
    for bus_name, bus_body in (doc.get("buses") or {}).items():
        bus_body = bus_body or {}
        bus = MotorBusDefinition()
        bus.config.name = bus_name
        bus.config.interface_name = str(bus_body.get("interface", bus_name))
        if "host_id" in bus_body:
            bus.config.host_id = int(bus_body["host_id"])
        if "command_rate_hz" in bus_body:
            bus.command_rate_hz = float(bus_body["command_rate_hz"])
        if "enable_retries" in bus_body:
            bus.config.enable_retries = int(bus_body["enable_retries"])
        if "enable_retry_delay_ms" in bus_body:
            bus.config.enable_retry_delay_ms = int(bus_body["enable_retry_delay_ms"])
        buses.append(bus)
    cfg.buses = buses

    # motors: [ { name, id, bus, model, joint, direction, run_mode, limits, safety } ]
    motors = []
    for entry in doc.get("motors") or []:
        entry = entry or {}
        mc = MotorConfig()
        if "name" in entry:
            mc.name = str(entry["name"])
        if "id" in entry:
            mc.id = int(entry["id"])
        if "bus" in entry:
            mc.bus_name = str(entry["bus"])
        if "model" in entry:
            mc.model = str(entry["model"])
        if "joint" in entry:
            mc.joint_name = str(entry["joint"])
        if "direction" in entry:
            mc.direction = 1 if int(entry["direction"]) >= 0 else -1
        if "run_mode" in entry:
            mc.run_mode = _run_mode(entry["run_mode"])
        limits_body = entry.get("limits") or {}
        limits = MotorLimits()
        if "position" in limits_body:
            limits.position_min, limits.position_max = _pair(limits_body["position"], "limits.position")
        if "velocity" in limits_body:
            limits.velocity_min, limits.velocity_max = _pair(limits_body["velocity"], "limits.velocity")
        if "torque" in limits_body:
            limits.torque_min, limits.torque_max = _pair(limits_body["torque"], "limits.torque")
        if "kp" in limits_body:
            limits.kp_min, limits.kp_max = _pair(limits_body["kp"], "limits.kp")
        if "kd" in limits_body:
            limits.kd_min, limits.kd_max = _pair(limits_body["kd"], "limits.kd")
        mc.limits = limits
        safety_body = entry.get("safety") or {}
        if "damping_kd" in safety_body:
            mc.safety.damping_kd = float(safety_body["damping_kd"])
        if "safe_position" in safety_body:
            lo, hi = _pair(safety_body["safe_position"], "safety.safe_position")
            mc.safety.safe_position_min = lo
            mc.safety.safe_position_max = hi
            mc.safety.safe_position_configured = True
        motors.append(mc)
    cfg.motors = motors

    # feedback
    fb_body = doc.get("feedback") or {}
    feedback = cfg.feedback
    if "active_reporting" in fb_body:
        feedback.active_reporting = bool(fb_body["active_reporting"])
    if "disable_active_reporting_on_exit" in fb_body:
        feedback.disable_active_reporting_on_exit = bool(
            fb_body["disable_active_reporting_on_exit"]
        )

    # safety
    safety_body = doc.get("safety") or {}
    safety = cfg.safety
    plugins = []
    for p_body in safety_body.get("plugins") or []:
        p_body = p_body or {}
        p = SafetyPluginConfig()
        if "id" in p_body:
            p.id = str(p_body["id"]).lower()
        if "type" in p_body:
            p.type = str(p_body["type"]).lower()
        if "action" in p_body:
            p.action = _limit_action(p_body["action"])
            p.action_configured = True
        if "severity" in p_body:
            p.severity = _severity(p_body["severity"])
            p.severity_configured = True
        if "timeout_ms" in p_body:
            p.timeout_ms = int(p_body["timeout_ms"])
        if "max_delta" in p_body or "max_position_delta" in p_body:
            p.max_delta = float(p_body.get("max_delta", p_body.get("max_position_delta")))
        if "threshold_c" in p_body or "threshold_temperature_c" in p_body:
            p.threshold_temperature_c = float(
                p_body.get("threshold_c", p_body.get("threshold_temperature_c"))
            )
            p.threshold_temperature_configured = True
        if "fault_reaction" in p_body:
            p.fault_reaction = _reaction(p_body["fault_reaction"], "plugin.fault_reaction")
            p.fault_reaction_configured = True
        plugins.append(p)
    safety.plugins = plugins

    reactions_body = safety_body.get("reactions") or {}
    damping = reactions_body.get("damping_latch") or {}
    if "send_count" in damping:
        safety.damping_latch_send_count = int(damping["send_count"])
    if "send_rate_hz" in damping or "rate_hz" in damping:
        safety.damping_latch_send_rate_hz = float(
            damping.get("send_rate_hz", damping.get("rate_hz"))
        )

    _load_reaction_block(safety, safety_body.get("manual_fault"), "manual_fault_reaction", "fault_reaction")
    _load_reaction_block(safety, safety_body.get("enable_fault"), "enable_fault_reaction", "fault_reaction")
    _load_reaction_block(safety, safety_body.get("start_fault"), "start_fault_reaction", "fault_reaction")
    _load_reaction_block(safety, safety_body.get("disable_fault"), "disable_fault_reaction", "fault_reaction")
    _load_reaction_block(safety, safety_body.get("communication_fault"), "communication_fault_reaction", "fault_reaction")
    _load_reaction_block(safety, safety_body.get("exit"), "exit_reaction", "reaction")

    return cfg


def _load_reaction_block(safety: SafetyConfig, body, field: str, key: str) -> None:
    if not body or key not in body:
        return
    setattr(safety, field, _reaction(body[key], field))
    setattr(safety, field + "_configured", True)


def create_arm_config(
    config_path: Optional[str] = None,
    *,
    robot: ArmModel = ArmModel.MILLY,
    interface: str = "socketcan",
    channel: str = "can0",
    bitrate: int = 1_000_000,
) -> RobstrideSystemConfig:
    """Piper-style config builder.

    Currently requires ``config_path`` (a YAML file). A bundled per-robot default
    (selected by ``robot``) will ship with M1. ``interface`` must be socketcan;
    ``bitrate`` is set at the OS level (``ip link``) and is accepted here only for
    API parity.
    """
    if interface != "socketcan":
        raise ValueError("Only interface='socketcan' is supported.")
    if config_path is None:
        raise ValueError(
            "create_arm_config currently requires config_path=<yaml>; "
            "a bundled default for each ArmModel will arrive with M1."
        )
    cfg = load_config(config_path)
    if channel and cfg.buses:
        buses = cfg.buses
        buses[0].config.name = channel
        buses[0].config.interface_name = channel
        cfg.buses = buses
    return cfg


# --------------------------------------------------------------------------- #
# Arm facade (Piper-style feel)
# --------------------------------------------------------------------------- #
class Arm:
    """High-level facade over a :class:`MotorManager`.

    Covers the low-level control family the core already provides (enable/disable,
    e-stop, MIT/joint pass-through, state readout). Cartesian motion, IK/FK and
    gravity compensation are milestones M1/M2 and raise ``NotImplementedError``.
    """

    def __init__(self, manager: MotorManager, config: Optional[RobstrideSystemConfig] = None):
        self._m = manager
        self._config = config
        self._joint_ids: List[int] = (
            [m.id for m in config.motors] if config is not None else []
        )
        self._joint_names: List[str] = (
            [m.joint_name or m.name for m in config.motors] if config is not None else []
        )
        # per-motor allowed position range and velocity limit from the yaml
        self._bounds: Dict[int, Tuple[float, float]] = {}
        self._vel_limits: Dict[int, float] = {}
        if config is not None:
            for m in config.motors:
                if m.safety.safe_position_configured:
                    self._bounds[m.id] = (m.safety.safe_position_min,
                                          m.safety.safe_position_max)
                else:
                    self._bounds[m.id] = (m.limits.position_min, m.limits.position_max)
                self._vel_limits[m.id] = abs(m.limits.velocity_max)
        self._max_vel: float = DEFAULT_MAX_VEL
        # kinematics (set via set_robot_model): motor id <-> URDF joint mapping
        self._rm = None
        self._flange = "link_6"
        self._supervisor = None
        # product path (create_arm) sets these so enable()/disable() bring the
        # supervisor up and down automatically; the ArmFactory dev path leaves
        # them off and manages the supervisor by hand.
        self._supervisor_auto = False
        self._supervisor_rate_hz = 100.0
        self._button_monitor = None
        self._button_cfg = None                # {poll_ms, on_toggle} from tuning
        self._estop_latched = False            # button e-stop: terminal, no resume
        self._arm_ids: List[int] = []          # motors mapped to URDF arm joints
        self._urdf_of: Dict[int, str] = {}     # motor id -> URDF joint name

    # -- lifecycle ----------------------------------------------------------- #
    @property
    def manager(self) -> MotorManager:
        return self._m

    def _dump_diag(self, log_fn) -> None:
        """Everything the core knows about the current (failure) state."""
        log_fn("  state=%s reaction=%s", self._m.state(),
               _core.fault_reaction_name(self._m.last_fault_reaction()))
        reason = self._m.fault_reason()
        if reason:
            log_fn("  fault_reason=%r", reason)
        for iss in self._m.last_safety_report().issues:
            log_fn("  [%s] %s: %s", _core.severity_name(iss.severity),
                   iss.plugin, iss.message)
        err = self._m.last_control_loop_error()
        if err:
            log_fn("  loop_error=%r", err)

    def _log_fsm(self, name: str, res: FsmResult) -> FsmResult:
        if res.ok:
            log.info("%s: %s", name, res.message)
        else:
            log.error("%s FAILED: %s", name, res.message)
            self._dump_diag(log.error)   # failures always carry full context
        return res

    def _start_state_watcher(self) -> None:
        """Background watcher: EVERY manager state transition is logged by the
        SDK itself — a fault can never go unreported, no matter which call
        site (or none) triggered it."""
        if getattr(self, "_watcher", None) and self._watcher.is_alive():
            return
        self._watcher_stop = threading.Event()

        def _watch():
            prev = self._m.state()
            while not self._watcher_stop.is_set():
                st = self._m.state()
                if st != prev:
                    if st == MotorManagerState.Fault:
                        log.error("STATE %s -> %s", prev, st)
                        self._dump_diag(log.error)
                    else:
                        log.info("STATE %s -> %s", prev, st)
                    prev = st
                time.sleep(0.05)

        self._watcher = threading.Thread(target=_watch, name="arm_state_watcher",
                                         daemon=True)
        self._watcher.start()

    def connect(self) -> bool:
        """Open the CAN bus(es), start the receive thread and the state watcher."""
        ok = self._m.open()
        if ok:
            log.info("connect: CAN open ok")
            self._start_state_watcher()
        else:
            ifaces = ([b.config.interface_name for b in self._config.buses]
                      if self._config is not None else [])
            log.error(
                "connect: CAN open FAILED%s — is the interface up? "
                "(sudo ip link set %s up type can bitrate 1000000; "
                "check the USB-CAN module is plugged in)",
                f" on {ifaces}" if ifaces else "",
                ifaces[0] if ifaces else "can0")
        return ok

    def disconnect(self) -> None:
        log.info("disconnect: closing CAN")
        if getattr(self, "_watcher_stop", None):
            self._watcher_stop.set()
        self._m.close()

    def enable(self) -> FsmResult:
        if self._estop_latched:
            raise RuntimeError(
                "arm was stopped by the button e-stop — this is terminal by "
                "design; restart the program to use the arm again")
        result = self._log_fsm("enable", self._m.enable())
        if not result.ok:
            if "not reachable" in result.message:
                # say WHICH motors are silent — the #1 real-world bring-up error
                fb = self._m.refresh_feedback(timeout_ms=100, retries=1)
                silent = [m.id for m in (self._config.motors if self._config else [])
                          if m.id not in fb]
                if silent:
                    log.error(
                        "  motors with NO response: %s — check motor power, CAN "
                        "wiring/termination and that ids match the config", silent)
            return result
        if self._supervisor_auto:
            # product path: bring the arm fully up and start holding its pose,
            # so a later move stays put and no dead-man latch can trip
            if self._config is not None:
                self._m.set_run_mode_for_all(self._config.motors[0].run_mode)
            can_rate = (self._config.buses[0].command_rate_hz
                        if self._config and self._config.buses else 100.0)
            loop = self.start_control_loop(can_rate)
            if not loop.ok:
                return loop
            self.start_supervisor(rate_hz=self._supervisor_rate_hz)
            if self._button_cfg is not None:
                # (re)start fresh so the baseline re-captures the button's
                # CURRENT position — after a recover()+enable(), whatever
                # position the button is in becomes the new 'normal'
                self.stop_button_monitor()
                self.start_button_monitor(**self._button_cfg)
        return result

    def disable(self) -> FsmResult:
        """Cut motor torque (-> Idle). WARNING: the arm goes limp and may DROP
        under gravity. To END A PROGRAM SAFELY use :meth:`shutdown` instead
        (it runs the yaml ``exit`` reaction — damping latch — so the arm settles
        under damping). Call ``disable()`` only when you deliberately want the
        arm to go limp and are holding it / it is in a safe pose."""
        log.warning("disable(): motor torque OFF — the arm may DROP under "
                    "gravity. To stop safely use shutdown() (damping latch).")
        self.stop_button_monitor()
        # stop the command stream BEFORE cutting torque (they are a matched pair)
        if self._supervisor is not None and self._supervisor.running():
            self._supervisor.stop()
            self._supervisor = None
        return self._log_fsm("disable", self._m.disable())

    def shutdown(self) -> FsmResult:
        """Graceful program exit: stop the supervisor, then shut down — which
        runs the yaml ``exit`` reaction (damping latch by default), so the arm
        settles under damping instead of dropping. This is the normal way to
        end a program (use ``disable()`` only when you deliberately want torque
        off / the arm to go limp)."""
        self.stop_button_monitor()
        if self._supervisor is not None and self._supervisor.running():
            self._supervisor.stop()
            self._supervisor = None
        return self._log_fsm("shutdown", self._m.shutdown())

    def recover(self) -> FsmResult:
        """Clear a fault -> Idle (de-energized; does NOT auto-re-energize). To
        resume after a general fault, call ``enable()``.

        A BUTTON e-stop is terminal: ``recover()`` refuses while the button
        latch is set — restart the program to use the arm again."""
        if self._estop_latched:
            raise RuntimeError(
                "arm was stopped by the button e-stop — this is terminal by "
                "design; restart the program to use the arm again")
        return self._log_fsm("recover", self._m.recover())

    def _button_estop(self) -> FsmResult:
        """Terminal e-stop from the button: engage the damping latch and mark
        the arm latched so enable()/recover() refuse until the program restarts.
        A button stop has no programmatic resume by design."""
        self._estop_latched = True
        return self.electronic_emergency_stop()

    def electronic_emergency_stop(self) -> FsmResult:
        """Manual e-stop. Uses the yaml ``safety.manual_fault`` reaction when a
        config is attached (default damping latch — a damped stop whose per-
        motor strength is the yaml ``damping_kd``)."""
        reaction = FaultReaction.DampingLatch
        if (self._config is not None
                and self._config.safety.manual_fault_reaction_configured):
            reaction = self._config.safety.manual_fault_reaction
        return self._log_fsm(
            f"e-stop ({_core.fault_reaction_name(reaction)})",
            self._m.fault("electronic_emergency_stop", reaction))

    def start_control_loop(self, rate_hz: float = 500.0) -> FsmResult:
        return self._log_fsm(f"start_control_loop({rate_hz:g}Hz)",
                             self._m.start_control_loop(rate_hz))

    def stop_control_loop(self) -> FsmResult:
        return self._log_fsm("stop_control_loop", self._m.stop_control_loop())

    def state(self) -> MotorManagerState:
        return self._m.state()

    # -- readback ------------------------------------------------------------ #
    def states(self) -> List[MotorState]:
        return self._m.states()

    def get_joint_angles(self) -> List[Optional[float]]:
        """Joint positions [rad] in configured motor order."""
        by_id = {s.id: s.position for s in self._m.states()}
        if not self._joint_ids:
            return [s.position for s in sorted(self._m.states(), key=lambda s: s.id)]
        return [by_id.get(jid) for jid in self._joint_ids]

    def is_ok(self) -> bool:
        """True while the manager is not faulted and reports no control-loop error."""
        return self._m.state() != MotorManagerState.Fault and not self._m.last_control_loop_error()

    # -- direct motor control (supervisor-owned) ---------------------------- #
    def move_mit(
        self,
        motor_id: int,
        *,
        position: float = 0.0,
        velocity: float = 0.0,
        kp: Optional[float] = None,
        kd: Optional[float] = None,
        torque_feedforward: float = 0.0,
    ) -> bool:
        """Set one motor's persistent MIT command through the supervisor.

        The supervisor remains the only command writer: it streams this
        command every tick while the other motors HOLD. Call ``hold_mode()``,
        ``float_mode()``, ``move_j()``, or ``move_p()`` to leave MIT mode.
        When ``kp``/``kd`` are omitted, this motor's product-profile default is
        used (``motion`` for an arm joint, ``gripper`` for the gripper).
        """
        self._require_running("move_mit")
        default_kp, default_kd = self._default_gains_for_motor(motor_id)
        return self._require_supervisor().set_mit_command(
            MotorCommand(
                id=motor_id,
                position=position,
                velocity=velocity,
                kp=default_kp if kp is None else kp,
                kd=default_kd if kd is None else kd,
                torque_feedforward=torque_feedforward,
            )
        )

    # -- kinematics & planned motion (needs set_robot_model) ---------------- #
    def set_robot_model(
        self,
        robot_model,
        flange_frame: str = "link_6",
        *,
        _load_factory_gravity_calibration: bool = True,
    ) -> None:
        """Attach a ``RobotModel`` for FK/IK and product gravity compensation.

        Config joint names are matched to URDF joints (arm prefixes like
        ``right_`` stripped automatically); the gripper stays unmapped.  The
        public default loads the locked ``milly_cal.yaml`` factory mass/COM
        calibration, because raw URDF inertials are not accurate enough for
        FLOAT.  The private keyword is for internal calibration tooling only.
        """
        if _load_factory_gravity_calibration:
            from .profile import load_factory_gravity_calibration
            load_factory_gravity_calibration(robot_model)
            log.info("factory gravity calibration loaded: milly_cal.yaml")
        self._rm = robot_model
        self._flange = flange_frame
        self._urdf_of = {}
        self._arm_ids = []
        unmapped = []
        if self._config is not None:
            for m in self._config.motors:
                uj = resolve_urdf_joint(m.joint_name, robot_model._vidx)
                if uj is not None:
                    self._urdf_of[m.id] = uj
                    self._arm_ids.append(m.id)
                else:
                    unmapped.append((m.id, m.joint_name))
        log.info("robot model attached: %d arm joints %s, flange=%s%s",
                 len(self._arm_ids),
                 {mid: self._urdf_of[mid] for mid in self._arm_ids},
                 flange_frame,
                 f", unmapped(held)={unmapped}" if unmapped else "")

    def _planned_arm_ids(self) -> List[int]:
        """Motor ids consumed by the six-value move_j/move_p APIs."""
        if self._arm_ids:
            return self._arm_ids
        if self._config is not None:
            ids = [m.id for m in self._config.motors
                   if m.joint_name != "gripper" and m.name != "gripper"]
            if ids:
                return ids
        return self._joint_ids

    def _ensure_self_collision_checker(self) -> None:
        """Lazily attach Milly kinematics and exact collision meshes.

        Planned moves fail closed when the robot-model extra or collision meshes
        are unavailable: without them the API cannot prove the path is safe.
        """
        if self._rm is None:
            try:
                from motomind_robot_model import RobotModel
            except ImportError as exc:
                raise RuntimeError(
                    "move_j/move_p self-collision preflight needs "
                    "motomind-robot-model; install the SDK robot-model wheel") from exc
            self.set_robot_model(RobotModel(milly_urdf()))
        if getattr(self._rm, "geom_model", None) is not None:
            return
        try:
            active, disabled = self._rm.enable_self_collision(
                _milly_collision_package_dirs(self._rm.urdf_path))
        except Exception as exc:
            raise RuntimeError(
                "move_j/move_p REJECTED: could not initialize self-collision "
                f"preflight ({exc})") from exc
        log.info("self-collision preflight enabled: %d pairs (%d baseline-disabled)",
                 active, disabled)

    def _reject_self_collision_path(
        self,
        start: Dict[int, float],
        target: Dict[int, float],
    ) -> None:
        """Reject a planned joint path that introduces a self-collision."""
        self._ensure_self_collision_checker()
        missing = [mid for mid in target if mid not in self._urdf_of]
        if missing:
            raise RuntimeError(
                "move_j/move_p REJECTED: self-collision preflight has no URDF "
                f"mapping for motor(s) {missing}")

        def as_model_q(positions: Dict[int, float]):
            return self._rm.q_from_joints({
                self._urdf_of[mid]: positions.get(mid, start[mid])
                for mid in target
            })

        target_q = as_model_q(target)
        hit = self._rm.first_new_self_collision_on_path(
            as_model_q(start), target_q,
            max_joint_step=_COLLISION_PATH_MAX_STEP_RAD)
        if hit is not None:
            progress, pairs = hit
            detail = pairs[:2]
            log.error("move_j REJECTED: predicted self-collision at %.1f%%: %s",
                      100.0 * progress, detail)
            raise RuntimeError(
                "move_j/move_p REJECTED: predicted self-collision at "
                f"{100.0 * progress:.1f}% of the path: {detail}")

    def set_default_gains(self, kp: Sequence[float], kd: Sequence[float]) -> None:
        """Per-joint default kp/kd for planned moves (move_j/move_p), in arm
        order (base -> wrist) — normally set from the robot's tuning file by
        :func:`create_arm`. Explicit kp=/kd= arguments still win per call."""
        ids = self._planned_arm_ids()
        n = min(len(ids), len(kp))
        self._default_kp = {mid: float(kp[i]) for i, mid in enumerate(ids[:n])}
        self._default_kd = {mid: float(kd[i]) for i, mid in enumerate(ids[:n])}

    def set_gripper_gains(self, kp: float, kd: float) -> None:
        """Default hold kp/kd for the gripper motor(s) (config joint/name
        ``gripper``) — normally set from the robot's tuning file by
        :func:`create_arm`. The supervisor streams the gripper at these gains;
        an explicit ``Gripper.move(kp=/kd=)`` still wins per call."""
        ids = [m.id for m in self._config.motors
               if m.joint_name == "gripper" or m.name == "gripper"] \
            if self._config is not None else []
        self._gripper_kp = {mid: float(kp) for mid in ids}
        self._gripper_kd = {mid: float(kd) for mid in ids}

    def _default_gains_for_motor(self, motor_id: int) -> Tuple[float, float]:
        """Profile defaults for one configured motor (arm or gripper)."""
        mid = int(motor_id)
        arm_kp = getattr(self, "_default_kp", {})
        arm_kd = getattr(self, "_default_kd", {})
        gripper_kp = getattr(self, "_gripper_kp", {})
        gripper_kd = getattr(self, "_gripper_kd", {})
        return (
            float(arm_kp.get(mid, gripper_kp.get(mid, 15.0))),
            float(arm_kd.get(mid, gripper_kd.get(mid, 1.0))),
        )

    def set_gravity_gains(self, gains: Dict[int, float]) -> None:
        """Per-joint gravity feedforward multiplier by motor id (tff =
        scale*gain*G(q)), e.g. ``{2: 1.1}`` gives joint_2 10% more compensation
        without touching the others — for when one joint sags a little at
        scale 1.0. Applied when the supervisor (re)starts; if it is already
        running in FLOAT, the change takes effect live."""
        merged = dict(getattr(self, "_gravity_gains", {}) or {})
        merged.update({int(k): float(v) for k, v in gains.items()})
        self._gravity_gains = merged
        sup = self._supervisor
        if sup is not None and sup.running():
            for mid, g in gains.items():
                sup.set_gravity_gain(int(mid), float(g))

    def set_float_kd(self, kds: Dict[int, float]) -> None:
        """Per-joint FLOAT damping override by motor id, e.g. ``{4: 0.5, 5: 0.5,
        6: 0.5}`` to make the distal joints less damped (easier to drag/teach)
        while FLOATing. Applied when the supervisor (re)starts; live if it is
        already running in FLOAT."""
        merged = dict(getattr(self, "_float_kd_overrides", {}) or {})
        merged.update({int(k): float(v) for k, v in kds.items()})
        self._float_kd_overrides = merged
        sup = self._supervisor
        if sup is not None and sup.running():
            for mid, kd in kds.items():
                sup.set_float_kd(int(mid), float(kd))

    def set_float_kp(self, kps: Dict[int, float]) -> None:
        """Per-joint FLOAT stiffness override by motor id — mainly to soften the
        GRIPPER while teaching (it otherwise holds at its full gripper_kp and
        feels stiff; arm joints are already kp=0 in FLOAT). Applied when the
        supervisor (re)starts; live if it is already running in FLOAT."""
        merged = dict(getattr(self, "_float_kp_overrides", {}) or {})
        merged.update({int(k): float(v) for k, v in kps.items()})
        self._float_kp_overrides = merged
        sup = self._supervisor
        if sup is not None and sup.running():
            for mid, kp in kps.items():
                sup.set_float_kp(int(mid), float(kp))

    # -- mode supervisor (single always-on command streamer) ----------------- #
    def start_supervisor(self, *, rate_hz: float = 100.0,
                         gravity_hold_kd: float = 1.0):
        """Start the single-writer mode supervisor (streams at ``rate_hz``,
        default 100; bounded [20, 500]). The arm HOLDS its current
        pose (soft gain ramp) and keeps holding after every motion — no
        dead-man latch between moves. move_j/move_p route through it while it
        runs. FLOAT (drag/teach) additionally needs a robot model attached."""
        from .gravity_comp import GravityCompensator
        from .mode_supervisor import ModeSupervisor
        if self._supervisor is not None and self._supervisor.running():
            return self._supervisor
        self._require_running("start_supervisor")
        gravity = None
        if self._rm is not None and self._config is not None:
            gravity = GravityCompensator.from_config(
                self._m, self._rm, self._config, hold_kd=gravity_hold_kd,
                gains=getattr(self, "_gravity_gains", None))
        # gain fallbacks: arm joints -> tuning file (_default_kp/kd), else 15/1;
        # gripper -> its tuning gains (_gripper_kp/kd from set_gripper_gains),
        # else 10/1 (a conservative gripper fallback). With no robot model attached the
        # arm ids are unknown — treat all as arm.
        arm_ids = set(self._arm_ids or self._joint_ids)
        gk = getattr(self, "_gripper_kp", {})
        gd = getattr(self, "_gripper_kd", {})
        kp = {mid: getattr(self, "_default_kp", {}).get(
                  mid, gk.get(mid, 15.0 if mid in arm_ids else 10.0))
              for mid in self._joint_ids}
        kd = {mid: getattr(self, "_default_kd", {}).get(
                  mid, gd.get(mid, 1.0))
              for mid in self._joint_ids}
        sup = ModeSupervisor(self._m, self._joint_ids, kp=kp, kd=kd,
                             bounds=self._bounds, gravity=gravity,
                             rate_hz=rate_hz)
        for mid, fkd in getattr(self, "_float_kd_overrides", {}).items():
            sup.set_float_kd(mid, fkd)
        for mid, fkp in getattr(self, "_float_kp_overrides", {}).items():
            sup.set_float_kp(mid, fkp)
        sup.start()
        self._supervisor = sup
        return sup

    def stop_supervisor(self) -> None:
        if self._supervisor is not None:
            self._supervisor.stop()
            self._supervisor = None

    # -- STM button monitor (polls the button board on a 2nd CAN socket) ------ #
    def start_button_monitor(self, *, poll_ms: int = 200,
                             on_toggle: str = "damping_latch"):
        """Start button-triggered actions (disabled in this SDK release)."""
        if not _BUTTON_MONITOR_ENABLED:
            raise RuntimeError(
                "STM button actions are disabled in this SDK release")
        from .button import ButtonMonitor
        if self._button_monitor is not None and self._button_monitor.running():
            return self._button_monitor
        if self._config is None or not self._config.buses:
            raise RuntimeError("button monitor needs a config-built Arm "
                               "(create_arm) with a known CAN interface")
        iface = self._config.buses[0].config.interface_name
        mon = ButtonMonitor(self, iface, poll_ms=poll_ms, on_toggle=on_toggle)
        mon.start()
        self._button_monitor = mon
        return mon

    def stop_button_monitor(self) -> None:
        if self._button_monitor is not None:
            self._button_monitor.stop()
            self._button_monitor = None

    def hold_mode(self) -> None:
        """HOLD the current measured pose (smooth gain ramp)."""
        self._require_supervisor().hold()

    def float_mode(self, scale: Optional[float] = None) -> None:
        """Gravity compensation ON (back-drivable drag/teach, smooth torque ramp).
        ``scale`` defaults to the robot's locked value (canonical ``gravity.scale``,
        1.0 = full comp); pass it only for dev tuning. Range [0, 1.5]: <1.0 sags a
        little (safer), >1.0 OVER-compensates (the arm rises — keep a hand on it)."""
        if scale is None:
            scale = getattr(self, "_float_scale", 1.0)
        self._require_supervisor().float_(scale)

    def _require_supervisor(self):
        if self._supervisor is None or not self._supervisor.running():
            raise RuntimeError(
                "supervisor not running — call arm.start_supervisor() first")
        return self._supervisor

    def set_max_vel(self, max_vel: float) -> None:
        """Default peak joint velocity [rad/s] for planned moves (move_j/move_p).
        The yaml velocity limits remain a hard cap on top."""
        if max_vel <= 0.0:
            raise ValueError(f"max_vel must be positive, got {max_vel}")
        self._max_vel = float(max_vel)

    def _require_running(self, api: str) -> None:
        """Raise with STATE-SPECIFIC guidance — a faulted arm must not be told
        to just re-enable (recovery is the correct path there)."""
        state = self._m.state()
        if state == MotorManagerState.Running:
            return
        if self._estop_latched:
            raise RuntimeError(
                f"{api}: arm was stopped by the button e-stop (damping latch) — "
                "this is terminal by design; restart the program to use the arm "
                "again")
        if state == MotorManagerState.Fault:
            reason = self._m.fault_reason()
            raise RuntimeError(
                f"{api}: arm is in FAULT (damping latch engaged)"
                + (f" — cause: {reason}" if reason else "")
                + ". Inspect/reposition the arm, then arm.recover() and "
                "arm.enable() to resume (re-holds at the measured pose)")
        raise RuntimeError(
            f"{api} requires Running (got {state}) — call arm.enable() and "
            "arm.start_control_loop() first")

    def _require_rm(self):
        if self._rm is None:
            raise RuntimeError(
                "no robot model attached — call arm.set_robot_model(RobotModel(urdf)) first")

    def _arm_feedback(self) -> Dict[int, float]:
        return {s.id: s.position for s in self._m.states()}

    def fk(self, joints: Optional[Sequence[float]] = None) -> List[float]:
        """Flange pose [x, y, z, roll, pitch, yaw] (m/rad) for the given arm
        joint positions (in arm-motor order), or the current feedback if None."""
        self._require_rm()
        if joints is None:
            fb = self._arm_feedback()
            joints = [fb.get(mid, 0.0) for mid in self._arm_ids]
        q = self._rm.q_from_joints({
            self._urdf_of[mid]: float(joints[i]) for i, mid in enumerate(self._arm_ids)})
        xyz, rpy = self._rm.frame_pose(q, self._flange)
        return [*map(float, xyz), *map(float, rpy)]

    def get_flange_pose(self) -> List[float]:
        """Current flange pose [x, y, z, roll, pitch, yaw] from feedback."""
        return self.fk(None)

    def move_j(
        self,
        positions: Sequence[float],
        *,
        max_vel: Optional[float] = None,
        kp: Optional[float] = None,
        kd: Optional[float] = None,
        rate: float = 100.0,
    ) -> float:
        """Planned joint move: slow by default, streamed in many small steps.

        ``positions`` are targets [rad] for the arm motors (arm-motor order —
        the motors mapped to URDF joints when a robot model is attached,
        otherwise all configured non-gripper motors). All joints follow one synchronized
        cubic profile (zero end velocities); duration is set by the slowest
        joint at ``max_vel`` [rad/s] peak (yaml velocity limits remain a hard
        cap). Other motors (e.g. the gripper) hold their current position.
        Blocks until done and returns the move duration [s]. Requires the
        control loop running.
        """
        if self._config is None:
            raise RuntimeError("move_j needs a config-built Arm (ArmFactory.create_arm)")
        self._require_running("move_j")
        ids = self._planned_arm_ids()
        if len(positions) != len(ids):
            raise ValueError(f"expected {len(ids)} positions for motors {ids}, "
                             f"got {len(positions)}")

        fb = self._arm_feedback()
        missing = [mid for mid in self._joint_ids if mid not in fb]
        if missing:
            raise RuntimeError(f"no feedback from motor(s) {missing}; refusing to move")

        # user-supplied targets are VALIDATED, not silently clamped — a target
        # outside the allowed range is a caller mistake and must be visible
        target = {}
        violations = []
        for i, mid in enumerate(ids):
            lo, hi = self._bounds[mid]
            pos = float(positions[i])
            if not lo <= pos <= hi:
                violations.append(f"motor {mid}: {pos} outside [{lo:.3f}, {hi:.3f}]")
            target[mid] = pos
        if violations:
            log.error("move_j REJECTED: %s", "; ".join(violations))
            raise ValueError(
                "move_j target outside the allowed range (safe_position/limits) — "
                + "; ".join(violations))
        for mid in ids:
            lo, hi = self._bounds[mid]
            if not lo <= fb[mid] <= hi:
                log.warning("move_j: motor %d starts OUTSIDE its allowed range "
                            "(%.3f not in [%.3f, %.3f]) — streamed commands will be "
                            "clamped until it re-enters", mid, fb[mid], lo, hi)
        start = fb
        via_supervisor = (self._supervisor is not None
                          and self._supervisor.running())
        if via_supervisor:
            # continuous start: HOLD -> the commanded pose (no PD-sag step);
            # FLOAT -> the MEASURED pose (the arm may have moved while limp)
            resume = self._supervisor.resume_pose()
            start = {mid: resume.get(mid, fb[mid]) for mid in fb}
        traj = plan_joint_move(
            start, target, self._vel_limits,
            max_vel=self._max_vel if max_vel is None else max_vel)
        self._reject_self_collision_path(start, target)
        log.info("move_j: %s -> %s over %.2fs (peak %.2f rad/s)%s",
                 {m: round(start[m], 3) for m in ids},
                 {m: round(target[m], 3) for m in ids},
                 traj.duration, self._max_vel if max_vel is None else max_vel,
                 " via supervisor" if via_supervisor else "")
        if via_supervisor:
            return self._supervisor.run_trajectory(traj, target)

        hold = {mid: fb[mid] for mid in self._joint_ids if mid not in target}
        period = 1.0 / rate
        # trajectory time advances by wall clock but at most a few periods per
        # iteration: if this thread stalls (GUI/viewer GIL block, GC), the move
        # pauses and resumes instead of JUMPING the command to a later point —
        # a jump > 3 rad would trip command_position_step_limit
        t = 0.0
        last = time.monotonic()
        while True:
            now = time.monotonic()
            t += min(now - last, 5 * period)
            last = now
            sampled = traj.sample(t)
            cmds = []
            for mid in self._joint_ids:
                pos = sampled.get(mid, hold.get(mid, 0.0))
                lo, hi = self._bounds[mid]
                default_kp, default_kd = self._default_gains_for_motor(mid)
                cmds.append(MotorCommand(
                    id=mid, position=min(max(pos, lo), hi),
                    kp=default_kp if kp is None else kp,
                    kd=default_kd if kd is None else kd))
            self._m.set_commands(cmds)
            if traj.done(t):
                rep = self._m.last_safety_report()
                if rep.command_modified or rep.command_rejected:
                    log.warning("move_j: core safety adjusted the commands — %s",
                                "; ".join(f"{i.plugin}: {i.message}"
                                          for i in rep.issues[:3]) or "(no detail)")
                log.info("move_j: done (%.2fs)", traj.duration)
                return traj.duration
            time.sleep(period)

    def move_p(
        self,
        pose: Sequence[float],
        *,
        max_vel: Optional[float] = None,
        **move_j_kwargs,
    ) -> float:
        """Cartesian PTP: IK to the flange pose [x, y, z, roll, pitch, yaw]
        (m/rad, base frame), then a planned joint move (same slow defaults).

        IK is seeded from the current measured configuration, so the nearest
        solution branch is taken. Raises if IK does not converge."""
        self._require_rm()
        self._require_running("move_p")
        if len(pose) != 6:
            raise ValueError("pose must be [x, y, z, roll, pitch, yaw]")
        fb = self._arm_feedback()
        seed = fb
        if self._supervisor is not None and self._supervisor.running():
            # seed IK from the same pose move_j starts its trajectory at
            # (HOLD: commanded; FLOAT: measured) — so the whole move is
            # continuous even coming out of drag/teach
            resume = self._supervisor.resume_pose()
            seed = {mid: resume.get(mid, fb.get(mid, 0.0)) for mid in self._arm_ids}
        q0 = self._rm.q_from_joints({
            self._urdf_of[mid]: seed.get(mid, 0.0) for mid in self._arm_ids})
        res = self._rm.ik(self._flange, pose[:3], pose[3:], q0,
                          free_joints=[self._urdf_of[mid] for mid in self._arm_ids])
        if not res.success:
            log.error("move_p REJECTED: IK did not converge for %s (pos_err=%.4f m, "
                      "rot_err=%.4f rad)", list(pose), res.pos_err, res.rot_err)
            raise RuntimeError(
                f"IK did not converge for pose {list(pose)}: pos_err={res.pos_err:.4f} m, "
                f"rot_err={res.rot_err:.4f} rad — target may be out of reach")
        log.info("move_p: IK ok in %d iters (pos_err=%.1e, rot_err=%.1e)",
                 res.iterations, res.pos_err, res.rot_err)
        targets = [float(res.q[self._rm._qidx[self._urdf_of[mid]]])
                   for mid in self._arm_ids]
        for mid, pos in zip(self._arm_ids, targets):
            lo, hi = self._bounds[mid]
            if not lo <= pos <= hi:
                log.error("move_p REJECTED: IK solution for motor %d is %.3f, "
                          "outside the safe envelope [%.3f, %.3f]", mid, pos, lo, hi)
                raise RuntimeError(
                    f"pose is only reachable outside the safe envelope — IK wants "
                    f"motor {mid} at {pos:.3f}, allowed [{lo:.3f}, {hi:.3f}]")
        return self.move_j(targets, max_vel=max_vel, **move_j_kwargs)

    # -- not-yet-implemented (milestones) ----------------------------------- #
    def start_gravity_compensation(self):
        raise NotImplementedError("Use GravityCompensator directly for now; the "
                                  "ModeSupervisor integration is planned (M1.5).")

    def init_effector(self, joint: str = "gripper") -> "Gripper":
        """Position-controlled (impedance) gripper on the motor whose config
        ``joint``/``name`` matches. Like Piper's ``init_effector``: build it
        once, then ``gripper.move(pos)`` / ``open()`` / ``close()``. The
        gripper rides the supervisor's command stream (start it via enable() on
        the create_arm path), so it holds and moves without a dead-man latch."""
        if self._config is None:
            raise RuntimeError(
                "init_effector needs a config-built Arm (ArmFactory.create_arm)")
        motors = [m for m in self._config.motors
                  if m.joint_name == joint or m.name == joint]
        if not motors:
            raise ValueError(
                f"no motor with joint/name {joint!r}; "
                f"motors: {[(m.id, m.joint_name) for m in self._config.motors]}")
        mc = motors[0]
        # Clamp to the INTERSECTION of the mechanical limits and the safe range —
        # never command past EITHER end. (The gripper's safe_position can be
        # padded WIDER than its limits so the safety plugin doesn't clip commands
        # at the exact ends; driving open()/close() to that pad would jam the
        # jaws into the hard stop and over-current.)
        lo, hi = mc.limits.position_min, mc.limits.position_max
        if mc.safety.safe_position_configured:
            lo = max(lo, mc.safety.safe_position_min)
            hi = min(hi, mc.safety.safe_position_max)
        return Gripper(self, mc.id, (lo, hi))


class Gripper:
    """Position-controlled (impedance) gripper effector on a single motor.

    Commands a target position [rad]; the motor's kp/kd hold it there
    (impedance). ``open()``/``close()`` go to the two ends of the configured
    range. Requires a running supervisor (create_arm auto-starts it)."""

    def __init__(self, arm: "Arm", motor_id: int, bounds: Tuple[float, float]):
        self._arm = arm
        self._id = motor_id
        self._lo, self._hi = bounds

    @property
    def motor_id(self) -> int:
        return self._id

    @property
    def range(self) -> Tuple[float, float]:
        return (self._lo, self._hi)

    @property
    def position(self) -> Optional[float]:
        """Current measured gripper position [rad] (None if no feedback yet)."""
        for s in self._arm.manager.states():
            if s.id == self._id:
                return s.position
        return None

    def move(self, position: float, *,
             kp: Optional[float] = None, kd: Optional[float] = None) -> float:
        """Move to ``position`` [rad] (clamped to the range) and hold it there
        via impedance. Returns the clamped target. Optional kp/kd override the
        gripper gains for a firmer/softer hold."""
        pos = min(max(float(position), self._lo), self._hi)
        sup = self._arm._require_supervisor()
        sup.set_target(self._id, pos, kp=kp, kd=kd)
        log.info("gripper -> %.3f rad (range [%.2f, %.2f])",
                 pos, self._lo, self._hi)
        return pos

    def open(self, **kw) -> float:
        """Fully open the gripper (Milly: the lower end of the range, -2.3 rad)."""
        return self.move(self._lo, **kw)

    def close(self, **kw) -> float:
        """Fully close the gripper (Milly: the upper end of the range, 0.0 rad)."""
        return self.move(self._hi, **kw)


class ArmFactory:
    """Piper-style factory. ``create_arm(cfg)`` builds a manager and wraps it."""

    @staticmethod
    def create_arm(config: RobstrideSystemConfig) -> Arm:
        manager = make_motor_manager(config)
        return Arm(manager, config)


def create_arm(product_id: str, *, supervisor_rate_hz: Optional[float] = None) -> Arm:
    """Open the robot whose button board reports exactly this product ID.

    The product ID is engraved on the robot (e.g. ``MILLY_6TG5``) and stored
    on its LED/button board at the factory. Flow:

    1. Load the robot's tuning file ``<config dir>/<product_id>.yaml`` if it
       exists (see ``profiles/MILLY_DEFAULT.yaml``), else the bundled
       ``MILLY_DEFAULT.yaml``; merged over the bundled canonical config.
    2. Probe every CAN interface and require an EXACT product-ID match —
       fail-closed, no override. (The board's MCU UID is factory-internal
       and is neither used nor exposed here.)
    3. Inject the matching interface, connect, apply the tuning, return the
       :class:`Arm`.

    On this (product) path ``enable()`` also starts the mode supervisor and
    ``disable()`` stops it — so after enabling, the arm holds its pose and a
    finished move stays put. ``supervisor_rate_hz`` (command-update rate) is
    bounded [20, CAN send rate]; default = the CAN rate. Values above the CAN
    rate are pointless (updates would be dropped), so they are rejected.

    One robot = one tuning file; a fleet of N robots is N files in the same
    directory, each opened with its own ``create_arm("MILLY_....")``.
    """
    from . import identity, profile

    want = product_id.strip()
    # Every Milly ID is engraved as MILLY_<code> (alphanumeric). Enforcing the
    # prefix turns a typo / wrong-robot string into an immediate clear error
    # rather than a fail-closed "not found" after probing every bus.
    if not re.fullmatch(r"MILLY_[A-Za-z0-9]{1,10}", want):
        raise ValueError(
            f"product_id must be the robot ID engraved on the robot — "
            f"'MILLY_' followed by its code, e.g. 'MILLY_6TG5' (got {product_id!r})")

    cfg, tuning = profile.load_robot_profile(want)

    can_rate = cfg.buses[0].command_rate_hz if cfg.buses else 100.0
    sup_rate = can_rate if supervisor_rate_hz is None else float(supervisor_rate_hz)
    if not 20.0 <= sup_rate <= can_rate:
        raise ValueError(
            f"supervisor_rate_hz must be within [20, {can_rate:g}] Hz "
            f"(<= the CAN send rate), got {supervisor_rate_hz}")

    found: List[str] = []
    matched: Optional[str] = None
    for iface in identity.list_can_interfaces():
        try:
            # gentle gate first: at most one frame to an empty/degraded channel
            if identity.probe_channel(iface) is None:
                continue
            pid = identity.read_product_id(iface)
        except OSError as exc:
            log.warning("create_arm: cannot probe %s (%s) — is it up?", iface, exc)
            continue
        if pid is not None:
            found.append(f"{pid} (on {iface})")
        if pid == want:
            matched = iface
            break
    if matched is None:
        raise RuntimeError(
            f"no connected robot is named {want!r} (fail-closed). "
            f"Robots found: {found or 'none'} — check the ID engraved on the "
            "robot, its CAN cable and that its LED board is powered.")
    log.info("product id %s verified on %s — opening the arm", want, matched)

    if len(cfg.buses) != 1:
        raise RuntimeError(
            f"bundled config defines {len(cfg.buses)} buses; create_arm "
            "expects the single-bus Milly config")
    cfg.buses[0].config.interface_name = matched
    for m in cfg.motors:
        m.bus_name = cfg.buses[0].config.name

    arm = ArmFactory.create_arm(cfg)
    if not arm.connect():
        raise RuntimeError(
            f"robot {want} found on {matched} but opening the CAN bus failed")
    arm.set_max_vel(tuning.max_vel)
    arm.set_default_gains(tuning.kp, tuning.kd)
    arm.set_gripper_gains(tuning.gripper_kp, tuning.gripper_kd)
    # locked gravity-comp trim from the canonical config (NOT user-tunable)
    grav_scale, grav_gains, float_kd, float_kp = profile.canonical_gravity_tuning(cfg)
    arm._float_scale = grav_scale        # FLOAT scale (gravity comp ON strength), locked
    if grav_gains:
        arm.set_gravity_gains(grav_gains)
    if float_kd:
        arm.set_float_kd(float_kd)
    if float_kp:
        arm.set_float_kp(float_kp)
    arm._supervisor_auto = True          # enable()/disable() manage the supervisor
    arm._button_cfg = tuning.button      # None unless the tuning has a button: section
    arm._supervisor_rate_hz = sup_rate
    log.info("%s ready on %s (max_vel=%.2f, supervisor %.0fHz on enable)",
             want, matched, tuning.max_vel, sup_rate)
    return arm
