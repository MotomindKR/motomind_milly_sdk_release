"""Type stubs for the compiled ``motomind_milly._core`` extension."""

from __future__ import annotations

from typing import Dict, List, Optional

__version__: str

def version() -> str: ...

class MotorManagerState:
    Idle: MotorManagerState
    Enabled: MotorManagerState
    Running: MotorManagerState
    Fault: MotorManagerState
    Shutdown: MotorManagerState

class SafetySeverity:
    Ignore: SafetySeverity
    Warning: SafetySeverity
    Fault: SafetySeverity

class LimitAction:
    Pass: LimitAction
    Clamp: LimitAction
    Reject: LimitAction

class FaultReaction:
    NoReaction: FaultReaction
    FreezeCommandStream: FaultReaction
    DampingLatch: FaultReaction
    HardDisable: FaultReaction

class CommType:
    GetDeviceId: CommType
    MotorControl: CommType
    MotorFeedback: CommType
    MotorEnable: CommType
    MotorStop: CommType
    SetMechanicalZero: CommType
    SetCanId: CommType
    ParamRead: CommType
    ParamWrite: CommType
    FaultFeedback: CommType
    DataSave: CommType
    ActiveReport: CommType

def severity_name(severity: SafetySeverity) -> str: ...
def limit_action_name(action: LimitAction) -> str: ...
def fault_reaction_name(reaction: FaultReaction) -> str: ...
def parse_severity(name: str) -> Optional[SafetySeverity]: ...
def parse_limit_action(name: str) -> Optional[LimitAction]: ...
def parse_fault_reaction(name: str) -> Optional[FaultReaction]: ...

class CanFrame:
    id: int
    dlc: int
    data: List[int]
    def __init__(self) -> None: ...

def build_can_id(comm_type: CommType, data_field: int, target_id: int) -> int: ...
def comm_type_from_can_id(can_id: int) -> int: ...
def data_field_from_can_id(can_id: int) -> int: ...

class MotorCommand:
    id: int
    joint_name: str
    position: float
    velocity: float
    torque_feedforward: float
    kp: float
    kd: float
    def __init__(
        self,
        id: int = ...,
        position: float = ...,
        velocity: float = ...,
        torque_feedforward: float = ...,
        kp: float = ...,
        kd: float = ...,
        joint_name: str = ...,
    ) -> None: ...

class MotorState:
    id: int
    joint_name: str
    position: float
    velocity: float
    torque: float
    temperature: float
    fault_bits: int
    mode_status: int

class Feedback:
    motor_id: int
    mode_status: int
    fault_bits: int
    position: float
    velocity: float
    torque: float
    temperature: float

class MotorLimits:
    position_min: float
    position_max: float
    velocity_min: float
    velocity_max: float
    torque_min: float
    torque_max: float
    kp_min: float
    kp_max: float
    kd_min: float
    kd_max: float
    def __init__(self) -> None: ...

class MotorSafetyConfig:
    damping_kd: float
    safe_position_min: float
    safe_position_max: float
    safe_position_configured: bool
    def __init__(self) -> None: ...

class MotorConfig:
    name: str
    joint_name: str
    id: int
    bus_name: str
    model: str
    direction: int
    required: bool
    run_mode: int
    limits: MotorLimits
    safety: MotorSafetyConfig
    def __init__(self) -> None: ...

class MotorBusConfig:
    name: str
    interface_name: str
    host_id: int
    default_retries: int
    enable_retries: int
    default_timeout_ms: int
    enable_retry_delay_ms: int
    def __init__(self) -> None: ...

class MotorBusDefinition:
    config: MotorBusConfig
    command_rate_hz: float
    def __init__(self) -> None: ...

class FeedbackConfig:
    active_reporting: bool
    disable_active_reporting_on_exit: bool
    def __init__(self) -> None: ...

class SafetyPluginConfig:
    id: str
    type: str
    action: LimitAction
    action_configured: bool
    severity: SafetySeverity
    severity_configured: bool
    timeout_ms: int
    max_delta: float
    threshold_temperature_c: float
    threshold_temperature_configured: bool
    fault_reaction: FaultReaction
    fault_reaction_configured: bool
    def __init__(self) -> None: ...

class SafetyConfig:
    plugins: List[SafetyPluginConfig]
    manual_fault_reaction: FaultReaction
    manual_fault_reaction_configured: bool
    enable_fault_reaction: FaultReaction
    enable_fault_reaction_configured: bool
    start_fault_reaction: FaultReaction
    start_fault_reaction_configured: bool
    disable_fault_reaction: FaultReaction
    disable_fault_reaction_configured: bool
    communication_fault_reaction: FaultReaction
    communication_fault_reaction_configured: bool
    exit_reaction: FaultReaction
    exit_reaction_configured: bool
    damping_latch_send_count: int
    damping_latch_send_rate_hz: float
    def __init__(self) -> None: ...

class RobstrideSystemConfig:
    buses: List[MotorBusDefinition]
    motors: List[MotorConfig]
    feedback: FeedbackConfig
    safety: SafetyConfig
    def __init__(self) -> None: ...

class MotorRuntime:
    config: MotorConfig
    latest_state: MotorState
    latest_command: MotorCommand

class FsmGuards:
    bus_open: bool
    motor_list_valid: bool
    required_motors_reachable: bool
    no_motor_faults: bool
    operation_mode_valid: bool
    initial_command_safe: bool
    command_fresh: bool
    manual_recovery_requested: bool
    def __init__(self) -> None: ...

class FsmResult:
    ok: bool
    from_state: MotorManagerState
    to_state: MotorManagerState
    message: str

class SafetyIssue:
    severity: SafetySeverity
    reaction: FaultReaction
    plugin: str
    message: str
    command_modified: bool
    command_rejected: bool

class SafetyReport:
    severity: SafetySeverity
    reaction: FaultReaction
    issues: List[SafetyIssue]
    command_modified: bool
    command_rejected: bool
    def ok(self) -> bool: ...

class MotorManager:
    def open(self) -> bool: ...
    def close(self) -> None: ...
    def state(self) -> MotorManagerState: ...
    def enable(self) -> FsmResult: ...
    def start(self, guards: FsmGuards = ...) -> FsmResult: ...
    def stop_control(self) -> FsmResult: ...
    def disable(self) -> FsmResult: ...
    def fault(self, reason: str, reaction: FaultReaction) -> FsmResult: ...
    def recover(self, guards: FsmGuards = ...) -> FsmResult: ...
    def shutdown(self) -> FsmResult: ...
    def set_command(self, command: MotorCommand) -> bool: ...
    def send_command(self, command: MotorCommand) -> bool: ...
    def set_commands(self, commands: List[MotorCommand]) -> None: ...
    def clear_commands(self) -> None: ...
    def set_run_mode(self, motor_id: int, mode: int) -> bool: ...
    def set_run_mode_for_all(self, mode: int) -> bool: ...
    def set_damping_latch_config(self, send_count: int, send_rate_hz: float) -> None: ...
    def set_enable_fault_reaction(self, reaction: FaultReaction) -> None: ...
    def set_start_fault_reaction(self, reaction: FaultReaction) -> None: ...
    def set_disable_fault_reaction(self, reaction: FaultReaction) -> None: ...
    def set_exit_reaction(self, reaction: FaultReaction) -> None: ...
    def set_communication_fault_reaction(self, reaction: FaultReaction) -> None: ...
    def set_active_reporting_enabled(self, enabled: bool) -> None: ...
    def set_disable_active_reporting_on_exit(self, enabled: bool) -> None: ...
    def refresh_feedback(self, timeout_ms: int = ..., retries: int = ...) -> Dict[int, Feedback]: ...
    def wait_fresh_feedback(self, timeout_ms: int = ...) -> Dict[int, Feedback]: ...
    def start_control_loop(self, rate_hz: float) -> FsmResult: ...
    def stop_control_loop(self) -> FsmResult: ...
    def control_loop_running(self) -> bool: ...
    def states(self) -> List[MotorState]: ...
    def runtimes(self) -> List[MotorRuntime]: ...
    def commands(self) -> List[MotorCommand]: ...
    def command_count(self) -> int: ...
    def last_safety_report(self) -> SafetyReport: ...
    def last_fault_reaction(self) -> FaultReaction: ...
    def last_control_loop_error(self) -> str: ...
    def fault_reason(self) -> str: ...
    def safety_chain_size(self) -> int: ...

def make_motor_manager(config: RobstrideSystemConfig) -> MotorManager: ...
def apply_safety_config(manager: MotorManager, config: SafetyConfig) -> None: ...

class FakeCanBus:
    def push_receive_frame(self, frame: CanFrame) -> None: ...
    def push_receive_on_send_frame(self, frame: CanFrame) -> None: ...
    def take_sent_frame(self) -> Optional[CanFrame]: ...
    def clear(self) -> None: ...

class FakeRig:
    manager: MotorManager
    fake: FakeCanBus
    def push_feedback_on_send(self, motor_id: int, mode_status: int = ...) -> None: ...
    def push_feedback(self, motor_id: int, mode_status: int = ...) -> None: ...

def build_fake_rig(
    motors: List[MotorConfig], bus_config: MotorBusConfig = ...
) -> FakeRig: ...
