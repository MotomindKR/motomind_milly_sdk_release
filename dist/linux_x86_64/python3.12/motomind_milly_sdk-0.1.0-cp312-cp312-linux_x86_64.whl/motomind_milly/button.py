"""STM button-board monitor: poll the button over CAN and fire an action on a
toggle.

The button board shares the motor CAN line. On SocketCAN this monitor opens its
OWN read (``identity.read_button`` = a 2nd socket), so it runs alongside the
running ``MotorManager`` WITHOUT touching the frozen core. The board's
auto-report is not implemented in firmware, so we POLL at a bounded rate.

The board TOGGLES ``button_state`` on each press (0<->1), so the action fires on
EVERY state change — one press == one change == one action. The first reading is
just recorded (no fire), so a button already 'on' at startup is harmless.

Actions (``on_toggle``):
  - ``damping_latch`` — one-way terminal e-stop via ``manager.fault`` (same as
    the GUI e-stop); resuming needs a program restart.
  - ``float_toggle`` — gravity comp on/off (FLOAT<->HOLD), recoverable; needs a
    robot model attached.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import TYPE_CHECKING, Callable, Dict

from . import identity

if TYPE_CHECKING:
    from ._sdk import Arm

log = logging.getLogger("motomind_milly.button")

POLL_MS_RANGE = (50, 1000)


def _damping_latch(arm: "Arm") -> None:
    """Terminal safe stop: damping latch with NO programmatic resume — the arm
    stays latched and enable()/recover() refuse until the program restarts. A
    button stop is final by design."""
    arm._button_estop()


def _float_toggle(arm: "Arm") -> None:
    """Toggle gravity compensation: FLOAT (comp ON — back-drivable drag/teach)
    <-> HOLD (comp OFF — stiff hold). Recoverable — press again to flip back.
    Needs a robot model attached (set_robot_model) so FLOAT can compute G(q)."""
    from .mode_supervisor import Mode
    sup = getattr(arm, "_supervisor", None)
    if sup is None or not sup.running():
        log.warning("button float_toggle: supervisor not running — ignored")
        return
    if sup.mode is Mode.FLOAT:
        arm.hold_mode()
        log.info("button -> HOLD (gravity comp OFF)")
    else:
        arm.float_mode()          # locked canonical scale (gravity comp ON)
        log.info("button -> FLOAT (gravity comp ON)")


#: action name (yaml ``button.on_toggle``) -> handler(arm)
_ACTIONS: Dict[str, Callable[["Arm"], None]] = {
    "damping_latch": _damping_latch,
    "float_toggle": _float_toggle,
}


def action_names() -> tuple:
    return tuple(_ACTIONS)


class ButtonMonitor:
    """Background poller that fires ``on_toggle`` when the button leaves its
    startup state. Start after the arm is enabled; stop before disconnect."""

    def __init__(self, arm: "Arm", interface: str, *, poll_ms: int = 200,
                 on_toggle: str = "damping_latch"):
        if on_toggle not in _ACTIONS:
            raise ValueError(
                f"unknown button action {on_toggle!r}; "
                f"available: {sorted(_ACTIONS)}")
        lo, hi = POLL_MS_RANGE
        if not lo <= poll_ms <= hi:
            raise ValueError(f"button poll_ms must be within [{lo}, {hi}], "
                             f"got {poll_ms}")
        self._arm = arm
        self._iface = interface
        self._period = poll_ms / 1000.0
        self._action_name = on_toggle
        self._action = _ACTIONS[on_toggle]
        self._thread: "threading.Thread | None" = None
        self._stop = threading.Event()

    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> "ButtonMonitor":
        if self.running():
            return self
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="button",
                                        daemon=True)
        self._thread.start()
        log.info("button monitor: polling %s every %.0f ms -> %s",
                 self._iface, self._period * 1000, self._action_name)
        return self

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None

    def _loop(self) -> None:
        prev = None
        misses = 0
        while not self._stop.is_set():
            # retries=0: one request/timeout per poll, so a silent board never
            # stalls the loop by more than a single timeout.
            try:
                st = identity.read_button(self._iface, retries=0)
            except OSError as exc:                    # iface down/missing: don't die
                misses += 1
                if misses in (5, 50):
                    log.warning("button monitor: read failed on %s (%s)",
                                self._iface, exc)
                self._stop.wait(self._period)
                continue
            if st is None:
                misses += 1
                if misses in (5, 50):
                    log.warning("button monitor: no response x%d on %s "
                                "(board powered?)", misses, self._iface)
                self._stop.wait(self._period)
                continue
            misses = 0
            state = st["button_state"]
            if prev is None:
                prev = state                      # first reading = startup state
                log.info("button monitor: initial state=%d (not a toggle)",
                         state)
            elif state != prev:
                # fire on EVERY state change: the board TOGGLES button_state on
                # each press (0<->1), so one press == one change == one action.
                # (Firing only when leaving a fixed baseline fired on every OTHER
                # press — fine for a one-shot e-stop, wrong for FLOAT<->HOLD.)
                log.warning("button toggle (state %d->%d) -> %s",
                            prev, state, self._action_name)
                try:
                    self._action(self._arm)
                except Exception as exc:          # never kill the poll thread
                    log.error("button action %s failed: %s",
                              self._action_name, exc)
                prev = state
            self._stop.wait(self._period)
