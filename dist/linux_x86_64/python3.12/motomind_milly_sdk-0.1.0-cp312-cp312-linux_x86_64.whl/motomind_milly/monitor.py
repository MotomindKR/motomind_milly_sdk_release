"""Motor status monitor GUI (tkinter, stdlib — no extra dependencies).

A read-only live view of every configured motor (position / velocity / torque /
temperature / fault bits / mode) plus the manager status (FSM state, control
loop, last safety issue, fault reaction) and the lifecycle buttons of the ROS
``robstride_motor_gui`` — Enable, Start/Stop Control, Disable, Clear Faults,
E-stop. No jog: this tool observes, it does not stream motion commands.

Two ways to run it:

1. Standalone (this process OWNS the CAN bus — nothing else may drive it):

     motomind-milly-gui --config configs/robots/motomind_milly/milly_teleop.yaml
     # or: python -m motomind_milly.monitor --config ...

   Closing the window e-stops (damping latch) and shuts down conservatively.

2. Embedded in a running SDK program (same process, same manager — no bus
   ownership conflict). The examples expose this as ``--gui``:

     .venv/bin/python tests/tools/aging_test_mujoco.py --api j --real --gui

   Closing the window only closes the window; the host program keeps running
   and keeps owning the arm lifecycle.
"""

from __future__ import annotations

import logging
import threading
from typing import Optional

from . import _core
from ._core import FaultReaction, MotorManager, MotorManagerState, RobstrideSystemConfig

log = logging.getLogger("motomind_milly.monitor")

_STATE_COLORS = {
    MotorManagerState.Idle: "#888888",
    MotorManagerState.Enabled: "#c58f00",
    MotorManagerState.Running: "#0a7d24",
    MotorManagerState.Fault: "#c01818",
    MotorManagerState.Shutdown: "#555555",
}
_COLUMNS = ("id", "joint", "pos [rad]", "vel [rad/s]", "tau [Nm]", "temp [C]",
            "fault", "mode")


class MotorMonitor:
    """Live motor/manager monitor window.

    ``owns_arm=True`` (standalone) makes closing the window e-stop + shutdown;
    embedded monitors never touch the host's arm lifecycle on close.
    """

    def __init__(
        self,
        manager: MotorManager,
        cfg: Optional[RobstrideSystemConfig] = None,
        *,
        title: str = "motomind milly — motor monitor",
        poll_ms: int = 100,
        owns_arm: bool = False,
    ):
        try:  # fail fast with a clear hint (NOT silently in the Tk thread)
            import tkinter  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "tkinter is not installed — on Ubuntu: sudo apt install python3-tk"
            ) from exc
        self._m = manager
        self._cfg = cfg
        self._title = title
        self._poll_ms = int(poll_ms)
        self._owns_arm = owns_arm
        self._rate = 100.0
        self._run_mode = 0
        if cfg is not None and cfg.buses:
            self._rate = float(cfg.buses[0].command_rate_hz)
        if cfg is not None and cfg.motors:
            self._run_mode = int(cfg.motors[0].run_mode)
        self._thread: Optional[threading.Thread] = None
        self._root = None
        self._closed = threading.Event()

    # ------------------------------------------------------------------ API
    def start(self) -> "MotorMonitor":
        """Open the window on a background thread (embedded use)."""
        if self._thread and self._thread.is_alive():
            return self
        self._thread = threading.Thread(target=self.run, name="motor_monitor",
                                        daemon=True)
        self._thread.start()
        return self

    def run(self) -> None:
        """Create the window and block in its event loop (Tk lives in this
        thread — all widget access happens here via ``after`` callbacks)."""
        import tkinter as tk
        from tkinter import ttk

        root = tk.Tk()
        self._root = root
        root.title(self._title)

        # -- manager status panel ------------------------------------------ #
        status = ttk.LabelFrame(root, text="Manager", padding=6)
        status.pack(fill=tk.X, padx=6, pady=4)
        state_var = tk.StringVar(value="-")
        state_lbl = tk.Label(status, textvariable=state_var, width=10,
                             fg="white", bg="#888888", font=("TkDefaultFont", 10, "bold"))
        state_lbl.grid(row=0, column=0, rowspan=2, padx=4, pady=2, sticky="ns")
        info_var = tk.StringVar(value="")
        ttk.Label(status, textvariable=info_var, justify=tk.LEFT).grid(
            row=0, column=1, rowspan=2, padx=8, sticky="w")

        # -- lifecycle buttons (same set as the ROS gui; no jog) ------------ #
        buttons = ttk.LabelFrame(root, text="Lifecycle", padding=6)
        buttons.pack(fill=tk.X, padx=6, pady=4)
        action_var = tk.StringVar(value="")

        def run_action(name, fn):
            """Blocking manager calls go to a worker thread; result -> label."""
            def work():
                try:
                    res = fn()
                    msg = getattr(res, "message", str(res))
                    ok = getattr(res, "ok", True)
                    action_var.set(f"{name}: {'ok' if ok else 'FAILED'} — {msg}")
                    (log.info if ok else log.error)("%s: %s", name, msg)
                except Exception as exc:  # surface, never kill the GUI
                    action_var.set(f"{name}: ERROR — {exc}")
                    log.exception("%s failed", name)
            threading.Thread(target=work, daemon=True).start()

        def do_enable():
            res = self._m.enable()
            if res.ok and self._cfg is not None:
                self._m.set_run_mode_for_all(self._run_mode)
            return res

        for text, fn in (
            ("Enable", do_enable),
            ("Start Control", lambda: self._m.start_control_loop(self._rate)),
            ("Stop Control", lambda: self._m.stop_control_loop()),
            ("Disable", lambda: self._m.disable()),
            ("Clear Faults", lambda: self._m.recover()),
        ):
            ttk.Button(buttons, text=text,
                       command=lambda t=text, f=fn: run_action(t, f)).pack(
                side=tk.LEFT, padx=2)
        manual_reaction = FaultReaction.DampingLatch
        if (self._cfg is not None
                and self._cfg.safety.manual_fault_reaction_configured):
            manual_reaction = self._cfg.safety.manual_fault_reaction
        estop_name = f"E-stop ({_core.fault_reaction_name(manual_reaction)})"
        tk.Button(buttons, text="E-STOP", fg="white", bg="#c01818",
                  command=lambda: run_action(estop_name,
                                             lambda: self._m.fault(
                                                 "gui e-stop", manual_reaction))
                  ).pack(side=tk.LEFT, padx=10)
        ttk.Label(buttons, textvariable=action_var).pack(side=tk.LEFT, padx=8)

        # -- per-motor table ------------------------------------------------ #
        table = ttk.Treeview(root, columns=_COLUMNS, show="headings", height=8)
        for col in _COLUMNS:
            table.heading(col, text=col)
            table.column(col, width=90 if col not in ("id",) else 40,
                         anchor=tk.CENTER)
        table.tag_configure("fault", background="#ffd6d6")
        table.pack(fill=tk.BOTH, expand=True, padx=6, pady=4)

        # -- 10 Hz poll ------------------------------------------------------ #
        def tick():
            if self._closed.is_set():
                root.destroy()
                return
            try:
                st = self._m.state()
                state_var.set(str(st).rsplit(".", 1)[-1])
                state_lbl.configure(bg=_STATE_COLORS.get(st, "#888888"))

                rep = self._m.last_safety_report()
                lines = [
                    f"control_loop={'running' if self._m.control_loop_running() else 'stopped'}"
                    f"  commands={self._m.command_count()}"
                    f"  reaction={_core.fault_reaction_name(self._m.last_fault_reaction())}",
                    f"safety={_core.severity_name(rep.severity)}"
                    + (f"  {rep.issues[0].plugin}: {rep.issues[0].message}"
                       if rep.issues else ""),
                ]
                reason = self._m.fault_reason()
                if reason:
                    lines.insert(0, f"fault_reason: {reason}")
                err = self._m.last_control_loop_error()
                if err:
                    lines.append(f"loop_error: {err}")
                info_var.set("\n".join(lines))

                table.delete(*table.get_children())
                for s in self._m.states():
                    tags = ("fault",) if s.fault_bits else ()
                    table.insert("", tk.END, tags=tags, values=(
                        s.id, s.joint_name,
                        f"{s.position:+.3f}", f"{s.velocity:+.3f}",
                        f"{s.torque:+.2f}", f"{s.temperature:.1f}",
                        f"0x{s.fault_bits:x}", s.mode_status))
            except Exception:
                log.exception("monitor poll failed")
            root.after(self._poll_ms, tick)

        def on_close():
            if self._owns_arm:
                # conservative standalone exit: damped stop, keep the latch
                try:
                    self._m.fault("monitor closed", FaultReaction.DampingLatch)
                    self._m.shutdown()
                except Exception:
                    log.exception("shutdown on close failed")
            self._closed.set()
            root.destroy()

        root.protocol("WM_DELETE_WINDOW", on_close)
        root.after(0, tick)
        root.mainloop()
        self._root = None

    def close(self) -> None:
        """Ask the window to close (safe from any thread)."""
        self._closed.set()


# --------------------------------------------------------------------------- #
# Standalone entry point
# --------------------------------------------------------------------------- #
def main() -> int:
    import argparse

    ap = argparse.ArgumentParser(
        description="Standalone motor monitor (this process OWNS the CAN bus)")
    ap.add_argument("--config", required=True, help="actuator yaml (teleop schema)")
    ap.add_argument("--poll-ms", type=int, default=100)
    args = ap.parse_args()

    from . import ArmFactory, enable_logging, load_config
    enable_logging()

    cfg = load_config(args.config)
    arm = ArmFactory.create_arm(cfg)
    print("[gui] opening CAN (motors stay idle until you press Enable)...")
    if not arm.connect():
        print("  ! CAN open failed — is the interface up? "
              "(sudo ip link set can0 up type can bitrate 1000000)")
        return 1

    mon = MotorMonitor(arm.manager, cfg, owns_arm=True,
                       title=f"motomind milly monitor — {args.config}",
                       poll_ms=args.poll_ms)
    try:
        mon.run()  # blocks; window close does the conservative shutdown
    finally:
        try:
            arm.disconnect()
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
