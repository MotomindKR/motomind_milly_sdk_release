"""Minimal channel-aware gs_usb (candleLight) transport for discovery.

Used by :mod:`motomind_milly.identity` on platforms without SocketCAN
(Windows; macOS later). Talks straight USB via pyusb — python-can's gs_usb
backend is NOT used because it ignores the frame's channel byte and can only
address channel 0 of a multi-channel module.

Scope: robot discovery (a few request/response frames). The realtime motor
control loop lives in the C++ core and gets its own transport in a later
milestone.

Dependencies (Windows): ``pip install pyusb libusb-package``. The module's
firmware carries WCID descriptors, so Windows auto-binds WinUSB — no manual
driver step.
"""

from __future__ import annotations

import os
import struct
import time
from typing import Callable, Dict, List, Optional, Tuple

GS_USB_VID = 0x1D50
GS_USB_PID = 0x606F

# control requests (bRequest)
_BREQ_HOST_FORMAT = 0
_BREQ_BITTIMING = 1
_BREQ_MODE = 2
_BREQ_BT_CONST = 4
_BREQ_DEVICE_CONFIG = 5

_MODE_RESET = 0
_MODE_START = 1

# struct gs_host_frame (classic CAN, no hardware timestamp):
#   u32 echo_id, u32 can_id, u8 dlc, u8 channel, u8 flags, u8 reserved, u8 data[8]
_FRAME = struct.Struct("<II4B8s")
FRAME_SIZE = _FRAME.size            # 20
RX_ECHO_ID = 0xFFFFFFFF             # frames from the bus (not our TX echoes)
CAN_EFF_FLAG = 0x80000000


# --------------------------------------------------------------------------- #
# Pure helpers (unit tested; no USB needed)
# --------------------------------------------------------------------------- #
def pack_frame(can_id: int, data: bytes, channel: int,
               extended: bool = True) -> bytes:
    """Encode one TX host frame for ``channel``."""
    raw_id = (can_id | CAN_EFF_FLAG) if extended else can_id
    return _FRAME.pack(0, raw_id, len(data), channel, 0, 0,
                       bytes(data).ljust(8, b"\0"))


def unpack_frame(raw: bytes) -> Optional[Dict[str, int]]:
    """Decode one host frame; None if it is our own TX echo or malformed."""
    if len(raw) < FRAME_SIZE:
        return None
    echo_id, raw_id, dlc, channel, flags, _res, data = _FRAME.unpack(
        raw[:FRAME_SIZE])
    if echo_id != RX_ECHO_ID:       # TX echo of a frame we sent — not bus RX
        return None
    return {
        "can_id": raw_id & 0x1FFFFFFF,
        "extended": bool(raw_id & CAN_EFF_FLAG),
        "channel": channel,
        "data": bytes(data[:dlc]),
    }


def solve_bittiming(fclk: int, bitrate: int, tseg1_range: Tuple[int, int],
                    tseg2_range: Tuple[int, int], brp_range: Tuple[int, int],
                    brp_inc: int = 1) -> Dict[str, int]:
    """Bit timing for ``bitrate`` aiming at an ~87.5 % sample point.

    E.g. the module's 48 MHz CAN clock at 1 Mbps solves to brp=3 with
    16 tq (tseg2=2 -> sample point 87.5 %).
    """
    best = None
    for brp in range(brp_range[0], brp_range[1] + 1, brp_inc):
        if fclk % (brp * bitrate):
            continue
        total = fclk // (brp * bitrate)      # tq per bit incl. sync
        tseg2 = max(tseg2_range[0], min(tseg2_range[1], round(total * 0.125)))
        tseg1 = total - 1 - tseg2            # sync = 1 tq
        if not tseg1_range[0] <= tseg1 <= tseg1_range[1]:
            continue
        sample = (total - tseg2) / total
        cand = (abs(sample - 0.875), brp)
        if best is None or cand < best[0]:
            best = (cand, {"prop_seg": tseg1 // 2,
                           "phase_seg1": tseg1 - tseg1 // 2,
                           "phase_seg2": tseg2, "sjw": 1, "brp": brp})
    if best is None:
        raise ValueError(
            f"no bit timing for {bitrate} bps from fclk={fclk} Hz")
    return best[1]


# --------------------------------------------------------------------------- #
# USB device handling (pyusb)
# --------------------------------------------------------------------------- #
def _import_usb():
    # point pyusb at the libusb DLL bundled in the libusb-package wheel
    try:
        import libusb_package
        dll = libusb_package.find_library("usb-1.0")
        if dll:
            os.environ["PATH"] = os.path.dirname(str(dll)) + os.pathsep \
                + os.environ.get("PATH", "")
    except Exception:
        pass
    try:
        import usb.core
        import usb.util
    except ImportError as exc:
        raise OSError(
            "gs_usb transport needs pyusb: pip install pyusb libusb-package"
        ) from exc
    return usb


class GsUsbDevice:
    """One USB-CAN module (possibly multi-channel)."""

    def __init__(self, usbdev):
        self._usb = _import_usb()
        self.dev = usbdev
        if os.name != "nt":     # Linux/macOS: take over from the kernel driver
            try:
                if self.dev.is_kernel_driver_active(0):
                    self.dev.detach_kernel_driver(0)
            except (NotImplementedError, self._usb.core.USBError):
                pass
        self.dev.set_configuration()
        intf = self.dev.get_active_configuration()[(0, 0)]
        eps = intf.endpoints()
        self._ep_in = next(e for e in eps if e.bEndpointAddress & 0x80)
        self._ep_out = next(e for e in eps if not e.bEndpointAddress & 0x80)

        self._ctrl_out(_BREQ_HOST_FORMAT, 1, struct.pack("<I", 0x0000BEEF))
        cfg = self._ctrl_in(_BREQ_DEVICE_CONFIG, 1, 12)
        self.channel_count = cfg[3] + 1
        self._started: Dict[int, bool] = {}
        self._pending: List[Dict[str, int]] = []

    # -- control plane ------------------------------------------------------ #
    def _ctrl_out(self, breq: int, value: int, data: bytes) -> None:
        self.dev.ctrl_transfer(0x41, breq, value, 0, data)

    def _ctrl_in(self, breq: int, value: int, length: int) -> bytes:
        return bytes(self.dev.ctrl_transfer(0xC1, breq, value, 0, length))

    def start(self, channel: int, bitrate: int = 1_000_000) -> None:
        if self._started.get(channel):
            return
        bt = self._ctrl_in(_BREQ_BT_CONST, channel, 40)
        (_feat, fclk, t1lo, t1hi, t2lo, t2hi, _sjw,
         brplo, brphi, brpinc) = struct.unpack("<10I", bt)
        timing = solve_bittiming(fclk, bitrate, (t1lo, t1hi), (t2lo, t2hi),
                                 (brplo, brphi), brpinc)
        self._ctrl_out(_BREQ_BITTIMING, channel, struct.pack(
            "<5I", timing["prop_seg"], timing["phase_seg1"],
            timing["phase_seg2"], timing["sjw"], timing["brp"]))
        self._ctrl_out(_BREQ_MODE, channel, struct.pack("<2I", _MODE_START, 0))
        self._started[channel] = True

    # -- data plane ---------------------------------------------------------- #
    def send(self, channel: int, can_id: int, data: bytes) -> None:
        self._ep_out.write(pack_frame(can_id, data, channel))

    def recv(self, channel: int, timeout_s: float) -> Optional[Dict[str, int]]:
        """Next bus frame for ``channel`` (other channels' frames are queued)."""
        for i, fr in enumerate(self._pending):
            if fr["channel"] == channel:
                return self._pending.pop(i)
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            try:
                raw = bytes(self._ep_in.read(
                    64, timeout=max(1, int((deadline - time.monotonic()) * 1000))))
            except self._usb.core.USBTimeoutError:
                return None
            except self._usb.core.USBError:
                return None
            fr = unpack_frame(raw)
            if fr is None:
                continue
            if fr["channel"] == channel:
                return fr
            self._pending.append(fr)
        return None


# --------------------------------------------------------------------------- #
# Logical interface registry ("can0", "can1", ... across modules)
# --------------------------------------------------------------------------- #
_devices: Optional[List[GsUsbDevice]] = None
_channels: Dict[str, Tuple[GsUsbDevice, int]] = {}


def _scan() -> None:
    global _devices
    if _devices is not None:
        return
    usb = _import_usb()
    _devices = []
    found = usb.core.find(find_all=True, idVendor=GS_USB_VID,
                          idProduct=GS_USB_PID)
    for usbdev in sorted(found, key=lambda d: (d.bus, d.address)):
        try:
            _devices.append(GsUsbDevice(usbdev))
        except Exception:       # in use / permission — skip this module
            continue
    n = 0
    for dev in _devices:
        for ch in range(dev.channel_count):
            _channels[f"can{n}"] = (dev, ch)
            n += 1


def list_channels() -> List[str]:
    """Logical interface names, e.g. ['can0', 'can1'] for one 2-channel module."""
    _scan()
    return sorted(_channels, key=lambda s: int(s[3:]))


def exchange(
    interface: str,
    request_id: int,
    request_data: bytes,
    match: Callable[[int], bool],
    timeout_s: float = 0.3,
    retries: int = 2,
) -> Optional[Tuple[int, bytes]]:
    """Same contract as identity._exchange, over gs_usb."""
    _scan()
    if interface not in _channels:
        raise OSError(f"no gs_usb channel named {interface!r} "
                      f"(available: {list_channels()})")
    dev, ch = _channels[interface]
    dev.start(ch)
    for _ in range(retries + 1):
        dev.send(ch, request_id, request_data)
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            fr = dev.recv(ch, deadline - time.monotonic())
            if fr is None:
                break
            if fr["extended"] and match(fr["can_id"]):
                return fr["can_id"], fr["data"]
    return None
