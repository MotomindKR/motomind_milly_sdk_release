"""Per-robot profiles: bundled canonical config + user tuning overlay.

Layering (distribution-ready — no repo paths):

1. ``profiles/milly_canonical.yaml`` — canonical motor/limit/safety config,
   shipped INSIDE the package. Users never see or edit it.
2. ``<config dir>/<PRODUCT_ID>.yaml`` — one small tuning file per robot,
   named exactly after the ID engraved on the robot (e.g. ``MILLY_6TG5.yaml``).
   Whitelisted keys only; unknown keys or out-of-range values are load errors,
   never silently ignored. If a robot has no such file, the bundled
   ``profiles/MILLY_DEFAULT.yaml`` tuning is used (with a log line) — the arm
   still runs on safe defaults.

Config dir: the package ``profiles/`` dir by default; ``$MOTOMIND_CONFIG_DIR`` overrides it.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

log = logging.getLogger("motomind_milly.profile")

_PROFILES_DIR = Path(__file__).resolve().parent / "profiles"
CANONICAL_CONFIG = _PROFILES_DIR / "milly_canonical.yaml"
DEFAULT_TUNING = _PROFILES_DIR / "MILLY_DEFAULT.yaml"
# Factory-measured mass / COM values used for every product FLOAT path.  This
# is package data, not a user profile: the CAD/URDF inertials alone are not
# accurate enough for safe neutral gravity compensation.
FACTORY_GRAVITY_CALIBRATION = _PROFILES_DIR / "milly_cal.yaml"

N_ARM_JOINTS = 6
MAX_VEL_RANGE = (0.0, 2.0)      # exclusive low, inclusive high
# STM button actions are disabled for this release. Keep the validation values
# here so a disabled ``button:`` section is still checked for typos.
BUTTON_POLL_MS_RANGE = (50, 1000)
BUTTON_ACTIONS = ("damping_latch", "float_toggle")

# --- safety overrides (whitelist per plugin id) ------------------------------ #
# 'ignore' (severity) and 'none' (fault_reaction) are deliberately NOT
# offered: users may make a check stricter or pick how it stops, but never
# silence it or strip the stop reaction.
SEVERITY_NAMES = ("warning", "fault")
FAULT_REACTION_NAMES = ("freeze_command_stream", "damping_latch", "hard_disable")
TIMEOUT_MS_RANGE = (50, 500)
TEMP_FAULT_C_RANGE = (60.0, 100.0)
TEMP_WARN_C_RANGE = (40.0, 100.0)

#: Which key(s) of which safety plugin a user may override. Everything else
#: (safe_position, motor_fault, actions, reactions, ...) is canonical-only.
SAFETY_TUNABLE = {
    "command_limit": {"severity", "fault_reaction"},
    "command_position_step_limit": {"severity", "fault_reaction"},
    "command_update_timeout": {"timeout_ms"},
    "stale_feedback": {"timeout_ms"},
    "temperature_warning": {"threshold_c"},
    "temperature_fault": {"threshold_c"},
}


def robot_config_dir() -> Path:
    """Directory holding one ``<PRODUCT_ID>.yaml`` per robot. Defaults to the
    package ``profiles/`` dir (next to MILLY_DEFAULT.yaml); override with
    ``$MOTOMIND_CONFIG_DIR`` (used by tests and for a separate config location)."""
    env = os.environ.get("MOTOMIND_CONFIG_DIR")
    return Path(env).expanduser() if env else _PROFILES_DIR


def load_factory_gravity_calibration(robot_model) -> None:
    """Apply Milly's locked, factory-measured gravity inertials to a model.

    The per-robot tuning overlay deliberately cannot change this file.  It is
    loaded by :meth:`Arm.set_robot_model` before a product FLOAT supervisor is
    created, so public teaching paths never silently fall back to raw URDF
    inertials.
    """
    if not FACTORY_GRAVITY_CALIBRATION.is_file():
        raise RuntimeError(
            "bundled factory gravity calibration is missing: "
            f"{FACTORY_GRAVITY_CALIBRATION}")
    try:
        robot_model.load_gravity_calibration(str(FACTORY_GRAVITY_CALIBRATION))
    except AttributeError as exc:
        raise TypeError(
            "robot_model must provide load_gravity_calibration(); use "
            "motomind_robot_model.RobotModel") from exc


@dataclass
class Tuning:
    """User-tunable knobs (everything else is canonical)."""
    kp: List[float] = field(default_factory=lambda: [15.0] * N_ARM_JOINTS)
    kd: List[float] = field(default_factory=lambda: [1.0] * N_ARM_JOINTS)
    max_vel: float = 0.5
    gripper_kp: float = 10.0      # gripper hold gains (single motor)
    gripper_kd: float = 1.0
    button: Optional[dict] = None  # always None while button actions are release-disabled
    safety: dict = field(default_factory=dict)   # {plugin_id: {key: value}}


def _canonical_gain_limits_for(name: str, cfg) -> List[Tuple[str, float, float]]:
    """Gain bounds for one arm parameter (kp or kd), in base-to-wrist order."""
    arm_motors = [m for m in cfg.motors if m.joint_name != "gripper"]
    if len(arm_motors) != N_ARM_JOINTS:
        raise RuntimeError("bundled canonical config must define six arm joints")
    return [(m.joint_name, getattr(m.limits, f"{name}_min"),
             getattr(m.limits, f"{name}_max"))
            for m in arm_motors]


def _gripper_gain_limits_for(name: str, cfg) -> Tuple[float, float]:
    grippers = [m for m in cfg.motors if m.joint_name == "gripper"]
    if len(grippers) != 1:
        raise RuntimeError("bundled canonical config must define one gripper")
    return (getattr(grippers[0].limits, f"{name}_min"),
            getattr(grippers[0].limits, f"{name}_max"))


def _check_gain_list(name: str, value, limits: List[Tuple[str, float, float]],
                     path: Path) -> List[float]:
    if (not isinstance(value, (list, tuple)) or len(value) != N_ARM_JOINTS
            or not all(isinstance(v, (int, float)) for v in value)):
        raise ValueError(
            f"{path}: motion.{name} must be a list of {N_ARM_JOINTS} numbers "
            "(one per arm joint, base -> wrist)")
    out = [float(v) for v in value]
    bad = [(joint, v, lo, hi)
           for (joint, lo, hi), v in zip(limits, out) if not lo <= v <= hi]
    if bad:
        detail = ", ".join(
            f"{joint}={v:g} outside [{lo:g}, {hi:g}]"
            for joint, v, lo, hi in bad)
        raise ValueError(
            f"{path}: motion.{name} {detail}")
    return out


def _check_gain_scalar(name: str, value, lo: float, hi: float,
                       path: Path) -> float:
    if not isinstance(value, (int, float)) or not lo <= float(value) <= hi:
        raise ValueError(
            f"{path}: gripper.{name} must be a number within [{lo}, {hi}], "
            f"got {value!r}")
    return float(value)


def _read_tuning_doc(path: Path) -> dict:
    """Load one tuning YAML into a dict (no validation)."""
    import yaml
    with open(path, "r", encoding="utf-8") as handle:
        doc = yaml.safe_load(handle) or {}
    if not isinstance(doc, dict):
        raise ValueError(f"{path}: tuning file must be a YAML mapping")
    return doc


def _deep_merge(base: dict, override: dict) -> dict:
    """Overlay ``override`` on ``base``: nested dicts merge key-by-key, every
    other value (scalars, lists) is REPLACED by override. Lists are replaced
    whole — a robot's ``motion.kp`` array replaces the default's, never merges
    element-wise."""
    out = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_tuning(path: Path) -> Tuning:
    """Parse and validate ONE tuning file (no merge)."""
    return _parse_tuning(_read_tuning_doc(path), path, _load_canonical_config())


def _load_canonical_config():
    from . import load_config   # deferred: profile <-> package import cycle
    return load_config(str(CANONICAL_CONFIG))


def _parse_tuning(doc: dict, path: Path, cfg) -> Tuning:
    """Validate a (possibly merged) tuning dict into a Tuning (whitelist)."""
    unknown = set(doc) - {"motion", "gripper", "button", "safety"}
    if unknown:
        raise ValueError(
            f"{path}: unknown section(s) {sorted(unknown)} — tunable sections "
            "are 'motion', 'gripper', 'button' and 'safety'; motor "
            "ids/limits/directions live in the bundled canonical config and "
            "cannot be overridden here")

    tuning = Tuning()
    motion = doc.get("motion") or {}
    if not isinstance(motion, dict):
        raise ValueError(f"{path}: 'motion' must be a mapping")
    unknown = set(motion) - {"kp", "kd", "max_vel"}
    if unknown:
        raise ValueError(
            f"{path}: unknown motion key(s) {sorted(unknown)} — allowed: "
            "kp, kd, max_vel (typos are rejected, not ignored)")

    if "kp" in motion:
        tuning.kp = _check_gain_list(
            "kp", motion["kp"], _canonical_gain_limits_for("kp", cfg), path)
    if "kd" in motion:
        tuning.kd = _check_gain_list(
            "kd", motion["kd"], _canonical_gain_limits_for("kd", cfg), path)
    if "max_vel" in motion:
        v = motion["max_vel"]
        if not isinstance(v, (int, float)) \
                or not MAX_VEL_RANGE[0] < float(v) <= MAX_VEL_RANGE[1]:
            raise ValueError(
                f"{path}: motion.max_vel must be within "
                f"({MAX_VEL_RANGE[0]}, {MAX_VEL_RANGE[1]}] rad/s, got {v!r}")
        tuning.max_vel = float(v)

    gripper = doc.get("gripper") or {}
    if not isinstance(gripper, dict):
        raise ValueError(f"{path}: 'gripper' must be a mapping")
    unknown = set(gripper) - {"kp", "kd"}
    if unknown:
        raise ValueError(
            f"{path}: unknown gripper key(s) {sorted(unknown)} — allowed: kp, kd")
    if "kp" in gripper:
        tuning.gripper_kp = _check_gain_scalar(
            "kp", gripper["kp"], *_gripper_gain_limits_for("kp", cfg), path)
    if "kd" in gripper:
        tuning.gripper_kd = _check_gain_scalar(
            "kd", gripper["kd"], *_gripper_gain_limits_for("kd", cfg), path)

    # Button actions are intentionally disabled for this release. Accept a
    # disabled section so existing robot files continue to load, but reject an
    # attempted enable rather than silently changing its safety semantics.
    button = doc.get("button")
    if button is not None:
        if not isinstance(button, dict):
            raise ValueError(f"{path}: 'button' must be a mapping")
        unknown = set(button) - {"poll_ms", "on_toggle", "enabled"}
        if unknown:
            raise ValueError(
                f"{path}: unknown button key(s) {sorted(unknown)} — allowed: "
                "poll_ms, on_toggle, enabled")
        enabled = button.get("enabled", True)
        if not isinstance(enabled, bool):
            raise ValueError(
                f"{path}: button.enabled must be true/false, got {enabled!r}")
        if enabled:
            raise ValueError(
                f"{path}: button actions are disabled in this SDK release; "
                "button.enabled must be false")
        # validate poll_ms/on_toggle ALWAYS (typos rejected even when disabled,
        # so a value doesn't silently break the day the button is re-enabled);
        # `enabled` only decides whether the monitor actually runs.
        lo, hi = BUTTON_POLL_MS_RANGE
        poll_ms = button.get("poll_ms", 200)
        if not isinstance(poll_ms, int) or not lo <= poll_ms <= hi:
            raise ValueError(
                f"{path}: button.poll_ms must be an integer within "
                f"[{lo}, {hi}] ms, got {poll_ms!r}")
        on_toggle = button.get("on_toggle", "damping_latch")
        if on_toggle not in BUTTON_ACTIONS:
            raise ValueError(
                f"{path}: button.on_toggle {on_toggle!r} not available — "
                f"allowed: {sorted(BUTTON_ACTIONS)}")
        tuning.button = None

    tuning.safety = _validate_safety(doc.get("safety") or {}, path)
    return tuning


def _validate_safety(section, path: Path) -> dict:
    if not isinstance(section, dict):
        raise ValueError(f"{path}: 'safety' must be a mapping")
    unknown = set(section) - set(SAFETY_TUNABLE)
    if unknown:
        raise ValueError(
            f"{path}: safety plugin(s) {sorted(unknown)} are not user-tunable "
            f"— allowed: {sorted(SAFETY_TUNABLE)}")
    out: dict = {}
    for plugin, entry in section.items():
        if not isinstance(entry, dict):
            raise ValueError(f"{path}: safety.{plugin} must be a mapping")
        allowed = SAFETY_TUNABLE[plugin]
        unknown = set(entry) - allowed
        if unknown:
            raise ValueError(
                f"{path}: safety.{plugin} key(s) {sorted(unknown)} not "
                f"allowed — tunable: {sorted(allowed)}")
        vals: dict = {}
        for key, value in entry.items():
            if key == "severity":
                if value not in SEVERITY_NAMES:
                    raise ValueError(
                        f"{path}: safety.{plugin}.severity {value!r} invalid "
                        f"— one of {list(SEVERITY_NAMES)}")
            elif key == "fault_reaction":
                if value not in FAULT_REACTION_NAMES:
                    raise ValueError(
                        f"{path}: safety.{plugin}.fault_reaction {value!r} "
                        f"invalid — one of {list(FAULT_REACTION_NAMES)}")
            elif key == "timeout_ms":
                lo, hi = TIMEOUT_MS_RANGE
                if not isinstance(value, int) or not lo <= value <= hi:
                    raise ValueError(
                        f"{path}: safety.{plugin}.timeout_ms must be an "
                        f"integer within [{lo}, {hi}] ms, got {value!r}")
            elif key == "threshold_c":
                lo, hi = (TEMP_FAULT_C_RANGE if plugin == "temperature_fault"
                          else TEMP_WARN_C_RANGE)
                if not isinstance(value, (int, float))                         or not lo <= float(value) <= hi:
                    raise ValueError(
                        f"{path}: safety.{plugin}.threshold_c must be within "
                        f"[{lo}, {hi}] C, got {value!r}")
            vals[key] = value
        out[plugin] = vals
    return out


def _apply_safety(cfg, overrides: dict, path: Path) -> None:
    """Write validated safety overrides onto the canonical config's plugins."""
    from ._core import parse_fault_reaction, parse_severity

    by_id = {p.id: p for p in cfg.safety.plugins}
    for plugin_id, vals in overrides.items():
        plugin = by_id.get(plugin_id)
        if plugin is None:   # canonical config always defines these
            raise RuntimeError(
                f"bundled config has no safety plugin {plugin_id!r}")
        if "severity" in vals:
            plugin.severity = parse_severity(vals["severity"])
            plugin.severity_configured = True
        if "fault_reaction" in vals:
            plugin.fault_reaction = parse_fault_reaction(vals["fault_reaction"])
            plugin.fault_reaction_configured = True
        if "timeout_ms" in vals:
            plugin.timeout_ms = int(vals["timeout_ms"])
        if "threshold_c" in vals:
            plugin.threshold_temperature_c = float(vals["threshold_c"])
            plugin.threshold_temperature_configured = True

    # cross-check the EFFECTIVE thresholds (override or bundled default)
    warn = by_id.get("temperature_warning")
    fault = by_id.get("temperature_fault")
    if warn is not None and fault is not None             and warn.threshold_temperature_c >= fault.threshold_temperature_c:
        raise ValueError(
            f"{path}: temperature_warning.threshold_c "
            f"({warn.threshold_temperature_c:g}) must stay BELOW "
            f"temperature_fault.threshold_c ({fault.threshold_temperature_c:g})")


def canonical_gravity_tuning(cfg):
    """Locked gravity-comp trim from the CANONICAL config (``gravity.scale`` /
    ``gravity.joint_gains`` / ``gravity.float_kd`` / ``gravity.float_kp``, keyed by
    joint name), mapped to motor ids. This lives in the canonical config on purpose
    — it is NOT user-editable via the per-robot profile. Returns
    (scale, gains, float_kd, float_kp)."""
    import yaml
    with open(CANONICAL_CONFIG, "r", encoding="utf-8") as fh:
        grav = (yaml.safe_load(fh) or {}).get("gravity") or {}
    by_joint = {m.joint_name: m.id for m in cfg.motors}
    def _by_id(section):
        return {by_joint[j]: float(v)
                for j, v in (grav.get(section) or {}).items() if j in by_joint}
    scale = float(grav.get("scale", 1.0))
    return scale, _by_id("joint_gains"), _by_id("float_kd"), _by_id("float_kp")


def load_robot_profile(product_id: str):
    """(canonical config, tuning) for one robot.

    Layered: bundled canonical config + ``MILLY_DEFAULT.yaml`` (base tuning) +
    ``<config dir>/<product_id>.yaml`` overlaid on top (key-by-key). A robot
    file only needs to specify what DIFFERS from the defaults; a section it
    omits is INHERITED from MILLY_DEFAULT, not dropped — so e.g. the button
    e-stop is never silently absent. If the robot has no file, the defaults
    alone are used (logged, so a filename typo doesn't pass unnoticed).
    """
    default_doc = _read_tuning_doc(DEFAULT_TUNING)
    robot_file = robot_config_dir() / f"{product_id}.yaml"
    if robot_file.exists() and robot_file.resolve() != DEFAULT_TUNING.resolve():
        merged = _deep_merge(default_doc, _read_tuning_doc(robot_file))
        source = robot_file
    else:
        merged = default_doc
        source = DEFAULT_TUNING
        log.info("no tuning file for %s (%s) — using bundled defaults "
                 "(MILLY_DEFAULT.yaml). Create that file to customise gains.",
                 product_id, robot_file)

    cfg = _load_canonical_config()
    tuning = _parse_tuning(merged, source, cfg)
    _apply_safety(cfg, tuning.safety, source)
    return cfg, tuning
