"""motomind_milly — Python SDK for the Milly arm (Robstride CAN motors).

Discovery (`list_robots`, the `motomind-milly-robots` CLI) is pure Python and
works everywhere. Everything that touches motors lives in `._sdk` on top of
the compiled `_core` extension and is loaded lazily on first access — so on
platforms where the extension is not built yet (Windows), importing this
package still works and gives discovery; control APIs raise a clear error
only when actually used.
"""

from __future__ import annotations

from .identity import RobotId, list_robots  # noqa: F401  (pure Python)

_SDK = None


def _load_sdk():
    global _SDK
    if _SDK is None:
        try:
            from . import _sdk as _mod
        except ImportError as exc:
            raise ImportError(
                "motomind_milly motor-control core is not available on this "
                "platform/build (the compiled _core extension failed to "
                "import). Robot discovery still works: "
                "motomind_milly.list_robots(). Underlying error: "
                f"{exc}") from exc
        _SDK = _mod
    return _SDK


#: Real submodules must resolve by import, NEVER through _load_sdk(): e.g.
#: identity does `from . import gsusb_transport`, which must not drag in the
#: compiled core on platforms that don't have it.
_SUBMODULES = frozenset({
    "identity", "gsusb_transport", "profile", "monitor", "gravity_comp",
    "motion", "_core", "_sdk",
})


def __getattr__(name):  # PEP 562: lazy `mm.create_arm`, `mm.Arm`, ...
    if name in _SUBMODULES or (name.startswith("_") and not name.endswith("__")):
        import importlib
        try:
            mod = importlib.import_module(f".{name}", __name__)
        except ImportError:
            raise AttributeError(name) from None
        globals()[name] = mod          # cache: skip __getattr__ next time
        return mod
    value = getattr(_load_sdk(), name)
    globals()[name] = value
    return value


def __dir__():
    base = list(globals())
    try:
        return sorted(set(base) | set(dir(_load_sdk())))
    except ImportError:
        return sorted(base)
