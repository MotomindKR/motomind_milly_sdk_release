"""Gravity-compensation bridge: robot-model G(q) -> motor commands.

Bridges the generic robot-model layer (motomind_robot_model, Pinocchio) to the
motor core (_core): it reads joint feedback, computes the generalized gravity
torque, maps it from URDF joint space into motor space (per-motor direction sign
and zero offset), and streams it as ``torque_feedforward`` via ``set_commands``.

The core is untouched — this uses only the public command/feedback API and the
existing ``torque_feedforward`` field, pushed from a mid-rate loop (Python stays
out of the C++ real-time control loop).

Mapping (per joint):
    q_urdf   = direction * q_motor + offset
    tau_motor = direction * tau_urdf            (contravariant with the sign)

IMPORTANT: the core already applies each motor's configured ``direction`` inside
its protocol layer (robstride_protocol.cpp) — feedback positions and commands at
the SDK boundary are ALREADY direction-corrected joint space. ``from_config``
therefore uses the identity mapping (direction=1); the explicit ``JointMap``
direction/offset fields exist only for exotic setups where the SDK-visible space
differs from the URDF's.

Requires the ``robotmodel`` extra (motomind-robot-model).
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Dict, List, Mapping, Optional

from ._core import MotorCommand, MotorManager

log = logging.getLogger("motomind_milly.gravity")

#: Arm prefixes stripped when matching config joint names against URDF joints
#: (dual-arm configs name motors right_joint_1/left_joint_1 etc.).
ARM_PREFIXES = ("right_", "left_")


def resolve_urdf_joint(joint_name: str, urdf_joints) -> Optional[str]:
    """Match a config joint name to a URDF joint, stripping an arm prefix."""
    if joint_name in urdf_joints:
        return joint_name
    for prefix in ARM_PREFIXES:
        if joint_name.startswith(prefix) and joint_name[len(prefix):] in urdf_joints:
            return joint_name[len(prefix):]
    return None


@dataclass
class JointMap:
    """Maps one motor id to a URDF joint, with sign and zero offset."""

    motor_id: int
    urdf_joint: str
    direction: int = 1
    offset: float = 0.0  # q_urdf = direction * q_motor + offset
    # motor-space torque limits: the feedforward is clamped to these so the
    # compensator never emits a torque the motor is not allowed to produce
    tau_min: float = float("-inf")
    tau_max: float = float("inf")
    #: per-joint feedforward multiplier (on top of the global scale) — absorbs
    #: per-link CAD mass/COM error until inertials are calibrated
    gain: float = 1.0


class GravityCompensator:
    """Computes and streams gravity-compensation feedforward torques.

    ``hold_kd`` adds a little velocity damping (kp stays 0 → compliant / back-
    drivable) so the floating arm is stable enough to drag-teach.

    ``scale`` blends the feedforward (0.0 → off, 1.0 → full G(q)) so it can be
    brought up gradually when commissioning a real arm.
    """

    def __init__(
        self,
        manager: MotorManager,
        robot_model,  # motomind_robot_model.RobotModel
        joint_maps: List[JointMap],
        *,
        hold_kd: float = 0.0,
        scale: float = 1.0,
    ):
        self._m = manager
        self._rm = robot_model
        self._maps = [jm for jm in joint_maps if jm.urdf_joint in robot_model._vidx]
        self.hold_kd = float(hold_kd)
        self.scale = float(scale)
        self._clamped: set = set()   # motor ids currently torque-clamped
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

    def set_gain(self, motor_id: int, gain: float) -> None:
        """Live-update one joint's feedforward multiplier (tff = scale*gain*G).
        Takes effect on the next compute() tick — used to trim a single joint
        (e.g. give joint_2 a little more) without touching the others."""
        for jm in self._maps:
            if jm.motor_id == motor_id:
                jm.gain = float(gain)
                return
        raise KeyError(f"no gravity-mapped motor {motor_id}")

    def gains(self) -> Dict[int, float]:
        """Current per-joint feedforward multipliers, {motor_id: gain}."""
        return {jm.motor_id: jm.gain for jm in self._maps}

    @classmethod
    def from_config(
        cls,
        manager: MotorManager,
        robot_model,
        config,  # _core.RobstrideSystemConfig
        *,
        hold_kd: float = 0.0,
        scale: float = 1.0,
        offsets: Optional[Mapping[int, float]] = None,
        gains: Optional[Mapping[int, float]] = None,
    ) -> "GravityCompensator":
        """Build joint maps from an SDK config.

        Identity mapping: the core already applies the per-motor direction sign
        in its protocol layer, so SDK-visible positions/torques are joint space.

        Joint names are the semantic key. Config names may carry an arm prefix
        (e.g. ``right_joint_1`` for a dual-arm setup) — they are matched against
        the URDF by stripping a leading ``right_``/``left_`` when needed.
        """
        offsets = offsets or {}
        gains = gains or {}
        maps = []
        for m in config.motors:
            urdf_joint = resolve_urdf_joint(m.joint_name, robot_model._vidx)
            if urdf_joint is None:
                continue
            maps.append(JointMap(m.id, urdf_joint, 1, float(offsets.get(m.id, 0.0)),
                                 tau_min=m.limits.torque_min,
                                 tau_max=m.limits.torque_max,
                                 gain=float(gains.get(m.id, 1.0))))
        return cls(manager, robot_model, maps, hold_kd=hold_kd, scale=scale)

    # -- computation --------------------------------------------------------- #
    def compute(self) -> List[MotorCommand]:
        """Feedforward commands: kp=0, kd=hold_kd, tff = scale * clamp(G(q)).

        The command position echoes the current feedback: it is inert under
        kp=0, but the step-limit safety plugin checks |cmd - actual| regardless
        of kp — a default 0.0 position would fault the arm at bent poses.
        """
        states = {s.id: s for s in self._m.states()}
        q: Dict[str, float] = {}
        for jm in self._maps:
            s = states.get(jm.motor_id)
            if s is not None:
                q[jm.urdf_joint] = jm.direction * s.position + jm.offset
        tau_urdf = self._rm.gravity_by_joint(q)
        cmds: List[MotorCommand] = []
        for jm in self._maps:
            if jm.urdf_joint in tau_urdf and jm.motor_id in states:
                raw = self.scale * jm.gain * jm.direction * tau_urdf[jm.urdf_joint]
                tau = min(max(raw, jm.tau_min), jm.tau_max)
                if tau != raw and jm.motor_id not in self._clamped:
                    self._clamped.add(jm.motor_id)
                    log.warning("gravity tff CLAMPED for motor %d: %.2f -> %.2f Nm "
                                "(torque limit [%.1f, %.1f])",
                                jm.motor_id, raw, tau, jm.tau_min, jm.tau_max)
                elif tau == raw and jm.motor_id in self._clamped:
                    self._clamped.discard(jm.motor_id)
                    log.info("gravity tff for motor %d back within limits (%.2f Nm)",
                             jm.motor_id, tau)
                cmds.append(MotorCommand(
                    id=jm.motor_id,
                    position=states[jm.motor_id].position,
                    kp=0.0,
                    kd=self.hold_kd,
                    torque_feedforward=tau,
                ))
        return cmds

    def push(self) -> None:
        """Compute and stream one gravity-comp update."""
        self._m.set_commands(self.compute())

    # -- background loop ----------------------------------------------------- #
    def start(self, rate_hz: float = 200.0) -> None:
        """Run the gravity-comp push loop on a background thread (mid-rate)."""
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        period = 1.0 / float(rate_hz)

        def _loop():
            while not self._stop.is_set():
                self.push()
                time.sleep(period)

        self._thread = threading.Thread(target=_loop, name="gravity_comp", daemon=True)
        self._thread.start()
        log.info("gravity comp stream started (rate=%.0fHz, scale=%.2f, hold_kd=%.2f)",
                 rate_hz, self.scale, self.hold_kd)

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=1.0)
            self._thread = None
            log.info("gravity comp stream stopped")
