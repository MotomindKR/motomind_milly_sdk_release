#pragma once

namespace motomind::robstride_motor
{

const char *version();

}  // namespace motomind::robstride_motor
