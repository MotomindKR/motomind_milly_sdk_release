#pragma once

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include "motomind/robstride_motor/robstride_protocol.hpp"
#include "motomind/robstride_motor/transport.hpp"
#include "motomind/robstride_motor/types.hpp"

namespace motomind::robstride_motor
{

struct MotorBusConfig
{
  std::string name{"can0"};
  std::string interface_name{"can0"};
  std::uint8_t host_id{0};
  std::chrono::milliseconds default_timeout{std::chrono::milliseconds(250)};
  int default_retries{5};
  int enable_retries{1};
  std::chrono::milliseconds enable_retry_delay{std::chrono::milliseconds(0)};
};

class MotorBus
{
public:
  MotorBus(MotorBusConfig config, std::unique_ptr<ICanBus> bus);
  ~MotorBus();

  MotorBus(const MotorBus &) = delete;
  MotorBus &operator=(const MotorBus &) = delete;

  bool open();
  void close();
  bool isOpen() const;

  const MotorBusConfig &config() const;
  void addMotor(const MotorConfig &config);
  std::vector<std::uint8_t> motorIds() const;

  std::optional<MotorRuntime> runtimeSnapshot(std::uint8_t motor_id) const;
  std::vector<MotorRuntime> runtimeSnapshots() const;

  std::optional<double> readParamFloat(
    std::uint8_t motor_id,
    std::uint16_t index,
    std::chrono::milliseconds timeout = std::chrono::milliseconds(0),
    int retries = 0);

  std::optional<std::uint8_t> readParamUint8(
    std::uint8_t motor_id,
    std::uint16_t index,
    std::chrono::milliseconds timeout = std::chrono::milliseconds(0),
    int retries = 0);

  bool writeParamUint8(
    std::uint8_t motor_id,
    std::uint16_t index,
    std::uint8_t value,
    std::chrono::milliseconds timeout = std::chrono::milliseconds(0),
    int retries = 0);

  std::optional<Feedback> enableMotor(
    std::uint8_t motor_id,
    std::chrono::milliseconds timeout = std::chrono::milliseconds(0),
    int retries = 0);

  bool setActiveReporting(
    std::uint8_t motor_id,
    bool enabled,
    std::chrono::milliseconds timeout = std::chrono::milliseconds(0),
    int retries = 0);

  std::map<std::uint8_t, Feedback> refreshFeedback(
    const std::vector<std::uint8_t> &motor_ids,
    std::chrono::milliseconds timeout = std::chrono::milliseconds(0),
    int retries = 0);

  std::map<std::uint8_t, Feedback> waitFreshFeedback(
    const std::vector<std::uint8_t> &motor_ids,
    std::chrono::milliseconds timeout = std::chrono::milliseconds(0));

  std::optional<Feedback> stopMotor(
    std::uint8_t motor_id,
    bool clear_fault,
    std::chrono::milliseconds timeout = std::chrono::milliseconds(0),
    int retries = 0);

  std::optional<Feedback> setMechanicalZero(
    std::uint8_t motor_id,
    std::chrono::milliseconds timeout = std::chrono::milliseconds(0),
    int retries = 0);

  bool setRunMode(
    std::uint8_t motor_id,
    std::uint8_t mode,
    std::chrono::milliseconds timeout = std::chrono::milliseconds(0),
    int retries = 0);

  bool sendCommand(const MotorCommand &command);
  std::optional<Feedback> receiveFeedback(std::chrono::milliseconds timeout);
  std::optional<Feedback> awaitFeedback(std::uint8_t motor_id, std::chrono::milliseconds timeout);

private:
  struct ParamFloatResponse
  {
    double value{0.0};
    SteadyTimePoint stamp{};
  };

  struct ParamUint8Response
  {
    std::uint8_t value{0};
    SteadyTimePoint stamp{};
  };

  MotorRuntime *runtimeMutable(std::uint8_t motor_id);
  const MotorParams *paramsFor(std::uint8_t motor_id) const;
  std::chrono::milliseconds effectiveTimeout(std::chrono::milliseconds timeout) const;
  int effectiveRetries(int retries) const;
  int effectiveEnableRetries(int retries) const;
  void applyFeedback(const Feedback &feedback);
  bool sendFrame(const CanFrame &frame);
  void startRxThread();
  void stopRxThread();
  void rxLoop();
  void processFrame(const CanFrame &frame);
  void processParamFrame(const CanFrame &frame);
  void registerPendingParam(std::uint8_t motor_id, std::uint16_t index, SteadyTimePoint stamp);
  void unregisterPendingParam(std::uint8_t motor_id, std::uint16_t index);
  std::optional<double> waitParamFloat(
    std::uint8_t motor_id,
    std::uint16_t index,
    SteadyTimePoint sent_time,
    std::chrono::milliseconds timeout);
  std::optional<std::uint8_t> waitParamUint8(
    std::uint8_t motor_id,
    std::uint16_t index,
    SteadyTimePoint sent_time,
    std::chrono::milliseconds timeout);
  bool waitParamAckOrFeedback(
    std::uint8_t motor_id,
    std::uint16_t index,
    SteadyTimePoint sent_time,
    std::chrono::milliseconds timeout);
  std::optional<Feedback> waitFeedbackSince(
    std::uint8_t motor_id,
    SteadyTimePoint sent_time,
    std::chrono::milliseconds timeout);

  MotorBusConfig config_;
  std::unique_ptr<ICanBus> bus_;
  std::map<std::uint8_t, MotorRuntime> motors_;
  std::map<std::uint8_t, MotorParams> protocol_params_;
  std::map<std::uint8_t, Feedback> latest_feedback_;
  std::deque<Feedback> feedback_queue_;
  std::map<std::pair<std::uint8_t, std::uint16_t>, ParamFloatResponse> param_float_responses_;
  std::map<std::pair<std::uint8_t, std::uint16_t>, ParamUint8Response> param_uint8_responses_;
  std::map<std::pair<std::uint8_t, std::uint16_t>, SteadyTimePoint> param_ack_times_;
  std::map<std::pair<std::uint8_t, std::uint16_t>, SteadyTimePoint> pending_params_;
  mutable std::mutex mutex_;
  std::condition_variable feedback_cv_;
  std::condition_variable param_cv_;
  std::mutex tx_mutex_;
  std::atomic_bool rx_running_{false};
  std::thread rx_thread_;
};

}  // namespace motomind::robstride_motor
