#pragma once

#include <string>

namespace motomind::robstride_motor
{

enum class MotorManagerState
{
  kIdle,
  kEnabled,
  kRunning,
  kFault,
  kShutdown,
};

struct FsmGuards
{
  bool bus_open{true};
  bool motor_list_valid{true};
  bool required_motors_reachable{true};
  bool no_motor_faults{true};
  bool operation_mode_valid{true};
  bool initial_command_safe{true};
  bool command_fresh{true};
  bool manual_recovery_requested{true};
};

struct FsmResult
{
  bool ok{false};
  MotorManagerState from{MotorManagerState::kIdle};
  MotorManagerState to{MotorManagerState::kIdle};
  std::string message;
};

const char *stateName(MotorManagerState state);

class MotorFsm
{
public:
  MotorManagerState state() const;
  const std::string &faultReason() const;

  FsmResult enable(const FsmGuards &guards = FsmGuards{});
  FsmResult start(const FsmGuards &guards = FsmGuards{});
  FsmResult stopControl();
  FsmResult disable();
  FsmResult fault(std::string reason);
  FsmResult recover(const FsmGuards &guards = FsmGuards{});
  FsmResult shutdown();

private:
  FsmResult transitionTo(MotorManagerState next, std::string message);
  FsmResult reject(std::string message) const;

  MotorManagerState state_{MotorManagerState::kIdle};
  std::string fault_reason_;
};

}  // namespace motomind::robstride_motor
