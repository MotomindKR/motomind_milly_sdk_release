#pragma once

#include <chrono>
#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "motomind/robstride_motor/types.hpp"

namespace motomind::robstride_motor::safety
{

enum class SafetySeverity
{
  kIgnore = 0,
  kWarning = 1,
  kFault = 3,
};

enum class LimitAction
{
  kPass = 0,
  kClamp = 1,
  kReject = 2,
};

enum class FaultReaction
{
  kNone = 0,
  kFreezeCommandStream = 1,
  kDampingLatch = 2,
  kHardDisable = 3,
};

struct SafetyIssue
{
  SafetySeverity severity{SafetySeverity::kIgnore};
  FaultReaction reaction{FaultReaction::kNone};
  std::string plugin;
  std::string message;
  bool command_modified{false};
  bool command_rejected{false};
};

struct SafetyReport
{
  SafetySeverity severity{SafetySeverity::kIgnore};
  FaultReaction reaction{FaultReaction::kNone};
  std::vector<SafetyIssue> issues;
  bool command_modified{false};
  bool command_rejected{false};

  bool ok() const { return severity != SafetySeverity::kFault; }
};

class SafetyPlugin
{
public:
  virtual ~SafetyPlugin() = default;

  virtual const char *name() const = 0;
  virtual SafetyReport check(
    const MotorRuntime &runtime,
    MotorCommand &command,
    SteadyTimePoint now) = 0;
};

class SafetyChain
{
public:
  void add(std::unique_ptr<SafetyPlugin> plugin, std::string id = {});
  bool empty() const;
  std::size_t size() const;

  SafetyReport check(
    const MotorRuntime &runtime,
    MotorCommand &command,
    SteadyTimePoint now) const;

private:
  struct Entry
  {
    std::unique_ptr<SafetyPlugin> plugin;
    std::string id;
  };

  std::vector<Entry> plugins_;
};

SafetyReport pass();
SafetyReport issue(
  SafetySeverity severity,
  FaultReaction reaction,
  std::string plugin,
  std::string message,
  bool command_modified = false,
  bool command_rejected = false);
SafetySeverity maxSeverity(SafetySeverity lhs, SafetySeverity rhs);
const char *severityName(SafetySeverity severity);
const char *limitActionName(LimitAction action);
const char *faultReactionName(FaultReaction reaction);
std::optional<SafetySeverity> parseSeverityName(const std::string &name);
std::optional<LimitAction> parseLimitActionName(const std::string &name);
std::optional<FaultReaction> parseFaultReactionName(const std::string &name);

}  // namespace motomind::robstride_motor::safety
