#pragma once

#include <chrono>

#include "motomind/robstride_motor/safety/safety_plugin.hpp"

namespace motomind::robstride_motor::safety
{

class CommandLimitPlugin final : public SafetyPlugin
{
public:
  explicit CommandLimitPlugin(
    LimitAction action,
    SafetySeverity severity,
    FaultReaction fault_reaction);

  const char *name() const override;
  SafetyReport check(const MotorRuntime &runtime, MotorCommand &command, SteadyTimePoint now) override;

private:
  LimitAction action_{LimitAction::kClamp};
  SafetySeverity severity_{SafetySeverity::kWarning};
  FaultReaction fault_reaction_{FaultReaction::kNone};
};

class CommandPositionStepLimitPlugin final : public SafetyPlugin
{
public:
  CommandPositionStepLimitPlugin(
    double max_delta,
    LimitAction action,
    SafetySeverity severity,
    FaultReaction fault_reaction);

  const char *name() const override;
  SafetyReport check(const MotorRuntime &runtime, MotorCommand &command, SteadyTimePoint now) override;

private:
  double max_delta_{0.0};
  LimitAction action_{LimitAction::kReject};
  SafetySeverity severity_{SafetySeverity::kFault};
  FaultReaction fault_reaction_{FaultReaction::kNone};
};

class SafePositionPlugin final : public SafetyPlugin
{
public:
  explicit SafePositionPlugin(
    SafetySeverity severity,
    FaultReaction fault_reaction);

  const char *name() const override;
  SafetyReport check(const MotorRuntime &runtime, MotorCommand &command, SteadyTimePoint now) override;

private:
  SafetySeverity severity_{SafetySeverity::kFault};
  FaultReaction fault_reaction_{FaultReaction::kNone};
};

class CommandUpdateTimeoutPlugin final : public SafetyPlugin
{
public:
  CommandUpdateTimeoutPlugin(
    std::chrono::milliseconds timeout,
    SafetySeverity severity,
    FaultReaction fault_reaction);

  const char *name() const override;
  SafetyReport check(const MotorRuntime &runtime, MotorCommand &command, SteadyTimePoint now) override;

private:
  std::chrono::milliseconds timeout_;
  SafetySeverity severity_{SafetySeverity::kFault};
  FaultReaction fault_reaction_{FaultReaction::kNone};
};

class StaleFeedbackPlugin final : public SafetyPlugin
{
public:
  StaleFeedbackPlugin(
    std::chrono::milliseconds timeout,
    SafetySeverity severity,
    FaultReaction fault_reaction);

  const char *name() const override;
  SafetyReport check(const MotorRuntime &runtime, MotorCommand &command, SteadyTimePoint now) override;

private:
  std::chrono::milliseconds timeout_;
  SafetySeverity severity_{SafetySeverity::kFault};
  FaultReaction fault_reaction_{FaultReaction::kNone};
};

class TemperatureLimitPlugin final : public SafetyPlugin
{
public:
  TemperatureLimitPlugin(
    double threshold_temperature_c,
    SafetySeverity severity,
    FaultReaction fault_reaction);

  const char *name() const override;
  SafetyReport check(const MotorRuntime &runtime, MotorCommand &command, SteadyTimePoint now) override;

private:
  double threshold_temperature_c_{75.0};
  SafetySeverity severity_{SafetySeverity::kFault};
  FaultReaction fault_reaction_{FaultReaction::kNone};
};

class MotorFaultPlugin final : public SafetyPlugin
{
public:
  explicit MotorFaultPlugin(
    SafetySeverity severity,
    FaultReaction fault_reaction);

  const char *name() const override;
  SafetyReport check(const MotorRuntime &runtime, MotorCommand &command, SteadyTimePoint now) override;

private:
  SafetySeverity severity_{SafetySeverity::kFault};
  FaultReaction fault_reaction_{FaultReaction::kNone};
};

class ModeStatusPlugin final : public SafetyPlugin
{
public:
  explicit ModeStatusPlugin(
    SafetySeverity severity,
    FaultReaction fault_reaction);

  const char *name() const override;
  SafetyReport check(const MotorRuntime &runtime, MotorCommand &command, SteadyTimePoint now) override;

private:
  SafetySeverity severity_{SafetySeverity::kFault};
  FaultReaction fault_reaction_{FaultReaction::kNone};
};

}  // namespace motomind::robstride_motor::safety
