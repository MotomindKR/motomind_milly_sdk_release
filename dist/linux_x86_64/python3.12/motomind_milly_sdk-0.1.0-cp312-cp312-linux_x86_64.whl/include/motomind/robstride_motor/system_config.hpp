#pragma once

#include <chrono>
#include <cstddef>
#include <memory>
#include <string>
#include <vector>

#include "motomind/robstride_motor/motor_manager.hpp"
#include "motomind/robstride_motor/safety/safety_plugin.hpp"
#include "motomind/robstride_motor/types.hpp"

namespace motomind::robstride_motor
{

struct SafetyPluginConfig
{
  std::string id;
  std::string type;
  safety::LimitAction action{safety::LimitAction::kReject};
  bool action_configured{false};
  safety::SafetySeverity severity{safety::SafetySeverity::kFault};
  bool severity_configured{false};
  std::chrono::milliseconds timeout_ms{std::chrono::milliseconds(0)};
  double max_delta{0.0};
  double threshold_temperature_c{0.0};
  bool threshold_temperature_configured{false};
  safety::FaultReaction fault_reaction{safety::FaultReaction::kNone};
  bool fault_reaction_configured{false};
};

struct SafetyConfig
{
  std::vector<SafetyPluginConfig> plugins;
  safety::FaultReaction manual_fault_reaction{safety::FaultReaction::kNone};
  bool manual_fault_reaction_configured{false};
  safety::FaultReaction enable_fault_reaction{safety::FaultReaction::kNone};
  bool enable_fault_reaction_configured{false};
  safety::FaultReaction start_fault_reaction{safety::FaultReaction::kNone};
  bool start_fault_reaction_configured{false};
  safety::FaultReaction disable_fault_reaction{safety::FaultReaction::kNone};
  bool disable_fault_reaction_configured{false};
  safety::FaultReaction communication_fault_reaction{safety::FaultReaction::kNone};
  bool communication_fault_reaction_configured{false};
  safety::FaultReaction exit_reaction{safety::FaultReaction::kNone};
  bool exit_reaction_configured{false};
  std::size_t damping_latch_send_count{5};
  double damping_latch_send_rate_hz{100.0};
};

struct FeedbackConfig
{
  bool active_reporting{false};
  bool disable_active_reporting_on_exit{true};
};

struct MotorBusDefinition
{
  MotorBusConfig config;
  double command_rate_hz{500.0};
};

struct RobstrideSystemConfig
{
  std::vector<MotorBusDefinition> buses;
  std::vector<MotorConfig> motors;
  FeedbackConfig feedback;
  SafetyConfig safety;
};

void applySafetyConfig(MotorManager &manager, const SafetyConfig &config);
std::unique_ptr<MotorManager> makeMotorManager(const RobstrideSystemConfig &config);

}  // namespace motomind::robstride_motor
