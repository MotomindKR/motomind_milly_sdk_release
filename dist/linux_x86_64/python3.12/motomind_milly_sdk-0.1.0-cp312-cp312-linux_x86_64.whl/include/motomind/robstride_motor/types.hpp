#pragma once

#include <chrono>
#include <cstdint>
#include <string>

namespace motomind::robstride_motor
{

using SteadyTimePoint = std::chrono::steady_clock::time_point;

struct MotorCommand
{
  std::uint8_t id{0};
  std::string joint_name;
  double position{0.0};
  double velocity{0.0};
  double torque_feedforward{0.0};
  double kp{0.0};
  double kd{0.0};
  SteadyTimePoint stamp{};
};

struct MotorState
{
  std::uint8_t id{0};
  std::string joint_name;
  double position{0.0};
  double velocity{0.0};
  double torque{0.0};
  double temperature{0.0};
  std::uint32_t fault_bits{0};
  std::uint8_t mode_status{0};
  SteadyTimePoint stamp{};
};

struct MotorLimits
{
  double position_min{-12.57};
  double position_max{12.57};
  double velocity_min{-33.0};
  double velocity_max{33.0};
  double torque_min{-14.0};
  double torque_max{14.0};
  double kp_min{0.0};
  double kp_max{500.0};
  double kd_min{0.0};
  double kd_max{5.0};
};

struct MotorSafetyConfig
{
  double damping_kd{-1.0};
  double safe_position_min{0.0};
  double safe_position_max{0.0};
  bool safe_position_configured{false};
};

struct MotorConfig
{
  std::string name;
  std::string joint_name;
  std::uint8_t id{0};
  std::string bus_name{"can0"};
  std::string model{"ROBSTRIDE_04"};
  int direction{1};
  bool required{true};
  std::uint8_t run_mode{0};
  MotorLimits limits;
  MotorSafetyConfig safety;
};

struct MotorRuntime
{
  MotorConfig config;
  MotorState latest_state;
  MotorCommand latest_command;
  SteadyTimePoint last_feedback_time{};
  SteadyTimePoint last_command_time{};
};

}  // namespace motomind::robstride_motor
