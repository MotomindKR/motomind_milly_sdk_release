#pragma once

#include <chrono>
#include <optional>
#include <string>

#include "motomind/robstride_motor/transport.hpp"

namespace motomind::robstride_motor
{

class SocketCanBus final : public ICanBus
{
public:
  SocketCanBus() = default;
  explicit SocketCanBus(std::string interface_name);
  ~SocketCanBus();

  SocketCanBus(const SocketCanBus &) = delete;
  SocketCanBus &operator=(const SocketCanBus &) = delete;

  SocketCanBus(SocketCanBus &&other) noexcept;
  SocketCanBus &operator=(SocketCanBus &&other) noexcept;

  bool open() override;
  void close() override;
  bool isOpen() const override;

  bool send(const CanFrame &frame) override;
  std::optional<CanFrame> receive(std::chrono::milliseconds timeout) override;
  void flush(
    std::chrono::milliseconds quiet_time = std::chrono::milliseconds(2),
    std::chrono::milliseconds max_time = std::chrono::milliseconds(20)) override;

private:
  std::string interface_name_{"can0"};
  int fd_{-1};
};

}  // namespace motomind::robstride_motor
