#pragma once

#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "motomind/robstride_motor/motor_bus.hpp"
#include "motomind/robstride_motor/motor_fsm.hpp"
#include "motomind/robstride_motor/safety/safety_plugin.hpp"
#include "motomind/robstride_motor/types.hpp"

namespace motomind::robstride_motor
{

class MotorManager
{
public:
  ~MotorManager();

  void addBus(std::unique_ptr<MotorBus> bus);

  bool open();
  void close();

  MotorManagerState state() const;
  const MotorFsm &fsm() const;

  FsmResult enable();
  FsmResult start(const FsmGuards &guards = FsmGuards{});
  FsmResult stopControl();
  FsmResult disable();
  FsmResult fault(std::string reason, safety::FaultReaction reaction);
  FsmResult recover(const FsmGuards &guards = FsmGuards{});
  FsmResult shutdown();

  bool setCommand(const MotorCommand &command);
  void setCommands(const std::vector<MotorCommand> &commands);
  void clearCommands();
  bool setRunMode(std::uint8_t motor_id, std::uint8_t mode);
  bool setRunModeForAll(std::uint8_t mode);
  void setDampingLatchConfig(std::size_t send_count, double send_rate_hz);
  void setEnableFaultReaction(safety::FaultReaction reaction);
  void setStartFaultReaction(safety::FaultReaction reaction);
  void setDisableFaultReaction(safety::FaultReaction reaction);
  void setExitReaction(safety::FaultReaction reaction);
  void setCommunicationFaultReaction(safety::FaultReaction reaction);
  void setActiveReportingEnabled(bool enabled);
  void setDisableActiveReportingOnExit(bool enabled);
  std::map<std::uint8_t, Feedback> refreshFeedback(
    std::chrono::milliseconds timeout = std::chrono::milliseconds(0),
    int retries = 0);
  std::map<std::uint8_t, Feedback> waitFreshFeedback(
    std::chrono::milliseconds timeout = std::chrono::milliseconds(0));
  FsmResult startControlLoop(double rate_hz);
  FsmResult stopControlLoop();
  bool controlLoopRunning() const;

  bool sendCommand(const MotorCommand &command);
  std::vector<MotorState> states() const;
  std::vector<MotorRuntime> runtimes() const;
  std::vector<MotorCommand> commands() const;
  std::size_t commandCount() const;
  safety::SafetyReport lastSafetyReportSnapshot() const;
  safety::FaultReaction lastFaultReaction() const;
  std::string lastControlLoopError() const;

  safety::SafetyChain &safetyChain();
  const safety::SafetyChain &safetyChain() const;

private:
  void controlLoop(double rate_hz);
  void feedbackMonitorLoop();
  void startFeedbackMonitor();
  void stopFeedbackMonitor();
  void joinFeedbackMonitorIfNeeded();
  void executeHardDisable();
  bool executeDampingLatch();
  double dampingKdFor(const MotorConfig &config) const;
  void joinControlThreadIfNeeded();
  std::vector<MotorCommand> commandSnapshot() const;
  std::map<std::uint8_t, MotorCommand> commandMapSnapshot() const;
  void setLastSafetyReport(safety::SafetyReport report);
  void setLastFaultReaction(safety::FaultReaction reaction);
  void setLastControlLoopError(std::string error);
  FsmResult okResult(std::string message) const;
  void rebuildMotorIndex();
  bool allBusesOpen() const;
  bool hasRequiredMotors() const;
  bool activateReportingForConfiguredMotors();
  void deactivateReportingBestEffort();

  std::vector<std::unique_ptr<MotorBus>> buses_;
  std::map<std::uint8_t, MotorBus *> motor_bus_index_;
  MotorFsm fsm_;
  safety::SafetyChain safety_chain_;
  safety::SafetyReport last_safety_report_;
  safety::FaultReaction last_fault_reaction_{safety::FaultReaction::kNone};
  std::string last_control_loop_error_;
  mutable std::mutex status_mutex_;
  std::map<std::uint8_t, MotorCommand> latest_commands_;
  mutable std::mutex command_mutex_;
  std::atomic_bool control_loop_running_{false};
  std::size_t damping_latch_send_count_{5};
  double damping_latch_send_rate_hz_{100.0};
  safety::FaultReaction enable_fault_reaction_{safety::FaultReaction::kNone};
  safety::FaultReaction start_fault_reaction_{safety::FaultReaction::kNone};
  safety::FaultReaction disable_fault_reaction_{safety::FaultReaction::kNone};
  safety::FaultReaction exit_reaction_{safety::FaultReaction::kNone};
  safety::FaultReaction communication_fault_reaction_{safety::FaultReaction::kNone};
  bool active_reporting_enabled_{false};
  bool disable_active_reporting_on_exit_{true};
  std::mutex control_thread_mutex_;
  std::thread control_thread_;
  std::atomic_bool feedback_monitor_running_{false};
  std::mutex feedback_monitor_mutex_;
  std::thread feedback_monitor_thread_;
};

}  // namespace motomind::robstride_motor
