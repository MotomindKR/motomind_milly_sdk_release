#pragma once

#include <optional>
#include <string>

#include "motomind/robstride_motor/can_frame.hpp"
#include "motomind/robstride_motor/types.hpp"

namespace motomind::robstride_motor
{

enum class CommType : std::uint8_t
{
  kGetDeviceId = 0,
  kMotorControl = 1,
  kMotorFeedback = 2,
  kMotorEnable = 3,
  kMotorStop = 4,
  kSetMechanicalZero = 6,
  kSetCanId = 7,
  kParamRead = 17,
  kParamWrite = 18,
  kFaultFeedback = 21,
  kDataSave = 22,
  kActiveReport = 24,
};

struct MotorParams
{
  double position_min{-12.57};
  double position_max{12.57};
  double velocity_min{-33.0};
  double velocity_max{33.0};
  double torque_min{-14.0};
  double torque_max{14.0};
  double kp_min{0.0};
  double kp_max{500.0};
  double kd_min{0.0};
  double kd_max{5.0};
  int direction{1};
};

struct Feedback
{
  std::uint8_t motor_id{0};
  std::uint8_t mode_status{0};
  std::uint16_t fault_bits{0};
  double position{0.0};
  double velocity{0.0};
  double torque{0.0};
  double temperature{0.0};
};

MotorParams motorParamsForModel(const std::string &model, int direction = 1);

std::uint32_t buildCanId(CommType comm_type, std::uint16_t data_field, std::uint8_t target_id);
std::uint8_t commTypeFromCanId(std::uint32_t can_id);
std::uint16_t dataFieldFromCanId(std::uint32_t can_id);

CanFrame makeEnableFrame(std::uint8_t host_id, std::uint8_t motor_id);
CanFrame makeStopFrame(std::uint8_t host_id, std::uint8_t motor_id, bool clear_fault);
CanFrame makeSetMechanicalZeroFrame(std::uint8_t host_id, std::uint8_t motor_id);
CanFrame makeParamReadFrame(std::uint8_t host_id, std::uint8_t motor_id, std::uint16_t index);
CanFrame makeParamWriteUint8Frame(
  std::uint8_t host_id, std::uint8_t motor_id, std::uint16_t index, std::uint8_t value);
CanFrame makeActiveReportFrame(std::uint8_t host_id, std::uint8_t motor_id, bool enabled);
CanFrame makeOperationControlFrame(
  std::uint8_t motor_id,
  const MotorParams &params,
  double torque,
  double position,
  double velocity,
  double kp,
  double kd);

std::optional<Feedback> parseFeedbackFrame(const CanFrame &frame, const MotorParams &params);
std::optional<double> parseParamFloatFrame(const CanFrame &frame, std::uint16_t expected_index);
std::optional<std::uint8_t> parseParamUint8Frame(const CanFrame &frame, std::uint16_t expected_index);

}  // namespace motomind::robstride_motor
