#pragma once

// GsUsbCanBus — ICanBus over a candleLight-compatible (gs_usb) USB-CAN module,
// talking to the device directly through libusb-1.0.
//
// Purpose: hosts WITHOUT SocketCAN (Windows, macOS). On Linux the kernel's
// gs_usb driver already exposes the module as can0/can1 — prefer SocketCanBus
// there. (Opening this transport on Linux requires the kernel driver to be
// detached; open() does that automatically via libusb.)
//
// This is an ADDITIVE extension to the frozen core: new files only, the same
// pattern as FakeCanBus/SocketCanBus. It is compiled only when libusb-1.0
// development headers are present (MOTOMIND_HAS_GSUSB is then defined for
// dependents).
//
// v1 scope/limitations (documented, deliberate):
//   - one GsUsbCanBus instance per physical module; `channel` selects which
//     of the module's CAN ports it drives. Frames arriving for the module's
//     OTHER channel are discarded — do not open two instances on one module
//     in the same process yet.
//   - classic CAN, 29-bit extended frames only (mirrors SocketCanBus, which
//     also drops non-EFF frames).

#include <chrono>
#include <cstdint>
#include <optional>
#include <string>

#include "motomind/robstride_motor/can_frame.hpp"
#include "motomind/robstride_motor/transport.hpp"

namespace motomind::robstride_motor
{

struct GsUsbBitTiming
{
  std::uint32_t prop_seg{0};
  std::uint32_t phase_seg1{0};
  std::uint32_t phase_seg2{0};
  std::uint32_t sjw{1};
  std::uint32_t brp{0};
};

// Solve classic-CAN bit timing for `bitrate` from the device-reported
// constraints (gs_usb BT_CONST), aiming at an ~87.5 % sample point.
// Pure function (no USB) so it is unit-testable everywhere.
// E.g. fclk=48 MHz @ 1 Mbps -> brp=3, 16 tq, phase_seg2=2 (87.5 %).
std::optional<GsUsbBitTiming> gsUsbSolveBitTiming(
  std::uint32_t fclk_hz,
  std::uint32_t bitrate,
  std::uint32_t tseg1_min, std::uint32_t tseg1_max,
  std::uint32_t tseg2_min, std::uint32_t tseg2_max,
  std::uint32_t brp_min, std::uint32_t brp_max, std::uint32_t brp_inc);

class GsUsbCanBus final : public ICanBus
{
public:
  static constexpr std::uint16_t kDefaultVendorId = 0x1D50;   // candleLight
  static constexpr std::uint16_t kDefaultProductId = 0x606F;

  GsUsbCanBus() = default;
  // `device_index` selects among modules sorted by (usb bus, address);
  // `channel` selects the module's CAN port (0-based).
  explicit GsUsbCanBus(
    unsigned device_index,
    unsigned channel = 0,
    std::uint32_t bitrate = 1'000'000,
    std::uint16_t vendor_id = kDefaultVendorId,
    std::uint16_t product_id = kDefaultProductId);
  ~GsUsbCanBus() override;

  GsUsbCanBus(const GsUsbCanBus &) = delete;
  GsUsbCanBus &operator=(const GsUsbCanBus &) = delete;
  GsUsbCanBus(GsUsbCanBus &&other) noexcept;
  GsUsbCanBus &operator=(GsUsbCanBus &&other) noexcept;

  bool open() override;
  void close() override;
  bool isOpen() const override;

  bool send(const CanFrame &frame) override;
  std::optional<CanFrame> receive(std::chrono::milliseconds timeout) override;
  void flush(
    std::chrono::milliseconds quiet_time = std::chrono::milliseconds(2),
    std::chrono::milliseconds max_time = std::chrono::milliseconds(20)) override;

  // Number of CAN channels the module reported (valid after open()).
  unsigned channelCount() const { return channel_count_; }

private:
  bool controlOut(std::uint8_t request, std::uint16_t value,
                  const void *data, std::uint16_t length);
  bool controlIn(std::uint8_t request, std::uint16_t value,
                 void *data, std::uint16_t length);

  unsigned device_index_{0};
  unsigned channel_{0};
  std::uint32_t bitrate_{1'000'000};
  std::uint16_t vendor_id_{kDefaultVendorId};
  std::uint16_t product_id_{kDefaultProductId};

  void *ctx_{nullptr};      // libusb_context*   (opaque: keep libusb out of
  void *handle_{nullptr};   // libusb_device_handle*      the public header)
  unsigned channel_count_{0};
  std::uint8_t ep_in_{0};
  std::uint8_t ep_out_{0};
  bool started_{false};
};

}  // namespace motomind::robstride_motor
