#pragma once

#include <chrono>
#include <condition_variable>
#include <deque>
#include <mutex>
#include <optional>
#include <vector>

#include "motomind/robstride_motor/transport.hpp"

namespace motomind::robstride_motor
{

class FakeCanBus final : public ICanBus
{
public:
  bool open() override;
  void close() override;
  bool isOpen() const override;

  bool send(const CanFrame &frame) override;
  std::optional<CanFrame> receive(std::chrono::milliseconds timeout) override;
  void flush(
    std::chrono::milliseconds quiet_time = std::chrono::milliseconds(2),
    std::chrono::milliseconds max_time = std::chrono::milliseconds(20)) override;

  void pushReceiveFrame(const CanFrame &frame);
  void pushReceiveOnSendFrame(const CanFrame &frame);
  std::optional<CanFrame> takeSentFrame();
  const std::vector<CanFrame> &sentFrames() const;
  void clear();

private:
  bool open_{false};
  std::deque<CanFrame> rx_frames_;
  std::deque<CanFrame> rx_on_send_frames_;
  std::deque<CanFrame> tx_frames_;
  std::vector<CanFrame> sent_frames_;
  mutable std::mutex mutex_;
  std::condition_variable cv_;
};

}  // namespace motomind::robstride_motor
