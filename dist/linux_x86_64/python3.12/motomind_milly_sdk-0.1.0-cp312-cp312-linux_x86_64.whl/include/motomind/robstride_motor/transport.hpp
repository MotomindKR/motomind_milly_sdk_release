#pragma once

#include <chrono>
#include <optional>

#include "motomind/robstride_motor/can_frame.hpp"

namespace motomind::robstride_motor
{

class ICanBus
{
public:
  virtual ~ICanBus() = default;

  virtual bool open() = 0;
  virtual void close() = 0;
  virtual bool isOpen() const = 0;

  virtual bool send(const CanFrame &frame) = 0;
  virtual std::optional<CanFrame> receive(std::chrono::milliseconds timeout) = 0;
  virtual void flush(
    std::chrono::milliseconds quiet_time = std::chrono::milliseconds(2),
    std::chrono::milliseconds max_time = std::chrono::milliseconds(20)) = 0;
};

}  // namespace motomind::robstride_motor
