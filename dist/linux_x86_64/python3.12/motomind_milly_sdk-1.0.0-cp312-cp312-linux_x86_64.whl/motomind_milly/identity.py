# Public launcher for the compiled implementation.
from . import _compiled_identity as _implementation
RobotId = _implementation.RobotId
list_robots = _implementation.list_robots
main = _implementation.main
def __getattr__(name):
    return getattr(_implementation, name)
if __name__ == '__main__':
    raise SystemExit(main())
