# Public launcher for the compiled implementation.
from . import _compiled_monitor as _implementation
import sys as _sys
if __name__ == '__main__':
    raise SystemExit(_implementation.main())
else:
    _sys.modules[__name__] = _implementation
